/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2018 Presta.Site
 * @license   LICENSE.txt
 */

/* Prefix: pbc */

$(function () {
    pbc_reloadNewBlockForm();
    pbc_clearZeroValues();
    pbc_updateHookInfoDisplay(0);
    // Init tinyMCE
    // pbcLoadTinyMce();
    pbc_setTinyMCEBg();

    // Init datepicker
    pbc_loadDatetimepicker();
    pbc_loadTimepicker();

    pbcMakeBlocksSortable();
    pbc_initColorPicker();
    // update option display
    pbc_updateDisplayCustomThemeOptions();
    pbc_updateDisplayTypeOptions(0);
    pbc_updateScheduleDisplay();

    $('.pbc-btn-preview').attr('target', '_blank');

    $('[name=theme]').on('change', function(){
        pbc_updateDisplayCustomThemeOptions(300);
    });

    var theme_name = $('[name=theme]:checked').data('theme');
    $('.pbc_color_wrp').addClass('hidden');
    $('.pbc_color_wrp.color-theme-' + theme_name).removeClass('hidden');

    // Delete field from list
    var del_selector = '#form-pstbannercountdown .pbc_delete_item';
    if (pbc_psv == 1.5) {
        del_selector = 'table.pstbannercountdown .pbc_delete_item';
    }
    $(document).on('click', del_selector, function (e) {
        e.preventDefault();

        if (!confirm(pbc_basic_confirm_txt)) {
            return false;
        }

        var table = 'pstbannercountdown';
        var url = $(this).attr('href');
        $.ajax({
            url: url,
            method: 'post',
            beforeSend: function () {
                $('#table-' + table).addClass('pst-loading');
            },
            complete: function () {
                pbc_reloadList(table);
            }
        });
    });

    $(document).on('click', '.msc_link', function () {
        $(this).next('.msc_link_input').fadeIn(200);
        $(this).hide();
    });

    // Tabs
    $('.pst-tabs-list a').on('click', function(e) {
        e.preventDefault();

        var tab_id = $(this).attr('href');

        pbc_openTab($(this), tab_id);
    });

    $(document).on('click', '#pbc-add-block', function (e) {
        e.preventDefault();
        $('#pbc-new-block-form-wrp').slideToggle(200, function () {
            pbcRefreshBlockFormDependencies();
        });
        if (pbc_psv == 1.5) {
            $('#pbc-new-block-form-wrp #fieldset_form').slideToggle(200, function () {
                pbcRefreshBlockFormDependencies();
            });
        }
        pbcLoadTinyMce();
        pbcRefreshBlockFormDependencies();
        pbc_initColorPicker();
        if (pbc_psv >= 1.6) {
            $('#pbc-new-block-form-wrp').find('[data-toggle="tooltip"]').tooltip();
        }
    });

    $(document).on('submit', '#pbc-new-block-form', function (e) {
        e.preventDefault();

        var $this = $(this);
        var form = $(this)[0];
        var data = new FormData(form);
        data.append('ajax', true);
        data.append('action', 'saveBlock');
        $(this).find('input[type=file]').each(function () {
            data.append($(this).attr('name'), $(this).prop("files")[0]);
        });

        $.ajax({
            url: pbc_ajax_url,
            dataType: 'text',
            cache: false,
            contentType: false,
            processData: false,
            method: 'post',
            type: 'post',
            data: data,
            success: function (data) {
                if (data == '1') {
                    pbc_reloadNewBlockForm();
                    pbc_reloadBlocks();
                    pbcShowSavedMsg();
                } else {
                    $this.find('.pst-errors-wrp').html(data);
                }
            }
        });

        return false;
    });

    $(document).on('submit', '#pbc-edit-block-form', function (e) {
        e.stopImmediatePropagation();
        e.preventDefault();

        var $this = $(this);
        var form = $(this)[0];
        var data = new FormData(form);
        data.append('ajax', true);
        data.append('action', 'saveBlock');
        $(this).find('input[type=file]').each(function () {
            data.append($(this).attr('name'), $(this).prop("files")[0]);
        });

        $.ajax({
            url: pbc_ajax_url,
            dataType: 'text',
            cache: false,
            contentType: false,
            processData: false,
            method: 'post',
            type: 'post',
            data: data,
            success: function (data) {
                if (data == '1') {
                    pbc_reloadNewBlockForm();
                    pbc_reloadBlocks();
                    $.pst_modal.close();
                    pbcShowSavedMsg();
                } else {
                    $this.find('.pst-errors-wrp').html(data);
                }
            }
        });

        return false;
    });

    $(document).on('click', '.ppc-del-block', function (e) {
        e.preventDefault();
        e.stopImmediatePropagation();

        if (!confirm(pbc_basic_confirm_txt)) {
            return false;
        }

        var id_block = $(this).data('id-block');

        $.ajax({
            url: pbc_ajax_url,
            method: 'post',
            data: {ajax: true, action: 'deleteBlock', id_block: id_block},
            complete: function () {
                pbc_reloadBlocks();
                pbcShowSavedMsg();
            }
        });
    });

    $(document).on('click', '.ppc-content', function () {
        var id_block = $(this).data('id-block');
        var $this = $(this);
        $this.addClass('loading');

        $.ajax({
            url: pbc_ajax_url,
            method: 'post',
            data: {ajax: true, action: 'getEditBlockForm', id_block: id_block},
            success: function (html) {
                $('#phc_blocks_modal_content').html(html).pst_modal();
                pbcInitProductAutoComplete();
                pbcMakeProductsSortable();
                if (pbc_psv == 1.5) {
                    $('#phc_blocks_modal_content #pstbannercountdown_block_form').attr('id', 'pbc-edit-block-form');
                    pbcLoadTinyMce();
                    setTimeout(function () {
                        pbcLoadTinyMce();
                    }, 500);
                } else {
                    pbcLoadTinyMce();
                }
                pbcRefreshBlockFormDependencies();
                pbc_initColorPicker();
                if (pbc_psv >= 1.6) {
                    $('#phc_blocks_modal_content').find('[data-toggle="tooltip"]').tooltip();
                }
            },
            complete: function () {
                $this.removeClass('loading');
            }
        });
    });

    $(document).on('click', '.pbc_active_toggle', function () {
        var id_countdown = $(this).data('id-countdown');
        var table = 'pstbannercountdown';

        $.ajax({
            url: pbc_ajax_url,
            data: {ajax: true, action: 'changeCountdownStatus', id_countdown: id_countdown},
            method: 'post',
            success: function () {
                pbc_reloadList(table);
            }
        });
    });

    $(document).on('keyup', '.pbc_margin_input', function () {
        pbcUpdateMargin($(this))
    });
    $(document).on('change', '.pbc_margin_input', function () {
        pbcUpdateMargin($(this))
    });

    $(document).on('change', '.pbc_type', function () {
        pbcRefreshBlockFormDependencies();
    });

    pbcInitProductAutoComplete();

    $(document).on('click', '.pbc-prod-remove', function () {
        $(this).parents('.list-group-item').remove();
    });

    $('#pbc_show_countdown_options').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        $(this).hide();
        $('#pbc_hide_countdown_options').show(200);
        $('.countdown_appearance_row').slideDown(200)
        pbc_updateDisplayCustomThemeOptions();
    });
    $('#pbc_hide_countdown_options').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        $(this).hide();
        $('#pbc_show_countdown_options').show(200);
        $('.countdown_appearance_row').slideUp(200)
    });
    $('#pbc_show_more_options').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        $(this).hide();
        $('#pbc_hide_more_options').show(200);
        $('.pbc_more_options_row').slideDown(200)
    });
    $('#pbc_hide_more_options').on('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        $(this).hide();
        $('#pbc_show_more_options').show(200);
        $('.pbc_more_options_row').slideUp(200)
    });

    $(document).on('click', '.pbc-delete-img', function (e) {
        if (!confirm(pbc_basic_confirm_txt)) {
            e.preventDefault();
            return false;
        }
    });

    // Slider inputs for font-size
    $(".pbc-fz-slider").slider({
        step: 0.05,
        min: 0.1,
        max: 2,
        slide: function(event, ui) {
            var form_group_selector = (pbc_psv > 1.5 ? '.form-group' : '.countdown_appearance_row')
            var $parent = $(this).closest(form_group_selector);
            $parent.find('.pbc-fz-input').val(ui.value);
            var val = parseInt(parseFloat(ui.value) * 100);
            $parent.find('.pbc-br-text').text(val + '%');
        },
        create: function() {
            var form_group_selector = (pbc_psv > 1.5 ? '.form-group' : '.countdown_appearance_row')
            var val = $(this).closest(form_group_selector).find('.pbc-fz-input').val();
            $(this).slider("value", val);
        }
    });

    $('[name="hook"]').on('change', function () {
        pbc_updateHookInfoDisplay();
    });

    $('.pbc-reset-colors').on('click', function (e) {
        e.preventDefault();

        $(this).parent().children('.pbc_color_wrp:visible').find('.pspc-color').each(function () {
            var default_color = $(this).data('default');
            $(this).val(default_color);
            if (typeof $(this).spectrum === 'function') {
                $(this).spectrum('set', default_color);
            }
        });
    });

    $('#pbc_restart').on('change', function () {
        var $restart_text = $(this).siblings('.pbc_restart_text');
        var alt_text = $restart_text.data('alt-text');
        var text = $restart_text.text();
        $restart_text.text(alt_text).data('alt-text', text); // switch the text

        var $input_wrp = $(this).siblings('.pbc_restart_input_wrp');
        if ($(this).is(':checked')) {
            $input_wrp.addClass('pbc_visible_inline');
            $input_wrp.find('.pbc_restart_hours_input').focus();
        } else {
            $input_wrp.removeClass('pbc_visible_inline');
        }
    });

    $('#pbc_new_banner_btn').on('click', function (e) {
        e.preventDefault();

        $('#pbc_presets_modal_content').pst_modal();
    });

    $('#pbc_source_banner').on('click', function (e) {
        if ($(this).find('option').length) {
            $(this).closest('li').find('input[type="radio"]').prop('checked', true);
        }
    });

    $(document).on('submit', '#pbc_presets_form', function (e) {
        $(this).find('.pbc-submit-btn').prop('disabled', true);
    });

    if (localStorage.getItem('pbc_settings_visible') === '1') {
        $('#pbc_settings_form').show();
        pbc_switchSettingsBtnText();
    }
    $('#pbc-settings-toggle').on('click', function (e) {
        e.preventDefault();

        // switch text and alt text
        pbc_switchSettingsBtnText();

        var $form = $('#pbc_settings_form');
        if (!$form.is(':visible')) {
            localStorage.setItem('pbc_settings_visible', '1');
        } else {
            localStorage.setItem('pbc_settings_visible', '0');
        }

        $form.toggle('50');
    });

    $(document).on('change', '.pspc-cg-all', function (e) {
        var $parent = $(this).parents('.pspc-cg-col:first');
        if ($(this).is(':checked')) {
            $parent.find('.pspc-cg-wrp').slideUp(150);
        } else {
            $parent.find('.pspc-cg-wrp').slideDown(150);
        }
    });

    // checkboxes in the schedule table
    $(document).on('change', '.pbc-schedule-cb', function() {
        if ($(this).is(':checked')) {
            $(this).closest('td').removeClass('inactive');
        } else {
            $(this).closest('td').addClass('inactive');
        }
    });

    // banner type change
    $(document).on('change', '[name="type"]', function() {
        pbc_updateDisplayTypeOptions(150);
    });

    if (pbc_psv === 1.5) {
        $('.pbc_more_options_row #check_all').on('click', function() {
            if (needExpandAllCategories())
                expandAllCategories();
            else {
                let $parent = $(this).closest('.pbc_more_options_row').find('.treeview');
                needCheckAll = true;
                $parent.find('input[type="checkbox"]').not(':checked').each(function () {
                    $(this).attr('checked', true);
                    clickOnCategoryBox($(this));
                });
            }
            return false;
        });
        $('.pbc_more_options_row #uncheck_all').on('click', function() {
            if (needExpandAllCategories()) {
                expandAllCategories();
            } else {
                let $parent = $(this).closest('.pbc_more_options_row').find('.treeview');
                needUncheckAll = true;
                $parent.find('input[type="checkbox"]:checked').each(function () {
                    $(this).attr('checked', false);
                    clickOnCategoryBox($(this));
                });
            }
            return false;
        });
    }
});

/*============================*/

// Default functionality:
$(function () {
    $(document).on('click', '.expand-ffifw', function (e) {
        e.preventDefault();
        $(this).siblings('.expandable-ffifw').fadeIn(300);
        $(this).siblings('.expandable-ffifw').find('.submit-new-field').show();
        $(this).hide();
        $('#new-ff-wrp input:visible:first').focus();
    });
    $(document).on('click', '.close-ffifw', function (e) {
        e.preventDefault();
        var $panel = $(this).parents('.expandable-ffifw:first');
        $panel.siblings('.expand-ffifw').fadeIn(300);
        $panel.hide();
    });
    var filter_inputs = '#table-pstbannercountdown .filter input, #table-pstbannercountdown .filter select';
    $(document).on('change', filter_inputs, function() {
        if ($(this).val()) {
            $('#submitFilterpstbannercountdown').val(1);
        }
    });
});

// List functions:
function pbc_reloadList(table, full) {
    $.ajax({
        url: pbc_ajax_url,
        data: {ajax: true, action: 'getList', table: table},
        method: 'post',
        beforeSend: function () {
            $('#pstbannercountdown-wrp, #table-' + table).addClass('pst-loading');
        },
        success: function (html) {
            if (!full) {
                if (pbc_psv == 1.5) {
                    html = $('<div/>').html(html).find('table:first').html();
                    $('#pstbannercountdown-wrp table').html(html)
                } else {
                    html = $('<div/>').html(html).find('#table-' + table).html();
                    $('#table-' + table).html(html)
                }
            } else {
                if (pbc_psv == 1.5) {
                    $('#pstbannercountdown_toolbar').remove();
                    $('#pstbannercountdown-wrp').html(html);
                    $('#pstbannercountdown-wrp #pstbannercountdown-wrp').removeAttr('id');
                } else {
                    html = $('<div/>').html(html).find('#form-' + table).html();
                    $('#form-' + table).html(html);

                    var $panel = $('#new-ff-wrp');
                    $panel.siblings('.expand-ffifw').fadeIn(300);
                    $panel.hide();
                    $panel.find('input, textarea, select').val('');
                }
            }
        },
        complete: function () {
            $('#pstbannercountdown-wrp, #table-' + table).removeClass('pst-loading');
            $('#form-pstbannercountdown').attr('novalidate', 'novalidate');
        }
    });
}

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function pbc_openTab($elem, tab_id) {
    $('.pst-tabs-list a').removeClass('active');
    $elem.addClass('active');
    $('.pst-tab-content').hide();
    $(tab_id).fadeIn(200);
}

function pbc_updateDisplayCustomThemeOptions() {
    var theme_name = $('[name="theme"]:checked').data('theme');

    $('.pbc_color_wrp').addClass('hidden');
    $('.pbc_color_wrp.color-theme-' + theme_name).removeClass('hidden');

    // if custom options block is visible
    if ($('#pbc_hide_countdown_options').is(':visible')) {
        $('.countdown_appearance_row').hide();
        var themes = {
            '1-simple': '.pbc_options_colors, .pbc_options_size, .pbc_options_brad, .pbc_options_compact, .pbc_options_highlight, .pbc_options_colon, .pbc_options_full_labels, .pbc_options_zero_days',
            '2-dark': '.pbc_options_colors, .pbc_options_size, .pbc_options_brad, .pbc_options_compact, .pbc_options_highlight, .pbc_options_full_labels, .pbc_options_zero_days',
            '3-light': '.pbc_options_colors, .pbc_options_size, .pbc_options_brad, .pbc_options_compact, .pbc_options_highlight, .pbc_options_full_labels, .pbc_options_zero_days',
            '4': '.pbc_options_colors, .pbc_options_size, .pbc_options_compact, .pbc_options_highlight, .pbc_options_colon, .pbc_options_full_labels, .pbc_options_zero_days',
            '5': '.pbc_options_colors, .pbc_options_size, .pbc_options_brad, .pbc_options_compact, .pbc_options_highlight, .pbc_options_colon, .pbc_options_full_labels, .pbc_options_zero_days',
            '6': '.pbc_options_colors, .pbc_options_size, .pbc_options_brad, .pbc_options_compact, .pbc_options_highlight, .pbc_options_colon, .pbc_options_full_labels, .pbc_options_zero_days',
            '7-minimal': '.pbc_options_colors, .pbc_options_size, .pbc_options_promo_text, .pbc_options_zero_days',
            '8-clock': '.pbc_options_colors, .pbc_options_size, .pbc_options_colon, .pbc_options_full_labels, .pbc_options_zero_days',
            '9-clock-b': '.pbc_options_colors, .pbc_options_size, .pbc_options_colon, .pbc_options_full_labels, .pbc_options_zero_days',
            '10-minimal-1': '.pbc_options_colors, .pbc_options_size, .pbc_options_promo_text',
            '11-minimal-2': '.pbc_options_colors, .pbc_options_size, .pbc_options_promo_text'
        };
        if (themes[theme_name]) {
            var options_selector = themes[theme_name];
            $(options_selector).show();
        }
    }
}

function pbc_reloadBlocks() {
    var id_countdown = $('#pbc-preview').data('id-countdown');

    $.ajax({
        url: pbc_ajax_url,
        method: 'post',
        data: {ajax: true, action: 'getBlockList', id_countdown: id_countdown},
        beforeSend: function () {
            $('#pbc-preview-blocks').addClass('pst-loading');
        },
        success: function (html) {
            $('#pbc-preview-blocks').replaceWith(html);
            pbcMakeBlocksSortable();
        },
        complete: function () {
            $('#pbc-preview-blocks').removeClass('pst-loading');
        }
    });
}

function pbc_reloadNewBlockForm() {
    var id_countdown = $('#pbc-preview').data('id-countdown');

    $.ajax({
        url: pbc_ajax_url,
        method: 'post',
        data: {ajax: true, action: 'getNewBlockForm', id_countdown: id_countdown},
        beforeSend: function () {
            $('#pbc-new-block-form-wrp').slideUp(200).addClass('pst-loading');
        },
        success: function (html) {
            $('#pbc-new-block-form-wrp').html(html);
            pbcInitProductAutoComplete();
        },
        complete: function () {
            $('#pbc-new-block-form-wrp').removeClass('pst-loading');
        }
    });
}

function pbcMakeBlocksSortable() {
    $('.pbc-blocks-sortable').sortable({
        update: function (event, ui) {
            var data = {ajax: true, action: 'saveBlockPositions'};
            var data_string = $.param(data) + '&' + $(this).sortable('serialize');

            $.ajax({
                url: pbc_ajax_url,
                method: 'post',
                data: data_string,
                success: function () {
                    pbcShowSavedMsg();
                }
            });
        }
    });
}
function pbcMakeProductsSortable() {
    $('.pbc_pa_list').sortable({
        handle: ".pbc_move_product",
        update: function (event, ui) {}
    });
}

function pbcLoadTinyMce() {
    // remove current editors
    $('textarea.pbc_rte').each(function() {
        var id = $(this).attr('id');
        if (id) {
            try {
                tinyMCE.execCommand('mceRemoveControl', true, id);
            } catch (e) {
                // Do nothing
            }
        }
    });

    // init editor
    tinySetup({
        editor_selector: "pbc_rte",
        toolbar2 : "fontselect,|,fontsizeselect",
        fontsize_formats: "6px 8px 10px 12px 14px 18px 24px 36px 48px",
        block_formats: 'Div=div;Paragraph=p;Header 2=h2;Header 3=h3;Header 4=h4;Header 5=h5;Header 6=h6;Address=address;Pre=pre',
        setup : function(ed) {
            if (typeof ed.onKeyUp !== 'undefined') {
                ed.onKeyUp.add(function(ed, e) {
                    tinyMCE.triggerSave();
                });
            } else {
                ed.on('keyup', function(e) {
                    tinyMCE.triggerSave();
                });
            }
            if (typeof ed.on !== 'undefined') {
                ed.on('init', function() {
                    pbc_setTinyMCEBg();
                });
            }
        }
    });
}

function pbcUpdateMargin($this) {
    var $parent = $this.parents('.pbc_margin_wrp:first');
    var top = ($parent.find('.pmi_top').val() ? $parent.find('.pmi_top').val() : 0);
    var right = ($parent.find('.pmi_right').val() ? $parent.find('.pmi_right').val() : 0);
    var bottom = ($parent.find('.pmi_bottom').val() ? $parent.find('.pmi_bottom').val() : 0);
    var left = ($parent.find('.pmi_left').val() ? $parent.find('.pmi_left').val() : 0);
    $parent.find('.pmi_hidden').val(top + 'px ' + right + 'px ' + bottom + 'px ' + left + 'px');
}

function pbcGetRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function pbcRefreshBlockFormDependencies() {
    var $new_form = $('#pbc-new-block-form');
    if ($new_form.is(':visible')) {
        var type = $('#pbc-new-block-form [name=type]').val();
        if (!type) {
            type = 'text';
        }

        $new_form.find('.pbc_bfg').hide();
        $new_form.find('.pbc_bfg_' + type).show();
    }

    var $edit_form = $('.current #pbc-edit-block-form');
    if ($edit_form.is(':visible')) {
        var type = $('.current #pbc-edit-block-form [name=type]').val();
        if (!type) {
            type = 'text';
        }

        $edit_form.find('.pbc_bfg').hide();
        $edit_form.find('.pbc_bfg_' + type).show();
    }

    if (pbc_psv == 1.5) {
        $('#pbc-new-block-form-wrp #pstbannercountdown_block_form').attr('id', 'pbc-new-block-form');
    }
}

function pbcInitProductAutoComplete() {
    $('.pbc_product_autocomplete').pbc_autocomplete({
        serviceUrl: pbc_ajax_url,
        params: {ajax: true, action: 'getProducts'},
        autoSelectFirst: true,
        onSelect: function (suggestion) {
            var $list = $(this).next('.pbc_pa_list');
            if (!$list.find('[data-id="prod-' + suggestion.data + '"]').length) {
                $list.append('<li class="list-group-item">' + suggestion.value + '<span class="pbc-prod-remove"><i class="icon-remove"></i></span><input type="hidden" data-id="prod-' + suggestion.data + '" name="products[]" value="' + suggestion.data + '" /></li>');
            }
            $(this).val('').focus();
        }
    });
}

function pbcShowSavedMsg() {
    if (typeof showSuccessMessage === 'function') {
        showSuccessMessage(pbc_saved_txt);
    }
}

function pbcGetThemeId(theme_name) {
    var id_theme = theme_name.replace(/(^\d+)(.+$)/i,'$1');

    return id_theme;
}
function pbcCheckTheme(ids) {
    var current_theme = $('[name="theme"]:checked').val();
    var id_current_theme = parseInt(pbcGetThemeId(current_theme));

    return ids.indexOf(id_current_theme) !== -1;
}
function pbc_initColorPicker() {
    $('.pbcColorPickerInput').spectrum({
        preferredFormat: "rgb",
        showAlpha: true,
        allowEmpty:true,
        showInput: true
    }).on('change.spectrum', function(e, tinycolor) {
        pbc_setTinyMCEBg();
    });
}
function pbc_clearZeroValues() {
    var elements = '#font_size, #border_radius, #height';
    $(elements).each(function () {
        if ($(this).val() === '0') {
            $(this).val('');
        }
    });
}

function pbc_updateHookInfoDisplay(delay) {
    var hook = $('[name="hook"]').val();

    if (hook === 'custom') {
        $('#pbc-hook-instructions').fadeIn(delay);
    } else {
        $('#pbc-hook-instructions').fadeOut(delay);
    }
}

function pbc_setTinyMCEBg() {
    if (typeof tinyMCE !== 'undefined') {
        var color = $('.jquery-modal').find('[name="bg_color"]').val();
        if (!color) {
            color = $('#pstbannercountdown_form').find('[name="bg_color"]').val();
        }
        $('.pbc_rte').each(function () {
            var target_selector = $(this).attr('id');
            var tm = tinyMCE.get(target_selector);
            if (tm && typeof tm !== 'undefined') {
                if (tm.getBody()) {
                    tm.getBody().style.backgroundColor = color;
                }
            }
        });
    }
}

function pbc_switchSettingsBtnText() {
    var $btn = $('#pbc-settings-toggle');
    var $text = $btn.find('.text');
    var text = $text.text();
    var alt_text = $btn.data('alt-text');
    $text.text(alt_text);
    $btn.data('alt-text', text);
}

function pbc_loadTimepicker() {
    if (typeof pbc_flatpickr_time === 'object' && typeof pbc_flatpickr_time.destroy === 'function') {
        pbc_flatpickr_time.destroy();
    }

    window.pbc_flatpickr_time = flatpickr('.pbc-timepicker', {
        enableTime: true,
        noCalendar: true,
        dateFormat: "H:i",
        time_24hr: true,
        "plugins": [new confirmDatePlugin({})]
    });
}

function pbc_updateScheduleDisplay() {
    $('.pbc-schedule-cb').each(function() {
        if ($(this).is(':checked')) {
            $(this).closest('td').removeClass('inactive');
        } else {
            $(this).closest('td').addClass('inactive');
        }
    });
}

function pbc_updateDisplayTypeOptions(delay) {
    let type = $('[name="type"]').val();

    $('.pbc_type_sub_row').hide();
    $('.pbc_' + type + '_type_sub_row').show(delay);
}

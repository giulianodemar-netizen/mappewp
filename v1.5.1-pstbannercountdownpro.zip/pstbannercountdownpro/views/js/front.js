/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2018 Presta.Site
 * @license   LICENSE.txt
 */

$(function () {
    $('.pbc-custom').each(function () {
        let id_countdown = $(this).text();
        let $banner = $('.pstb-hidden #pstBannerCountdown-' + id_countdown).parent();
        if ($banner.length) {
            let content = $banner[0].outerHTML;
            content = '<div class="pstb-wrp"><div class="row pstb-container">' + content + '</div></div>';
            $(this).html(content).removeClass('pbc-custom');
        }
    });

    $(document).on('click', '.pstb_close', function (e) {
        e.preventDefault();

        $(this).hide();
        var id = $(this).data('id');
        $('#pstBannerCountdown-' + id).fadeOut(300, function () {
            $('.pbc-sticky-padding').remove();
            $('.pstBannerCountdownItem').each(function() {
                pbc_setStickyHelper($(this));
            });
        });

        var ctime = Math.floor(Date.now() / 1000);
        localStorage.setItem('pstbc_' + id, ctime);
    });

    // maybe there are sticky banners without timers
    if (!$('.pbc-inactive').length) {
        $('.pbc-sticky-padding').remove();
        $('.pstBannerCountdownItem').each(function() {
            pbc_setStickyHelper($(this));
        });
    }
    pbc_initCountdown();
    if (pbc_getUrlParameter('banner_preview') !== null) {
        localStorage.setItem('pbc_banner_preview', '1');
    }

    if (localStorage.getItem('pbc_banner_preview') === '1') {
        var html = '<div id="pbc_preview_wrp"><label><input type="checkbox" id="pbc_preview" checked> ' + pbc_preview_txt + '</label></div>';
        $('body').append(html);
    }

    $(document).on('change', '#pbc_preview', function () {
        if (!$(this).is(':checked')) {
            localStorage.setItem('pbc_banner_preview', '0');
            $(this).prop('disabled', true);
            window.location = window.location.pathname + '?no_banner_preview=1';
        }
    });

    // If there are any timers in the product info, they will be properly started on the product data reload:
    if (typeof prestashop === 'object' && typeof prestashop.on === 'function') {
        prestashop.on('updatedProduct', function (event) {
            pbc_initCountdown();
        });
    }
});

// Parse countdown string to an object
function pbc_strfobj(str) {
    var pieces = str.split(':');
    var obj = {};
    pbc_labels.forEach(function(label, i) {
        obj[label] = pieces[i]
    });
    return obj;
}
// Return the time components that diffs
function pbc_diff(obj1, obj2) {
    var diff = [];
    pbc_labels.forEach(function(key) {
        if (obj1[key] !== obj2[key]) {
            diff.push(key);
        }
    });
    return diff;
}

function pbc_initCountdown(selector) {
    selector = (selector ? selector : '.pbc-inactive');
    $(selector).each(function(){
        var $pbc = $(this);
        var pbc_theme = $pbc.data('theme').toString();
        var flip = parseInt($pbc.data('flip'));
        var full_labels = parseInt($pbc.data('full-labels'));
        var highlight = $pbc.data('highlight');
        var hide_zero_days = $pbc.data('hide-zero-days');
        $pbc.addClass('pstbannercountdown hide_weeks');
        var $pbc_main = $(this).find('.pbc-main');
        if (!$pbc_main.length) {
            $pbc.append('<div class="pbc-main" />');
            $pbc_main = $(this).find('.pbc-main');
        }
        $pbc.removeClass('pbc-inactive');
        var $init_content = $(this).find('.pbc-init-content');
        if ($init_content.length) {
            $init_content.remove();
        }

        // get To date
        var to = $(this).data('to');
        if (!isNaN(to)) {
            to = parseInt(to);
        } else {
            to = pbc_dateStringToTimestamp(to);
        }
        if (to) {
            to *= 1000; // seconds to milliseconds
        }

        var now = + new Date();
        if (!to || (to < now)) {
            $(this).closest('.pstBannerCountdownItem').hide();
            return true;
        }

        if (pbc_theme.indexOf('minimal') !== -1) {
            $(this).pbccountdown(to, function(event) {
                var now = + new Date();
                if (to < now) {
                    $pbc.closest('.pstBannerCountdownItem').hide(400);
                }
                var days = parseInt(event.strftime('%D'));
                days = (days == 1 ? pbc_labels_lang_1['days'] : pbc_labels_lang['days']);
                if (parseInt(days) < 1 && hide_zero_days) {
                    $pbc.addClass('pbc-hide-days');
                } else {
                    $pbc.removeClass('pbc-hide-days');
                }
                var text = $(this).data('text');
                $pbc_main.html(event.strftime((text ? '<span class="pbc_h">' + text + '</span> ' : '') + '<div class="pbc-countdown-wrp"><span class="days-%D">%D ' + days + '</span> %H:%M:%S </div>'));
            });
        } else {
            var labels = pbc_labels,
                template = _.template(pbc_countdown_tpl);
            var currDate = '00:00:00:00';
            var nextDate = '00:00:00:00';

            // Build the layout
            var initData = pbc_strfobj(currDate);
            labels.forEach(function(label, i) {
                $pbc_main.append(template({
                    curr: initData[label],
                    next: initData[label],
                    label: label,
                    label_lang: pbc_labels_lang[label],
                    highlight: highlight,
                    full_labels: full_labels
                }));
            });
            // Starts the countdown
            $pbc_main.pbccountdown(to, function(event) {
                var days = parseInt(event.strftime('%D'));
                if (parseInt(days) < 1 && hide_zero_days) {
                    $pbc.addClass('pbc-hide-days');
                } else {
                    $pbc.removeClass('pbc-hide-days');
                }
                var now = + new Date();

                if (to < now) {
                    $pbc.closest('.pstBannerCountdownItem').hide(400);
                }

                var data;
                var newDate = event.strftime('%D:%H:%M:%S');

                if (newDate !== nextDate) {
                    currDate = nextDate;
                    nextDate = newDate;
                    // Set up the data
                    data = {
                        'curr': pbc_strfobj(currDate),
                        'next': pbc_strfobj(nextDate)
                    };
                    // Apply the new values to each node that changed
                    pbc_diff(data.curr, data.next).forEach(function(label) {
                        var selector = '.%s'.replace(/%s/, label),
                            $node = $pbc_main.find(selector);
                        // Update the node
                        $node.removeClass('flip hidden');
                        $node.find('.pbc-curr').text(data.curr[label]);
                        $node.find('.pbc-next').text(data.next[label]);
                        // Update the label
                        var label_txt = (data.next[label] === '01' ? pbc_labels_lang_1[label] : pbc_labels_lang[label]);
                        if (!full_labels && label_txt.length >= 6) {
                            label_txt = label_txt.substr(0, 3);
                        }
                        $node.find('.pbc-label').text(label_txt);
                        // Wait for a repaint to then flip
                        _.delay(function($node) {
                            if (flip) {
                                $node.addClass('flip');
                            }
                        }, 50, $node);
                    });
                }
            });
        }

        pbc_setStickyHelper($pbc);
    });
}

function pbc_setStickyHelper($pbc) {
    // set body padding for sticky banners
    var $parent_sticky_top = $pbc.parents('.pbc-sticky-top');
    var $parent_sticky_bottom = $pbc.parents('.pbc-sticky-bottom');
    if ($parent_sticky_top.length) {
        var height = $parent_sticky_top.outerHeight();
        if (!$pbc.is(':visible') || $pbc.hasClass('pstb-hidden') || $pbc.hasClass('pstb-hiding')) {
            height = 0;
        }
        $('body').prepend('<div class="pbc-sticky-padding" style="height: ' + height + 'px;" />')
    } else if ($parent_sticky_bottom.length) {
        var height = $parent_sticky_bottom.outerHeight();
        if (!$pbc.is(':visible') || $pbc.hasClass('pstb-hidden') || $pbc.hasClass('pstb-hiding')) {
            height = 0;
        }
        $('body').append('<div class="pbc-sticky-padding" style="height: ' + height + 'px;" />')
    }
}

function pbc_dateStringToTimestamp(dateString) {
    if (dateString) {
        var dateTimeParts = dateString.split(' '),
            timeParts = dateTimeParts[1].split(':'),
            dateParts = dateTimeParts[0].split('-'),
            date;

        date = new Date(dateParts[0], parseInt(dateParts[1], 10) - 1, dateParts[2], timeParts[0], timeParts[1]);

        return date.getTime();
    } else {
        return null;
    }
}

function pbc_getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }

    return null;
}

var pbc_countdown_tpl = '' +
    '<div class="pbc-time <%= label %> <%= label == highlight ? \'pbc-highlight\' : \'\' %>">' +
    '<span class="pbc-count pbc-curr pbc-top"><%= curr %></span>' +
    '<span class="pbc-count pbc-next pbc-top"><%= next %></span>' +
    '<span class="pbc-count pbc-next pbc-bottom"><%= next %></span>' +
    '<span class="pbc-count pbc-curr pbc-bottom"><%= curr %></span>' +
    '<span class="pbc-label"><%= (label_lang.length < 6 || full_labels) ? label_lang : label_lang.substr(0, 3)  %></span>' +
    '</div>';
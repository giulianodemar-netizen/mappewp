/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    chmln
 * @copyright 2017
 * @license   MIT
 */
function confirmDatePlugin(pluginConfig) {
    var defaultConfig = {
        confirmIcon: "",
        confirmText: "OK",
        resetText: "X",
        showAlways: false,
        theme: "light"
    };

    var config = {};
    for (var key in defaultConfig) {
        config[key] = pluginConfig && pluginConfig[key] !== undefined ? pluginConfig[key] : defaultConfig[key];
    }

    return function (fp) {
        fp.confirmContainer = fp._createElement("div", "flatpickr-confirm " + config.theme + "Theme", config.confirmText);
        fp.resetContainer = fp._createElement("div", "flatpickr-reset " + config.theme + "Theme", config.resetText);

        fp.confirmContainer.tabIndex = -1;
        fp.resetContainer.tabIndex = -1;
        fp.confirmContainer.innerHTML += config.confirmIcon;

        fp.confirmContainer.addEventListener("click", function () {
            fp.close();
            if (typeof fp !== 'undefined' && typeof fp.element !== 'undefined' && !fp.element.value) {
                fp.element.value = '12:00';
            }
        });
        fp.resetContainer.addEventListener("click", function () {
            fp.close();
            if (typeof fp !== 'undefined' && typeof fp.element !== 'undefined') {
                fp.element.value = '';
                if (typeof fp.altInput !== 'undefined') {
                    fp.altInput.value = '';
                }
            }
        });

        var hooks = {
            onReady: function onReady() {
                fp.calendarContainer.appendChild(fp.confirmContainer);
                fp.calendarContainer.appendChild(fp.resetContainer);
            }
        };

        if (config.showAlways) fp.confirmContainer.classList.add("visible");else hooks.onChange = function (dateObj, dateStr) {
            var showCondition = fp.config.enableTime || fp.config.mode === "multiple";
            if (dateStr && !fp.config.inline && showCondition)
                return fp.confirmContainer.classList.add("visible");
            fp.confirmContainer.classList.remove("visible");
        };

        if (config.showAlways) fp.resetContainer.classList.add("visible");else hooks.onChange = function (dateObj, dateStr) {
            var showCondition = fp.config.enableTime || fp.config.mode === "multiple";
            if (dateStr && !fp.config.inline && showCondition)
                return fp.resetContainer.classList.add("visible");
            fp.resetContainer.classList.remove("visible");
        };

        hooks.onKeyDown = function (_, __, ___, e) {
            if (fp.config.enableTime && e.key === "Tab" && e.target === fp.amPM) {
                e.preventDefault();
                fp.confirmContainer.focus();
            } else if (e.key === "Enter" && e.target === fp.confirmContainer) {
                fp.close();
            } else if (e.key === "Enter" && e.target === fp.resetContainer) {
                fp.close();
            }
        };

        return hooks;
    };
}

if (typeof module !== "undefined") module.exports = confirmDatePlugin;
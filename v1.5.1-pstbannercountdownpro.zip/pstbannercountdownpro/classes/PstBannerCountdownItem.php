<?php
/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2018 Presta.Site
 * @license   LICENSE.txt
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class PstBannerCountdownItem extends ObjectModel
{
    public $system_name;
    public $theme;
    public $hook;
    public $from;
    public $to;
    public $from_schedule;
    public $to_schedule;
    public $active;
    public $bg_color;
    public $bg_image;
    public $colors;
    public $link;
    public $width;
    public $limit_width;
    public $height;
    public $font_size;
    public $border_radius;
    public $highlight_position;
    public $compact_view;
    public $promo_text;
    public $screen_sizes;
    public $custom_css;
    public $close_btn;
    public $show_colon;
    public $margin;
    public $restart;
    public $restart_hours;
    public $categories;
    public $show_full_labels;
    public $all_groups;
    public $type;
    public $schedule;
    public $hide_zero_days;
    public $priority;

    public $sticky = false;
    public $skip_block_creation = false;
    protected $module;

    public static $definition = [
        'table' => 'pstbannercountdown',
        'primary' => 'id_pstbannercountdown',
        'multilang' => true,
        'fields' => [
            // Classic fields
            'system_name' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'theme' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true],
            'bg_color' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'screen_sizes' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'hook' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'from' => ['type' => self::TYPE_DATE, 'validate' => 'isPhpDateFormat'],
            'to' => ['type' => self::TYPE_DATE, 'validate' => 'isPhpDateFormat'],
            'from_schedule' => ['type' => self::TYPE_DATE, 'validate' => 'isPhpDateFormat'],
            'to_schedule' => ['type' => self::TYPE_DATE, 'validate' => 'isPhpDateFormat'],
            'width' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'limit_width' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'height' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'font_size' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'border_radius' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'compact_view' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'highlight_position' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'custom_css' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml'],
            'close_btn' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'show_colon' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'margin' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'restart' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'is_checkbox' => true],
            'restart_hours' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'categories' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'is_checkbox' => true],
            'show_full_labels' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'all_groups' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'is_checkbox' => true],
            'type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'schedule' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'hide_zero_days' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'priority' => ['type' => self::TYPE_INT, 'validate' => 'isInt'],
            // Lang fields
            'link' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isUrl'],
            'promo_text' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml'],
            'bg_image' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'lang' => true, 'file' => true],
        ],
    ];

    public function __construct($id = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id, $id_lang, $id_shop);

        $this->loadSchedule();

        $this->active = $this->isActive();

        $this->from = ($this->from && strtotime($this->from) > 0 ? date('Y-m-d\TH:i:s\Z', strtotime($this->from)) : '');
        $this->to = ($this->to && strtotime($this->to) ? date('Y-m-d\TH:i:s\Z', strtotime($this->to)) : '');

        $this->from_schedule = ($this->from_schedule && strtotime($this->from_schedule) > 0 ? date('Y-m-d\TH:i:s\Z', strtotime($this->from_schedule)) : '');
        $this->to_schedule = ($this->to_schedule && strtotime($this->to_schedule) > 0 ? date('Y-m-d\TH:i:s\Z', strtotime($this->to_schedule)) : '');

        $this->module = Module::getInstanceByName('pstbannercountdownpro');
    }

    public function isActive()
    {
        if (!$this->id) {
            return true;
        }

        $context = Context::getContext();
        $is_active = Db::getInstance()->getValue(
            'SELECT `active`
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
             WHERE `id_pstbannercountdown` = ' . (int) $this->id . '
              AND `id_shop` = ' . (int) $context->shop->id
        );
        // if there are no rows in the shop table
        if ($is_active === false) {
            $is_active = true;
        }

        return $is_active;
    }

    public function validateAllFields()
    {
        $errors = [];

        $module = Module::getInstanceByName('pstbannercountdownpro');
        if ($this->type == 'regular' && !$this->to) {
            $errors[] = $module->l('The "to" field is required.');
        }

        $this->prepareArrayFields();

        $valid = $this->validateFields(false, true);
        if ($valid !== true) {
            $errors[] = $valid . "\n";
        }
        $valid_lang = $this->validateFieldsLang(false, true);
        if ($valid_lang !== true) {
            $errors[] = $valid_lang . "\n";
        }

        return $errors;
    }

    public function validateField($field, $value, $id_lang = null, $skip = [], $human_errors = true)
    {
        return parent::validateField($field, $value, $id_lang, $skip, $human_errors);
    }

    public function save($null_values = false, $auto_date = true)
    {
        if (!$this->from) {
            $from_time = time() - (24 * 60 * 60); // now - 24h
            $this->from = date('Y-m-d H:i:s', $from_time);
        }

        // fix date format for PS 1.6-
        if (version_compare(_PS_VERSION_, '1.7.0', '<')) {
            $props = ['from', 'to', 'from_schedule', 'to_schedule'];
            foreach ($props as $prop) {
                if ($this->{$prop}) {
                    $prop_tmp = new DateTime($this->{$prop}, new DateTimeZone('UTC'));
                    $this->{$prop} = $prop_tmp->format('Y-m-d H:i:s');
                }
            }
        }

        $this->prepareArrayFields();

        $result = parent::save($null_values, $auto_date);

        if ($result && $this->id) {
            // save shop data
            if (Shop::isFeatureActive()) {
                // if multishop active, shop data already saved, only update status
                foreach (Shop::getContextListShopID() as $id_shop) {
                    Db::getInstance()->execute(
                        'UPDATE `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
                         SET `active` = ' . (int) $this->active . '
                         WHERE `id_pstbannercountdown` = ' . (int) $this->id . '
                          AND `id_shop` = ' . (int) $id_shop
                    );
                }
            } else {
                foreach (Shop::getContextListShopID() as $id_shop) {
                    Db::getInstance()->execute(
                        'INSERT INTO `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
                         (`id_pstbannercountdown`, `id_shop`, `active`)
                         VALUES
                         (' . (int) $this->id . ', ' . (int) $id_shop . ', ' . (int) $this->active . ')
                         ON DUPLICATE KEY UPDATE
                          `active` = ' . (int) $this->active
                    );
                }
            }

            $module = Module::getInstanceByName('pstbannercountdownpro');
            $module->clearSmartyCache();
            $module->registerHook($this->hook);
        }

        return $result;
    }

    public function add($autodate = true, $null_values = false)
    {
        $result = parent::add($autodate, $null_values);

        if ($result && $this->id && !$this->skip_block_creation) {
            $id_countdown_block = Db::getInstance()->getValue(
                'SELECT `id_pstbannercountdown_block`
                 FROM `' . _DB_PREFIX_ . 'pstbannercountdown_block`
                 WHERE `id_pstbannercountdown` = ' . (int) $this->id . ' AND `type` = "countdown"'
            );
            if (!$id_countdown_block) {
                $countdown_block = new PstBannerCountdownBlock();
                $countdown_block->id_pstbannercountdown = $this->id;
                $countdown_block->type = 'countdown';
                $countdown_block->width = 12;
                $countdown_block->position = 0;
                $countdown_block->align = 'left';
                // Check for errors
                $field_errors = $countdown_block->validateAllFields();
                // Save if no errors
                if (!(is_array($field_errors) && count($field_errors))) {
                    $countdown_block->save();
                }
            }
        }

        return $result;
    }

    public static function getBannersFront($hook = null, $id = null, $name = null)
    {
        $context = Context::getContext();

        if (!$context->customer) {
            return null;
        }

        if (class_exists('PrestaShopCollection')) {
            $banners = new PrestaShopCollection('PstBannerCountdownItem', $context->language->id);
        } elseif (class_exists('Collection')) {
            $banners = new Collection('PstBannerCountdownItem', $context->language->id);
        } else {
            return null;
        }

        if (Tools::getValue('banner_preview')) {
            $context->cookie->pbc_banner_preview = true;
        } elseif (Tools::getValue('no_banner_preview')) {
            $context->cookie->pbc_banner_preview = false;
        }

        // search banners ids for this shop
        $groups = $context->customer->getGroups();
        $groups = (is_array($groups) && count($groups)
            ? $context->customer->getGroups()
            : [0]
        );
        $banners_tmp = Db::getInstance()->executeS(
            'SELECT s.`id_pstbannercountdown`
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_shop` s
             LEFT JOIN `' . _DB_PREFIX_ . 'pstbannercountdown` p
              ON s.`id_pstbannercountdown` = p.`id_pstbannercountdown`
             LEFT JOIN `' . _DB_PREFIX_ . 'pstbannercountdown_group` g
              ON s.`id_pstbannercountdown` = g.`id_pstbannercountdown`
             WHERE s.`id_shop` IN (' . implode(',', array_map('intval', Shop::getContextListShopID())) . ')
              AND (
               p.`all_groups` = 1
               ' . (is_object($context->customer)
                ? 'OR g.`id_group` IN (' . implode(',', array_map('intval', $groups)) . ')'
                : '') . '
              ) ' .
             (!$context->cookie->pbc_banner_preview ? ' AND s.`active` = 1 ' : '')
        );
        $banners_ids = [];
        foreach ($banners_tmp as $item) {
            $banners_ids[] = $item['id_pstbannercountdown'];
        }

        if (!$banners_ids) {
            return [];
        }

        $banners->sqlWhere(
            'a0.`id_pstbannercountdown` IN (' . implode(',', array_map('intval', $banners_ids)) . ')' .
            ($hook
             ? (is_array($hook) ? ' AND `hook` IN ("' . implode('", "', array_map('pSQL', $hook)) . '")' : ' AND `hook` = "' . pSQL($hook) . '"')
             : '') . '
             AND (
                (`from` <= UTC_TIMESTAMP() AND (`to` >= UTC_TIMESTAMP() OR `restart` = 1))
                OR
                `type` = "schedule"
             )
             ' . ($id ? ' AND a0.`id_pstbannercountdown` = "' . (int) $id . '" ' : '') . '
             ' . ($name ? ' AND `system_name` LIKE "' . pSQL($name) . '" ' : '')
        );
        $banners->orderBy('priority', 'ASC');

        $id_category = Tools::getValue('id_category');
        $id_product = Tools::getValue('id_product');
        $controller = Tools::getValue('controller');
        $categories = [];

        // if need to check category restriction
        if ($controller == 'category' && $id_category) {
            $categories[] = $id_category;
        } elseif ($controller == 'product' && $id_product) {
            $categories = Product::getProductCategories($id_product);
        } elseif ($controller == 'index') {
            $categories[] = 2;
        }

        foreach ($banners as $key => $banner) {
            if ($banner->type == 'schedule') {
                $active_today = self::checkScheduleAndSetDates($banner);
                $banner->to = $banner->to . ' UTC';
                if (!$active_today) {
                    unset($banners[$key]);
                    continue;
                }
            } else {
                $banner->to = $banner->to . ' UTC';

                // restart if necessary
                $datetime_current = new DateTime('now', new DateTimeZone('UTC'));
                $datetime_to = new DateTime($banner->to, new DateTimeZone('UTC'));
                if ($datetime_to < $datetime_current) {
                    if ($banner->restart) {
                        $restarted = $banner->restartTimer();
                        if (!$restarted) {
                            unset($banners[$key]);
                            continue;
                        }
                    } else {
                        unset($banners[$key]);
                        continue;
                    }
                }
            }

            if (strpos($banner->hook, 'Sticky') !== false) {
                $banner->sticky = true;
            }

            if ($banner->categories) {
                $banner_categories = explode(',', $banner->categories);
                if (!array_intersect($categories, $banner_categories)) {
                    unset($banners[$key]);
                }
            }
        }

        return $banners;
    }

    public static function getAllBanners($check_time = true)
    {
        $context = Context::getContext();
        if (class_exists('PrestaShopCollection')) {
            $banners = new PrestaShopCollection('PstBannerCountdownItem', $context->language->id);
        } elseif (class_exists('Collection')) {
            $banners = new Collection('PstBannerCountdownItem', $context->language->id);
        } else {
            return null;
        }

        if ($check_time) {
            $banners->sqlWhere(
                '`from` <= UTC_TIMESTAMP() AND (`to` >= UTC_TIMESTAMP() OR `restart` = 1)'
            );
        }

        foreach ($banners as $banner) {
            $banner->to = $banner->to . ' UTC';
            if (strpos($banner->hook, 'Sticky') !== false) {
                $banner->sticky = true;
            }
        }

        return $banners;
    }

    public static function getAllBO()
    {
        $context = Context::getContext();
        if (class_exists('PrestaShopCollection')) {
            $banners = new PrestaShopCollection('PstBannerCountdownItem', $context->language->id);
        } elseif (class_exists('Collection')) {
            $banners = new Collection('PstBannerCountdownItem', $context->language->id);
        } else {
            return [];
        }

        return $banners;
    }

    public function getBlocks()
    {
        return PstBannerCountdownBlock::getBlocksFront($this->id);
    }

    public function getBgUrl()
    {
        return _MODULE_DIR_ . 'pstbannercountdownpro/upload/' . $this->bg_image;
    }

    public function loadColors()
    {
        if ($this->id && $this->theme) {
            $id_colors = PstBannerCountdownColors::getIdByIdCountdownAndTheme($this->id, $this->theme);
            $this->colors = new PstBannerCountdownColors($id_colors);
        }
    }

    public function getThemeName()
    {
        return rtrim($this->theme, '.css');
    }

    public function getSizeVisibilityClasses()
    {
        $result = '';
        if ($this->screen_sizes) {
            $pbc = Module::getInstanceByName('pstbannercountdownpro');

            foreach ($pbc->getScreenSizeList() as $key => $size) {
                if (!$this->screen_sizes[$key]) {
                    $result .= 'pbc-hide-' . $size['id_option'] . ' ';
                }
            }
        }

        return $result;
    }

    /**
     * Check if the current theme is in the list of theme ids
     *
     * @param $ids_theme array
     *
     * @return bool
     */
    public function checkTheme($ids_theme)
    {
        $id_current_theme = $this->getThemeId($this->theme);

        foreach ($ids_theme as $id_theme) {
            if ($id_current_theme == $id_theme) {
                return true;
            }
        }

        return false;
    }

    public function getThemeId()
    {
        $id_theme = null;
        preg_match("~^(\d+)~", $this->theme, $id_theme);
        if (isset($id_theme[0])) {
            return $id_theme[0];
        }

        return $id_theme;
    }

    public function delete()
    {
        $id = $this->id;
        $result = parent::delete();

        if ($result) {
            foreach (self::$definition['fields'] as $field_name => $field_data) {
                if (isset($field_data['lang']) && $field_data['lang']) {
                    foreach (Language::getLanguages() as $lang) {
                        if (isset($this->{$field_name}[$lang['id_lang']]) && $this->{$field_name}[$lang['id_lang']]) {
                            $file =
                                _PS_MODULE_DIR_ . 'pstbannercountdownpro/upload/' . $this->{$field_name}[$lang['id_lang']];
                            if (file_exists($file)
                                && strpos($this->{$field_name}[$lang['id_lang']], 'example') === false
                            ) {
                                @unlink($file);
                            }
                        }
                    }
                } else {
                    if ($this->{$field_name}) {
                        $file = _PS_MODULE_DIR_ . 'pstbannercountdownpro/upload/' . $this->{$field_name};
                        if (file_exists($file)) {
                            @unlink($file);
                        }
                    }
                }
            }

            Db::getInstance()->execute(
                'DELETE
                 FROM `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
                 WHERE `id_pstbannercountdown` = ' . (int) $this->id
            );

            // delete banner's blocks
            $blocks = PstBannerCountdownBlock::getBlocks($id);
            foreach ($blocks as $block) {
                $block->delete();
            }

            // delete banner's colors
            $color_sets = Db::getInstance()->executeS(
                'SELECT *
                 FROM `' . _DB_PREFIX_ . 'pstbannercountdown_colors`
                 WHERE `id_pstbannercountdown` = ' . (int) $id
            );
            foreach ($color_sets as $set) {
                $colors = new PstBannerCountdownColors($set['id_pstbannercountdown_colors']);
                $colors->delete();
            }
        }

        return $result;
    }

    /**
     * @param bool $active_only
     *
     * @return array list of shop ids
     */
    public function getShops($active_only = true)
    {
        $result = [];

        $shops = Db::getInstance()->executeS(
            'SELECT `id_shop`
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
             WHERE `id_pstbannercountdown` = ' . (int) $this->id .
            ($active_only ? ' AND `active` = 1 ' : '')
        );

        foreach ($shops as $shop) {
            $result[] = $shop['id_shop'];
        }

        return $result;
    }

    public static function getShopsStatic($id_pbc, $active_only = true)
    {
        $pbc = new PstBannerCountdownItem($id_pbc);

        return $pbc->getShops($active_only);
    }

    public function displayInitTimeLabel($type, $diff = '00')
    {
        $text = '';

        // the same behavior as in front.js:pbc_countdown_tpl
        if (is_object($this->module)) {
            switch ($type) {
                case 'days':
                    $text = ($diff == '01'
                        ? $this->module->l('day', 'pstbannercountdownitem')
                        : $this->module->l('days', 'pstbannercountdownitem'));
                    break;
                case 'hours':
                    $text = ($diff == '01'
                        ? $this->module->l('hour', 'pstbannercountdownitem')
                        : $this->module->l('hours', 'pstbannercountdownitem'));
                    break;
                case 'minutes':
                    $text = ($diff == '01'
                        ? $this->module->l('minute', 'pstbannercountdownitem')
                        : $this->module->l('minutes', 'pstbannercountdownitem'));
                    break;
                case 'seconds':
                    $text = ($diff == '01'
                        ? $this->module->l('second', 'pstbannercountdownitem')
                        : $this->module->l('seconds', 'pstbannercountdownitem'));
                    break;
            }

            if (!$this->show_full_labels && Tools::strlen($text) >= 6) {
                $text = Tools::substr($text, 0, 3);
            }
        }

        return $text;
    }

    protected function restartTimer()
    {
        if (!$this->restart) {
            return false;
        }

        $dt_current = new DateTime('now', new DateTimeZone('UTC'));
        $dt_from = new DateTime($this->from, new DateTimeZone('UTC'));
        $dt_to = new DateTime($this->to, new DateTimeZone('UTC'));
        $dt_to_tmp = new DateTime($this->to, new DateTimeZone('UTC'));
        $minutes_diff = (int) round(abs($dt_to->getTimestamp() - $dt_from->getTimestamp()) / 60);
        $minutes_restart = (int) round($this->restart_hours * 60 * 1);

        // if expired and should be restarted
        if ($dt_current > $dt_to) {
            // add X hours to the old end of the countdown:
            $dt_from_new = $dt_to_tmp->modify("+$minutes_restart minute");
            $dt_from_new_tmp = clone $dt_from_new;
            // if the countdown with new start time should be already started:
            if ($dt_from_new <= $dt_current) {
                $dt_to_new = $dt_from_new_tmp->modify("+$minutes_diff minute");
                $i = 0;
                // if even after restart the timer is already expired, max 1000 cycles
                while ($dt_to_new < $dt_current && $i < 1000) {
                    $dt_from_new = $dt_from_new->modify("+$minutes_restart minute");
                    $dt_from_new_tmp = clone $dt_from_new;
                    $dt_to_new = $dt_from_new_tmp->modify("+$minutes_diff minute");
                    ++$i;
                }
                $this->from = $dt_from_new->format('Y-m-d H:i:s');
                $this->to = $dt_to_new->format('Y-m-d H:i:s');

                return $this->save();
            }
        }

        return false;
    }

    public function getDiff($type)
    {
        $dt_current = new DateTime('now', new DateTimeZone('UTC'));
        $dt_to = new DateTime($this->to, new DateTimeZone('UTC'));
        $types = ['days' => 'D', 'hours' => 'H', 'minutes' => 'I', 'seconds' => 'S'];
        if (isset($types[$type])) {
            return $dt_current->diff($dt_to)->format('%' . $types[$type]);
        }

        return '00';
    }

    public function getDigits()
    {
        $result = [];
        $types = ['days', 'hours', 'minutes', 'seconds'];

        foreach ($types as $type) {
            $diff = $this->getDiff($type);
            $result[$type] = [
                'label' => $this->displayInitTimeLabel($type, $diff),
                'digits' => $diff,
            ];
        }

        return $result;
    }

    public function getGroups()
    {
        $groups_raw = Db::getInstance()->executeS(
            'SELECT `id_group`
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_group`
             WHERE `id_pstbannercountdown` = ' . (int) $this->id
        );

        $groups = [];
        foreach ($groups_raw as $group_raw) {
            $groups[] = $group_raw['id_group'];
        }

        return $groups;
    }

    public static function getGroupsTxt($id_item)
    {
        $context = Context::getContext();

        $groups_raw = Db::getInstance()->executeS(
            'SELECT gl.`name`
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_group` pg
             LEFT JOIN `' . _DB_PREFIX_ . 'group_lang` gl ON pg.`id_group` = gl.`id_group`
              AND gl.`id_lang` = ' . (int) $context->language->id . '
             WHERE pg.`id_pstbannercountdown` = ' . (int) $id_item
        );

        $groups = [];
        foreach ($groups_raw as $group_raw) {
            $groups[] = Tools::strtolower($group_raw['name']);
        }

        return implode(', ', $groups);
    }

    public function setGroups($groups)
    {
        if (!$this->id) {
            return false;
        }

        // clear groups for this countdown
        Db::getInstance()->execute(
            'DELETE FROM `' . _DB_PREFIX_ . 'pstbannercountdown_group`
             WHERE `id_pstbannercountdown` = ' . (int) $this->id
        );

        // skip adding groups if all_groups
        if ($this->all_groups) {
            return true;
        }

        if (is_array($groups) && count($groups)) {
            foreach ($groups as $id_group) {
                Db::getInstance()->execute(
                    'INSERT IGNORE INTO `' . _DB_PREFIX_ . 'pstbannercountdown_group`
                     (`id_pstbannercountdown`, `id_group`)
                     VALUES
                     (' . (int) $this->id . ', ' . (int) $id_group . ')'
                );
            }
        }
    }

    protected function prepareArrayFields()
    {
        // convert schedule to string
        if (!is_string($this->schedule)) {
            $this->schedule = (array) $this->schedule;
            $this->schedule = json_encode($this->schedule);
        }
    }

    protected static function checkScheduleAndSetDates(&$banner)
    {
        $banner->loadSchedule();
        $active_today = false;
        $datetime_current = new DateTime('now', new DateTimeZone('UTC'));
        $tz = Configuration::get('PS_TIMEZONE');

        // check for the start and end dates:
        if ($banner->from_schedule && strtotime($banner->from_schedule) > 0) {
            $dt_from = new DateTime($banner->from_schedule, new DateTimeZone($tz));
            $dt_from->setTimezone(new DateTimeZone('UTC'));
            if ($dt_from > $datetime_current) {
                return false;
            }
        }
        if ($banner->to_schedule && strtotime($banner->to_schedule) > 0) {
            $dt_to = new DateTime($banner->to_schedule, new DateTimeZone($tz));
            $dt_to->setTimezone(new DateTimeZone('UTC'));
            if ($dt_to <= $datetime_current) {
                return false;
            }
        }

        // check for the schedule:
        if (is_array($banner->schedule) && $banner->schedule) {
            $today = date('N');
            // if enabled for this day
            if (isset($banner->schedule[$today]) && !empty($banner->schedule[$today]['on'])) {
                // if time is set
                if (!empty($banner->schedule[$today][0]) && !empty($banner->schedule[$today][1])) {
                    $datetime_from =
                        new DateTime($banner->schedule[$today][0], new DateTimeZone($tz));
                    $datetime_from->setTimezone(new DateTimeZone('UTC'));
                    $datetime_to =
                        new DateTime($banner->schedule[$today][1], new DateTimeZone($tz));
                    $datetime_to->setTimezone(new DateTimeZone('UTC'));
                    // If the end time specifies 59 minutes, add 59 seconds. That is, 23:59:00 becomes 23:59:59.
                    if ($datetime_to->format('i') == '59') {
                        $datetime_to->modify('+59 second');
                    }

                    // check if active right now
                    if ($datetime_from <= $datetime_current && $datetime_to > $datetime_current) {
                        $active_today = true;
                        $old_from = $banner->from;
                        $old_to = $banner->to;
                        $banner->from = $datetime_from->format('Y-m-d H:i:s');
                        $banner->to = $datetime_to->format('Y-m-d H:i:s');
                        if ($datetime_from->format('Y-m-d H:i:s') != $old_from
                            || $datetime_to->format('Y-m-d H:i:s') != $old_to
                        ) {
                            $banner->save(); // save, clear cache, etc.
                        }
                    }
                }
            }
        }

        return $active_today;
    }

    public function loadSchedule()
    {
        if (is_string($this->schedule)) {
            $this->schedule = json_decode($this->schedule, true);
        }
    }
}

<?php
/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2018 Presta.Site
 * @license   LICENSE.txt
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class PstBannerCountdownColors extends ObjectModel
{
    public $id_pstbannercountdown;
    public $theme;
    public $bg;
    public $promo;
    public $digits;
    public $highlight;
    public $labels;
    public $border;
    public $shadow;

    public static $definition = [
        'table' => 'pstbannercountdown_colors',
        'primary' => 'id_pstbannercountdown_colors',
        'fields' => [
            // Classic fields
            'id_pstbannercountdown' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'theme' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'bg' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'promo' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'digits' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'highlight' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'labels' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'border' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'shadow' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
        ],
    ];

    public function __construct($id = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id, $id_lang, $id_shop);
    }

    public function validateAllFields()
    {
        $errors = [];

        $valid = $this->validateFields(false, true);
        if ($valid !== true) {
            $errors[] = $valid . "\n";
        }
        $valid_lang = $this->validateFieldsLang(false, true);
        if ($valid_lang !== true) {
            $errors[] = $valid_lang . "\n";
        }

        return $errors;
    }

    public function validateField($field, $value, $id_lang = null, $skip = [], $human_errors = true)
    {
        return parent::validateField($field, $value, $id_lang, $skip, $human_errors);
    }

    public static function getIdByIdCountdownAndTheme($id_pstbannercountdown, $theme)
    {
        if (strpos($theme, '.css') === false) {
            $theme .= '.css';
        }

        $id = Db::getInstance()->getValue(
            'SELECT `id_pstbannercountdown_colors`
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_colors`
             WHERE `id_pstbannercountdown` = ' . (int) $id_pstbannercountdown . '
              AND `theme` = "' . pSQL($theme) . '"'
        );

        return $id;
    }

    public function save($null_values = false, $auto_date = true)
    {
        $result = parent::save($null_values, $auto_date);

        if ($result) {
            $module = Module::getInstanceByName('pstbannercountdownpro');
            $module->clearSmartyCache();
        }

        return $result;
    }
}

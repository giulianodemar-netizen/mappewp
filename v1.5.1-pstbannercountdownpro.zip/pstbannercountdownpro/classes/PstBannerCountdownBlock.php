<?php
/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2018 Presta.Site
 * @license   LICENSE.txt
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class PstBannerCountdownBlock extends ObjectModel
{
    public $id_pstbannercountdown;
    public $type;
    public $width;
    public $width_mobile;
    public $position;
    public $content;
    public $content_countdown;
    public $align;
    public $align_mobile;
    public $valign;
    public $valign_mobile;
    public $margin;
    public $image;
    public $bg_color;
    public $link;

    public $products;

    public static $definition = [
        'table' => 'pstbannercountdown_block',
        'primary' => 'id_pstbannercountdown_block',
        'multilang' => true,
        'fields' => [
            // Classic fields
            'id_pstbannercountdown' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'width' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'width_mobile' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'align' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'align_mobile' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'valign' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'valign_mobile' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'margin' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'bg_color' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            // Lang fields
            'content' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
            'content_countdown' => ['type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml'],
            'image' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isString', 'file' => true],
            'link' => ['type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isUrl'],
        ],
    ];

    public function __construct($id = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id, $id_lang, $id_shop);
    }

    public function validateAllFields()
    {
        $errors = [];

        $valid = $this->validateFields(false, true);
        if ($valid !== true) {
            $errors[] = $valid . "\n";
        }
        $valid_lang = $this->validateFieldsLang(false, true);
        if ($valid_lang !== true) {
            $errors[] = $valid_lang . "\n";
        }

        return $errors;
    }

    public function validateField($field, $value, $id_lang = null, $skip = [], $human_errors = true)
    {
        return parent::validateField($field, $value, $id_lang, $skip, $human_errors);
    }

    public static function getBlocks($id_countdown)
    {
        if (class_exists('PrestaShopCollection')) {
            $blocks = new PrestaShopCollection('PstBannerCountdownBlock');
        } elseif (class_exists('Collection')) {
            $blocks = new Collection('PstBannerCountdownBlock');
        } else {
            return null;
        }

        $blocks->where('id_pstbannercountdown', '=', $id_countdown);
        $blocks->orderBy('position', 'ASC');

        return $blocks;
    }

    public static function getBlocksFront($id_countdown)
    {
        $context = Context::getContext();
        if (class_exists('PrestaShopCollection')) {
            $blocks = new PrestaShopCollection('PstBannerCountdownBlock', $context->language->id);
        } elseif (class_exists('Collection')) {
            $blocks = new Collection('PstBannerCountdownBlock', $context->language->id);
        } else {
            return [];
        }

        $blocks->where('id_pstbannercountdown', '=', $id_countdown);
        $blocks->orderBy('position', 'ASC');

        return $blocks;
    }

    public static function getMaxPosition($id_countdown)
    {
        return Db::getInstance()->getValue(
            'SELECT MAX(`position`)
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_block`
             WHERE `id_pstbannercountdown` = ' . (int) $id_countdown
        );
    }

    public function addProduct($id_product)
    {
        Db::getInstance()->execute(
            'INSERT IGNORE
             INTO `' . _DB_PREFIX_ . 'pstbannercountdown_block_product`
             (`id_pstbannercountdown_block`, `id_product`)
             VALUES
             (' . (int) $this->id . ', ' . (int) $id_product . ')'
        );
    }

    public function getProducts()
    {
        $context = Context::getContext();

        $products = Db::getInstance()->executeS(
            'SELECT pbp.*, pl.`name`, p.`reference`
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_block_product` pbp
             LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON pbp.`id_product` = p.`id_product`
             LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON pbp.`id_product` = pl.`id_product`
              AND pl.`id_lang` = ' . (int) $context->language->id . '
             WHERE `id_pstbannercountdown_block` = ' . (int) $this->id . '
             GROUP BY p.`id_product`'
        );

        return $products;
    }

    public function getProductsFront()
    {
        $context = Context::getContext();
        $id_lang = $context->language->id;
        $interval =
            (Configuration::get('PS_NB_DAYS_NEW_PRODUCT') ? (int) Configuration::get('PS_NB_DAYS_NEW_PRODUCT') : 20);

        if (version_compare(_PS_VERSION_, '1.6.1.0', '<')) {
            $sql = '
            SELECT p.*, product_shop.*, stock.out_of_stock, IFNULL(stock.quantity, 0) as quantity,
                pl.`description`, pl.`description_short`, pl.`link_rewrite`, pl.`meta_description`,
                pl.`meta_keywords`, pl.`meta_title`, pl.`name`,
                m.`name` AS manufacturer_name, p.`id_manufacturer` as id_manufacturer,
                MAX(image_shop.`id_image`) id_image, il.`legend`,
                t.`rate`, pl.`meta_keywords`, pl.`meta_title`, pl.`meta_description`,
                DATEDIFF(p.`date_add`, DATE_SUB(NOW(),
                INTERVAL ' . $interval . ' DAY)) > 0 AS new
            FROM `' . _DB_PREFIX_ . 'pstbannercountdown_block_product` pbp
            LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON pbp.`id_product` = p.`id_product`
            ' . Shop::addSqlAssociation('product', 'p', false) . '
            LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl
                ON p.`id_product` = pl.`id_product`
                AND pl.`id_lang` = ' . (int) $id_lang . Shop::addSqlRestrictionOnLang('pl') . '
            LEFT JOIN `' . _DB_PREFIX_ . 'image` i ON (i.`id_product` = p.`id_product`)' .
            Shop::addSqlAssociation('image', 'i', false, 'image_shop.cover=1') . '
            LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il
             ON (i.`id_image` = il.`id_image` AND il.`id_lang` = ' . (int) $id_lang . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'manufacturer` m ON (m.`id_manufacturer` = p.`id_manufacturer`)
            LEFT JOIN `' . _DB_PREFIX_ . 'tax_rule` tr ON (product_shop.`id_tax_rules_group` = tr.`id_tax_rules_group`)
                AND tr.`id_country` = ' . (int) Context::getContext()->country->id . '
                AND tr.`id_state` = 0
            LEFT JOIN `' . _DB_PREFIX_ . 'tax` t ON (t.`id_tax` = tr.`id_tax`)
            ' . Product::sqlStock('p');
        } elseif ($this->getPSVersion() == 1.6) {
            $sql = '
            SELECT
                p.id_product, IFNULL(product_attribute_shop.id_product_attribute,0) id_product_attribute,
                pl.`link_rewrite`, pl.`name`, pl.`description_short`, product_shop.`id_category_default`,
                image_shop.`id_image` id_image, il.`legend`,
                p.`ean13`, p.`upc`, p.`reference`, cl.`link_rewrite` AS category, p.show_price, p.available_for_order,
                IFNULL(stock.quantity, 0) as quantity, p.customizable,
                IFNULL(pa.minimal_quantity, p.minimal_quantity) as minimal_quantity, stock.out_of_stock,
                product_shop.`date_add` > "' . date('Y-m-d', strtotime('-' . $interval . ' DAY')) . '" as new,
                product_shop.`on_sale`, product_attribute_shop.minimal_quantity AS product_attribute_minimal_quantity
            FROM `' . _DB_PREFIX_ . 'pstbannercountdown_block_product` pbp
            LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON pbp.`id_product` = p.`id_product`
            ' . Shop::addSqlAssociation('product', 'p') . '
            LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_shop` product_attribute_shop
                ON (p.`id_product` = product_attribute_shop.`id_product` AND product_attribute_shop.`default_on` = 1
                 AND product_attribute_shop.id_shop=' . (int) $context->shop->id . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute` pa
             ON (product_attribute_shop.id_product_attribute=pa.id_product_attribute)
            LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl
                ON p.`id_product` = pl.`id_product`
                AND pl.`id_lang` = ' . (int) $id_lang . Shop::addSqlRestrictionOnLang('pl') . '
            LEFT JOIN `' . _DB_PREFIX_ . 'image_shop` image_shop ON (image_shop.`id_product` = p.`id_product`
             AND image_shop.cover=1 AND image_shop.id_shop=' . (int) $context->shop->id . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il ON (image_shop.`id_image` = il.`id_image`
             AND il.`id_lang` = ' . (int) $id_lang . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'category_lang` cl
                ON cl.`id_category` = product_shop.`id_category_default`
                AND cl.`id_lang` = ' . (int) $id_lang . Shop::addSqlRestrictionOnLang('cl') . Product::sqlStock('p', 0);
        } else { // 1.7+
            $ps9 = version_compare(_PS_VERSION_, '9.0.0', '>=');
            $sql = '
            SELECT p.*, product_shop.*, stock.out_of_stock, IFNULL(stock.quantity, 0) as quantity,
                ' . (Combination::isFeatureActive() ? 'product_attribute_shop.minimal_quantity
                 AS product_attribute_minimal_quantity,
                IFNULL(product_attribute_shop.id_product_attribute,0) id_product_attribute,' : '') . '
                pl.`description`, pl.`description_short`, pl.`link_rewrite`, pl.`meta_description`,
                ' . (!$ps9 ? ' pl.`meta_keywords`, ' : '') . '
                pl.`meta_title`, pl.`name`, pl.`available_now`, pl.`available_later`,
                m.`name` AS manufacturer_name, p.`id_manufacturer` as id_manufacturer,
                image_shop.`id_image` id_image, il.`legend`,
                t.`rate`,
                DATEDIFF(p.`date_add`, DATE_SUB("' . date('Y-m-d') . ' 00:00:00",
                INTERVAL ' . (int) $interval . ' DAY)) > 0 AS new'
                . ' FROM `' . _DB_PREFIX_ . 'pstbannercountdown_block_product` pbp
            LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON pbp.`id_product` = p.`id_product`
            ' . Shop::addSqlAssociation('product', 'p', false);

            if (Combination::isFeatureActive()) {
                $sql .= '
                 LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_shop` product_attribute_shop
				    ON (p.`id_product` = product_attribute_shop.`id_product`
				     AND product_attribute_shop.`default_on` = 1 
				     AND product_attribute_shop.id_shop=' . (int) $context->shop->id . ')';
            }

            $sql .= '
                LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl
					ON p.`id_product` = pl.`id_product`
					AND pl.`id_lang` = ' . (int) $context->language->id . Shop::addSqlRestrictionOnLang('pl') . '
				LEFT JOIN `' . _DB_PREFIX_ . 'image_shop` image_shop
					ON (image_shop.`id_product` = p.`id_product` AND image_shop.cover=1
					 AND image_shop.id_shop=' . (int) $context->shop->id . ')
				LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il ON (image_shop.`id_image` = il.`id_image`
				 AND il.`id_lang` = ' . (int) $context->language->id . ')
				LEFT JOIN `' . _DB_PREFIX_ . 'manufacturer` m ON (m.`id_manufacturer` = p.`id_manufacturer`)
				LEFT JOIN `' . _DB_PREFIX_ . 'tax_rule` tr ON (product_shop.`id_tax_rules_group` = tr.`id_tax_rules_group`)
					AND tr.`id_country` = ' . (int) $context->country->id . '
					AND tr.`id_state` = 0
				LEFT JOIN `' . _DB_PREFIX_ . 'tax` t ON (t.`id_tax` = tr.`id_tax`)
				' . Product::sqlStock('p', 0);
        }

        $sql .= '
		WHERE
            `id_pstbannercountdown_block` = ' . (int) $this->id . '
            AND product_shop.`active` = 1
            AND p.`visibility` != "none"';

        if (Group::isFeatureActive()) {
            $groups = FrontController::getCurrentCustomerGroups();
            $sql .= ' AND EXISTS(SELECT 1 FROM `' . _DB_PREFIX_ . 'category_product` cp
				JOIN `' . _DB_PREFIX_ . 'category_group` cg
				 ON (cp.id_category = cg.id_category AND cg.`id_group`
				  ' . (count($groups) ? 'IN (' . implode(',', array_map('intval', $groups)) . ')' : '= 1') . ')
				WHERE cp.`id_product` = p.`id_product`)';
        }

        $sql .= '
        GROUP BY pbp.`id_product`
		ORDER BY pbp.`position` DESC';

        $products = Db::getInstance()->executeS($sql);
        $products = Product::getProductsProperties($context->language->id, $products);

        if ($this->getPSVersion() >= 1.7) {
            $assembler = new ProductAssembler($context);
            $presenterFactory = new ProductPresenterFactory($context);
            $presentationSettings = $presenterFactory->getPresentationSettings();
            if (version_compare(_PS_VERSION_, '9.0.0', '>=')) {
                $presenter = new PrestaShop\PrestaShop\Adapter\Presenter\Product\ProductListingPresenter(
                    new PrestaShop\PrestaShop\Adapter\Image\ImageRetriever(
                        $context->link
                    ),
                    $context->link,
                    new PrestaShop\PrestaShop\Adapter\Product\PriceFormatter(),
                    new PrestaShop\PrestaShop\Adapter\Product\ProductColorsRetriever(),
                    $context->getTranslator()
                );
            } else {
                $presenter = new PrestaShop\PrestaShop\Core\Product\ProductListingPresenter(
                    new PrestaShop\PrestaShop\Adapter\Image\ImageRetriever(
                        $context->link
                    ),
                    $context->link,
                    new PrestaShop\PrestaShop\Adapter\Product\PriceFormatter(),
                    new PrestaShop\PrestaShop\Adapter\Product\ProductColorsRetriever(),
                    $context->getTranslator()
                );
            }

            $products_for_template = [];

            foreach ($products as $rawProduct) {
                $products_for_template[] = $presenter->present(
                    $presentationSettings,
                    $assembler->assembleProduct($rawProduct),
                    $context->language
                );
            }

            $products = $products_for_template;
        }

        return $products;
    }

    public function clearProducts($excl = [])
    {
        if ($this->id) {
            Db::getInstance()->execute(
                'DELETE
                 FROM `' . _DB_PREFIX_ . 'pstbannercountdown_block_product`
                 WHERE `id_pstbannercountdown_block` = ' . (int) $this->id . '
                  ' . (count($excl) ? ' AND `id_product` NOT IN (' . implode(',', array_map('intval', $excl)) . ')' : '')
            );
        }
    }

    public function save($null_values = false, $auto_date = true)
    {
        $result = parent::save($null_values, $auto_date);

        if ($result) {
            $module = Module::getInstanceByName('pstbannercountdownpro');
            $module->clearSmartyCache();
        }

        return $result;
    }

    public function delete()
    {
        $result = parent::delete();

        if ($result) {
            foreach (self::$definition['fields'] as $field_name => $field_data) {
                if (isset($field_data['lang']) && $field_data['lang']) {
                    foreach (Language::getLanguages() as $lang) {
                        if (isset($this->{$field_name}[$lang['id_lang']]) && $this->{$field_name}[$lang['id_lang']]) {
                            $file =
                                _PS_MODULE_DIR_ . 'pstbannercountdownpro/upload/' . $this->{$field_name}[$lang['id_lang']];
                            if (file_exists($file)
                                && strpos($this->{$field_name}[$lang['id_lang']], 'example') === false
                            ) {
                                @unlink($file);
                            }
                        }
                    }
                } else {
                    if ($this->{$field_name}) {
                        $file = _PS_MODULE_DIR_ . 'pstbannercountdownpro/upload/' . $this->{$field_name};
                        if (file_exists($file)) {
                            @unlink($file);
                        }
                    }
                }
            }
        }

        return $result;
    }

    public function getImageUrl()
    {
        return _MODULE_DIR_ . 'pstbannercountdownpro/upload/' . $this->image;
    }

    public function getPSVersion($without_dots = false)
    {
        $ps_version = _PS_VERSION_;
        $ps_version = Tools::substr($ps_version, 0, 3);

        if ($without_dots) {
            $ps_version = str_replace('.', '', $ps_version);
        }

        return (float) $ps_version;
    }
}

<?php
/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2017 Presta.Site
 * @license   LICENSE.txt
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_2_0($module)
{
    try {
        Db::getInstance()->execute(
            'ALTER TABLE `' . _DB_PREFIX_ . 'pstbannercountdown`
             ADD `margin` VARCHAR(64),
             ADD `categories` TEXT,
             ADD `restart` TINYINT(1) DEFAULT 0,
             ADD `restart_hours` DECIMAL(10, 4)'
        );
        Db::getInstance()->execute(
            'ALTER TABLE `' . _DB_PREFIX_ . 'pstbannercountdown_block`
             ADD `valign` VARCHAR(64)'
        );
        Db::getInstance()->execute(
            'ALTER TABLE `' . _DB_PREFIX_ . 'pstbannercountdown_block_lang`
             ADD `link` VARCHAR(255),
             ADD `content_countdown` TEXT'
        );
    } catch (Exception $e) {
        // ignore
    }

    return true; // Return true if success.
}

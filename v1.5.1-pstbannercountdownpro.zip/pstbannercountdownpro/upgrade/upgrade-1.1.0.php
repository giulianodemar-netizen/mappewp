<?php
/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2017 Presta.Site
 * @license   LICENSE.txt
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_0($module)
{
    try {
        // get old data
        $banners = Db::getInstance()->executeS(
            'SELECT *
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown`'
        );

        // new tables
        Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pstbannercountdown_shop` (
                `id_pstbannercountdown` INT(10) NOT NULL,
                `id_shop` INT(10) NOT NULL,
                `active` TINYINT(1) DEFAULT 1,
                UNIQUE (`id_pstbannercountdown`, `id_shop`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8'
        );

        // drop obsolete columns
        Db::getInstance()->execute(
            'ALTER TABLE `' . _DB_PREFIX_ . 'pstbannercountdown`
             DROP `active`,
             DROP `id_shop`;'
        );

        // add new columns
        Db::getInstance()->execute(
            'ALTER TABLE `' . _DB_PREFIX_ . 'pstbannercountdown`
             ADD `show_colon` TINYINT(1) DEFAULT 0,
             MODIFY `font_size` DECIMAL(8, 2) UNSIGNED;'
        );

        // update old data
        foreach ($banners as $banner) {
            Db::getInstance()->execute(
                'INSERT INTO `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
                 (`id_pstbannercountdown`, `id_shop`, `active`)
                 VALUES
                 (' . (int) $banner['id_pstbannercountdown'] . ', ' . (int) $banner['id_shop'] . ', ' . (int) $banner['active'] . ')'
            );

            $fz_old = (int) $banner['font_size'];
            $fz_100p = 12;
            $fz_new = $fz_old / $fz_100p;
            Db::getInstance()->execute(
                'UPDATE `' . _DB_PREFIX_ . 'pstbannercountdown`
                 SET `font_size` = ' . (float) $fz_new . '
                 WHERE `id_pstbannercountdown` = ' . (int) $banner['id_pstbannercountdown']
            );
        }

        $module->regenerateCSS();
    } catch (Exception $e) {
        // ignore
    }

    return true; // Return true if success.
}

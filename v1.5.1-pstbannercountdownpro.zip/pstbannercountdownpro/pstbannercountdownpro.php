<?php
/**
 * NOTICE OF LICENSE
 *
 * This file is licenced under the Software License Agreement.
 * With the purchase or the installation of the software in your application
 * you accept the licence agreement.
 *
 * @author    Presta.Site
 * @copyright 2018 Presta.Site
 * @license   LICENSE.txt
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

if (version_compare(_PS_VERSION_, '1.7.0.0', '<')) {
    require_once _PS_MODULE_DIR_ . 'pstbannercountdownpro/classes/PstBannerCountdownModule16.php';
} else {
    require_once _PS_MODULE_DIR_ . 'pstbannercountdownpro/classes/PstBannerCountdownModule17.php';
}

require_once _PS_MODULE_DIR_ . 'pstbannercountdownpro/classes/PstBannerCountdownItem.php';
require_once _PS_MODULE_DIR_ . 'pstbannercountdownpro/classes/PstBannerCountdownColors.php';
require_once _PS_MODULE_DIR_ . 'pstbannercountdownpro/classes/PstBannerCountdownBlock.php';

class PstBannerCountdownPro extends PstBannerCountdownModule
{
    protected $html;
    protected $errors = [];
    public $settings_prefix = 'PBC_';

    public $custom_css;

    public function __construct()
    {
        $this->name = 'pstbannercountdownpro';
        $this->tab = 'front_office_features';
        $this->version = '1.5.1';
        $this->ps_versions_compliancy = ['min' => '1.5.4.0', 'max' => _PS_VERSION_];
        $this->author = 'PrestaSite';
        $this->bootstrap = true;
        $this->module_key = 'd6c59bd03ab4fd5623c053432eb811db';
        $this->controllers = ['preview'];

        parent::__construct();
        $this->loadSettings();

        $this->displayName = $this->l('Countdown banner PRO');
        $this->description = $this->l('A module for creating banners with countdown timers');
        $this->confirmUninstall = $this->l('Are you sure? All module data will be PERMANENTLY DELETED.');
    }

    public function install()
    {
        if (!parent::install()) {
            return false;
        }

        // Register hooks
        $this->installHooks();

        // Create tables
        $this->installDB();

        // default values:
        $this->installDefaultSettings();

        // Disable free version of this module in order to prevent double countdowns
        $free_version = Module::getInstanceByName('pstbannercountdown');
        if ($free_version) {
            $free_version->disable();
        }

        // Generate settings CSS
        $this->loadSettings();
        $this->regenerateCSS();

        return true;
    }

    public function installHooks()
    {
        $hooks = [
            'header',
            'displayBackOfficeHeader',
            'actionAdminControllerSetMedia',
            'pstBannerCountdown',
            'displayBanner',
            'displayHome',
            'displayLeftColumn',
            'displayRightColumn',
            'displayFooter',
            'displayFooterProduct',
            'displayMaintenance',
            'displayAfterBodyOpeningTag',
            'displayBeforeBodyClosingTag',
        ];

        foreach ($hooks as $hook) {
            $this->registerHook($hook);
        }

        return true;
    }

    public function installDB()
    {
        $install_queries = $this->getDbTables();
        foreach ($install_queries as $query) {
            if (!Db::getInstance()->execute($query)) {
                return false;
            }
        }

        return true;
    }

    protected function getDbTables()
    {
        return [
            'pstbannercountdown' => 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pstbannercountdown` (
                `id_pstbannercountdown` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `system_name` VARCHAR(255),
                `theme` VARCHAR(255),
                `bg_color` VARCHAR(255),
                `hook` VARCHAR(255),
                `width` INTEGER UNSIGNED,
                `limit_width` TINYINT(1) DEFAULT 0,
                `height` INTEGER UNSIGNED,
                `font_size` DECIMAL(8, 2) UNSIGNED,
                `border_radius` INTEGER UNSIGNED,
                `from` DATETIME,
                `to` DATETIME,
                `from_schedule` DATETIME,
                `to_schedule` DATETIME,
                `screen_sizes` VARCHAR(65),
                `compact_view` TINYINT(1) DEFAULT 0,
                `highlight_position` VARCHAR(255),
                `custom_css` TEXT,
                `close_btn` TINYINT(1) DEFAULT 0,
                `show_colon` TINYINT(1) DEFAULT 0,
                `margin` VARCHAR(64),
                `restart` TINYINT(1) DEFAULT 0,
                `restart_hours` DECIMAL(10, 4),
                `categories` TEXT,
                `show_full_labels` TINYINT(1) DEFAULT 0,
                `all_groups` TINYINT(1) DEFAULT 1,
                `type` VARCHAR(16),
                `schedule` TEXT,
                `hide_zero_days` TINYINT(1) DEFAULT 0,
                `priority` INT(6) DEFAULT 1,
                PRIMARY KEY (`id_pstbannercountdown`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8',
            'pstbannercountdown_lang' => 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pstbannercountdown_lang` (
                `id_pstbannercountdown` INT(10) UNSIGNED NOT NULL,
                `id_lang` INT(10),
                `link` VARCHAR(255),
                `promo_text` VARCHAR(255),
                `bg_image` VARCHAR(255),
                UNIQUE (`id_pstbannercountdown`, `id_lang`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8',
            'pstbannercountdown_shop' => 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pstbannercountdown_shop` (
                `id_pstbannercountdown` INT(10) NOT NULL,
                `id_shop` INT(10) NOT NULL,
                `active` TINYINT(1) DEFAULT 1,
                UNIQUE (`id_pstbannercountdown`, `id_shop`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8',
            'pstbannercountdown_colors' => 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pstbannercountdown_colors` (
                `id_pstbannercountdown_colors` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_pstbannercountdown` INT(10) UNSIGNED NOT NULL,
                `theme` VARCHAR(255) NOT NULL,
                `bg` VARCHAR(255),
                `promo` VARCHAR(255),
                `digits` VARCHAR(255),
                `highlight` VARCHAR(255),
                `labels` VARCHAR(255),
                `border` VARCHAR(255),
                `shadow` VARCHAR(255),
                PRIMARY KEY (`id_pstbannercountdown_colors`),
                UNIQUE (`id_pstbannercountdown`, `theme`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8',
            'pstbannercountdown_block' => 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pstbannercountdown_block` (
                `id_pstbannercountdown_block` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_pstbannercountdown` INT(10) UNSIGNED NOT NULL,
                `type` VARCHAR(64),
                `width` VARCHAR(64),
                `width_mobile` VARCHAR(64),
                `align` VARCHAR(64),
                `align_mobile` VARCHAR(64),
                `valign` VARCHAR(64),
                `valign_mobile` VARCHAR(64),
                `margin` VARCHAR(64),
                `bg_color` VARCHAR(64),
                `position` INT(6),
                PRIMARY KEY (`id_pstbannercountdown_block`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8',
            'pstbannercountdown_block_lang' => 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pstbannercountdown_block_lang` (
                `id_pstbannercountdown_block` INT(10) UNSIGNED NOT NULL,
                `id_lang` INT(10),
                `content` TEXT,
                `content_countdown` TEXT,
                `image` VARCHAR(255),
                `link` VARCHAR(255),
                UNIQUE (`id_pstbannercountdown_block`, `id_lang`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8',
            'pstbannercountdown_block_product' => 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pstbannercountdown_block_product` (
                `id_pstbannercountdown_block` INT(10) UNSIGNED NOT NULL,
                `id_product` INT(10),
                `position` INT(6),
                UNIQUE (`id_pstbannercountdown_block`, `id_product`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8',
            'pstbannercountdown_group' => 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'pstbannercountdown_group` (
                `id_pstbannercountdown` INT(11) NOT NULL,
                `id_group` INT(11) NOT NULL,
                UNIQUE (`id_pstbannercountdown`, `id_group`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8',
        ];
    }

    public function installDefaultSettings()
    {
        foreach ($this->getSettings() as $item) {
            if ($item['type'] == 'html') {
                continue;
            }
            if (isset($item['default']) && (Configuration::get($this->settings_prefix . $item['name']) === false)) {
                if (isset($item['lang']) && $item['lang']) {
                    $lang_value = [];
                    foreach (Language::getLanguages() as $lang) {
                        $lang_value[$lang['id_lang']] = $item['default'];
                    }
                    if (sizeof($lang_value)) {
                        Configuration::updateValue($this->settings_prefix . $item['name'], $lang_value, true);
                    }
                } else {
                    Configuration::updateValue($this->settings_prefix . $item['name'], $item['default']);
                }
            }
        }
    }

    public function uninstall()
    {
        if (!parent::uninstall()) {
            return false;
        }

        // drop tables
        foreach ($this->getDbTables() as $table_name => $query) {
            Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . pSQL($table_name) . '`;');
        }

        // Delete all the module settings
        $ids_conf = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . 'configuration`  WHERE `name` LIKE "' . pSQL($this->settings_prefix) . '%"'
        );
        foreach ($ids_conf as $id_conf) {
            $id_conf = $id_conf['id_configuration'];
            Db::getInstance()->execute(
                'DELETE FROM `' . _DB_PREFIX_ . 'configuration_lang` WHERE `id_configuration` = ' . (int) $id_conf
            );
            Db::getInstance()->execute(
                'DELETE FROM `' . _DB_PREFIX_ . 'configuration` WHERE `id_configuration` = ' . (int) $id_conf
            );
        }

        return true;
    }

    public function getContent()
    {
        // Check if this is an ajax call / PS1.5
        if ($this->getPSVersion() < 1.6 && Tools::getIsset('ajax')
            && Tools::getValue('ajax') && Tools::getValue('action')) {
            if (is_callable([$this, 'ajaxProcess' . Tools::getValue('action')])) {
                call_user_func([$this, 'ajaxProcess' . Tools::getValue('action')]);
            }
            exit;
        }

        $this->registerSmartyPlugins();

        $this->html = '';

        if (!$this->active) {
            $this->html .= $this->displayWarning(
                $this->l('The module is deactivated. Please activate it for proper working.')
            );
        }

        $this->html .= $this->postProcess();

        if (Tools::getValue('createNewCountdown')
            || Tools::isSubmit('submitCountdown')
            || Tools::isSubmit('updatepstbannercountdown')
            || Tools::isSubmit('save_and_preview')
            || Tools::isSubmit('submitpstbannercountdown')
        ) {
            $title =
                (Tools::getValue('id_pstbannercountdown') ? $this->l('Edit banner') : $this->l('New banner'));
            $id_countdown = Tools::getValue('id_pstbannercountdown');
            if ($id_countdown) {
                $countdown = new PstBannerCountdownItem($id_countdown);
                $this->html .= $this->displayCustomHookInfo($id_countdown);
                $this->html .= $this->renderItemForm(
                    $title,
                    $this->getItemFormFields($id_countdown),
                    'pstbannercountdown',
                    $this->renderPreviewBlock($id_countdown),
                    $countdown
                );
            } else {
                $this->html .= $this->renderItemForm(
                    $title,
                    $this->getItemFormFields(),
                    'pstbannercountdown',
                    $this->renderPreviewBlock(),
                    null
                );
            }
        } else {
            $this->html .= $this->renderItems();
            $this->html .= $this->renderQuickGuide();
            $this->html .= $this->renderForm($this->l('Settings'), $this->getSettings(), 'pbc_settings');
        }

        return $this->html;
    }

    protected function postProcess()
    {
        $html = '';
        $settings_updated = false;
        $this->errors = [];
        $confirmation = 6;
        $token = Tools::getAdminTokenLite('AdminModules');
        $redirect_url = null;

        // Check if this is an ajax call / PS1.5
        if (($this->getPSVersion() < 1.6 || $this->getPSVersion() >= 9)
            && Tools::getIsset('ajax') && Tools::getValue('ajax') && Tools::getValue('action')) {
            if (is_callable([$this, 'ajaxProcess' . Tools::getValue('action')])) {
                call_user_func([$this, 'ajaxProcess' . Tools::getValue('action')]);
            }
            exit;
        }

        if (Tools::getValue('installTab')) {
            $this->installTab();
        } elseif (Tools::getValue('uninstallTab')) {
            $this->uninstallTab();
        }

        if (Tools::isSubmit('submitpbc_settings')) {
            // saving settings:
            $settings = $this->getSettings();
            foreach ($settings as $item) {
                if ($item['type'] == 'html' || (isset($item['lang']) && $item['lang'] == true)) {
                    continue;
                }
                if (Tools::isSubmit($item['name'])) {
                    $validated = true;
                    $val_method = (isset($item['validate']) ? $item['validate'] : '');

                    if (Tools::strlen(Tools::getValue($item['name']))) {
                        // Validation:
                        if (Tools::strlen($val_method) && is_callable(['Validate', $val_method])) {
                            $validated =
                                call_user_func(['Validate', $val_method], Tools::getValue($item['name']));
                        }
                    }
                    if ($validated) {
                        try {
                            Configuration::updateValue(
                                $this->settings_prefix . $item['name'],
                                Tools::getValue($item['name']),
                                true
                            );
                        } catch (Exception $e) {
                            // do nothing, maybe conf name length exception in PS15
                        }
                        $settings_updated = true;
                    } else {
                        $label = trim($item['label'], ':');
                        $this->errors[] = sprintf($this->l('The "%s" field is invalid'), $label);
                    }
                }
            }

            // update lang fields:
            $languages = Language::getLanguages();
            foreach ($settings as $item) {
                if (!(isset($item['lang']) && $item['lang'])) {
                    continue;
                }
                $val_method = (isset($item['validate']) ? $item['validate'] : '');
                $lang_value = [];
                foreach ($languages as $lang) {
                    if (Tools::isSubmit($item['name'] . '_' . $lang['id_lang'])) {
                        $validated = true;
                        if (Tools::strlen(Tools::getValue($item['name'] . '_' . $lang['id_lang']))) {
                            // Validation:
                            if (Tools::strlen($val_method) && is_callable(['Validate', $val_method])) {
                                $validated =
                                    call_user_func(
                                        ['Validate', $val_method],
                                        Tools::getValue($item['name'] . '_' . $lang['id_lang'])
                                    );
                            }
                        }
                        if ($validated) {
                            $lang_value[$lang['id_lang']] = Tools::getValue($item['name'] . '_' . $lang['id_lang']);
                            $settings_updated = true;
                        } else {
                            $label = trim($item['label'], ':');
                            $this->errors[] = sprintf($this->l('The "%s" field is invalid'), $label);
                        }
                    }
                }
                if (sizeof($lang_value)) {
                    Configuration::updateValue($this->settings_prefix . $item['name'], $lang_value, true);
                }
            }
        }

        if (Tools::isSubmit('createNewCountdown') && Tools::getValue('preset')) {
            $preset = Tools::getValue('preset');
            $id_countdown = $this->createBannerFromPreset($preset);
            if ($id_countdown) {
                $confirmation = 3;
                $redirect_url = $this->getModuleConfigurationPageUrl([
                    'updatepstbannercountdown' => '',
                    'id_pstbannercountdown' => $id_countdown,
                    'conf' => $confirmation,
                    'from_preset' => '1',
                ]);
                Tools::redirectAdmin($redirect_url);
            }
        }

        if (Tools::isSubmit('submitCountdown') || Tools::isSubmit('submitpstbannercountdown')) {
            $html = '';
            $id_countdown = Tools::getValue('id_pstbannercountdown');
            $confirmation = ($id_countdown ? 4 : 3);
            $countdown = new PstBannerCountdownItem($id_countdown);

            foreach (PstBannerCountdownItem::$definition['fields'] as $field_name => $field_data) {
                if (isset($field_data['lang']) && $field_data['lang']
                    && !(isset($field_data['file']) && $field_data['file'])
                ) {
                    $countdown->$field_name = [];
                    foreach (Language::getLanguages() as $lang) {
                        $countdown->{$field_name}[$lang['id_lang']] =
                            trim(Tools::getValue($field_name . '_' . $lang['id_lang']));
                    }
                } elseif (isset($field_data['file']) && $field_data['file']) {
                    // skip for now because ID is required but can be not set yet
                    continue;
                } else {
                    if ($field_name == 'screen_sizes') {
                        $ssizes = '';
                        foreach ($this->getScreenSizeList() as $item) {
                            if (Tools::isSubmit('screen_sizes_' . $item['id_option'])) {
                                $ssizes .= '1';
                            } else {
                                $ssizes .= '0';
                            }
                        }
                        $countdown->{$field_name} = $ssizes;
                    } elseif ($field_name == 'schedule' && Tools::isSubmit($field_name)) {
                        $countdown->{$field_name} = Tools::getValue($field_name);
                    } else {
                        if (Tools::isSubmit($field_name)
                            || (isset($field_data['is_checkbox']) && $field_data['is_checkbox'])
                        ) {
                            $countdown->{$field_name} = (is_array(Tools::getValue($field_name))
                                    ? implode(',', Tools::getValue($field_name))
                                    : trim(Tools::getValue($field_name)));
                        }
                    }
                }
            }

            // check the schedule data
            if ($countdown->type == 'schedule') {
                if (is_array($countdown->schedule)) {
                    $days = $this->getDaysOfWeek();
                    $tz = Configuration::get('PS_TIMEZONE');
                    $dt_current = new DateTime('now', new DateTimeZone($tz));

                    foreach ($countdown->schedule as $i => $day) {
                        if (!empty($day['on'])) {
                            $from_txt = $dt_current->format('Y-m-d') . ' ' . $day[0];
                            $from_dt = new DateTime($from_txt, new DateTimeZone($tz));
                            $to_txt = $dt_current->format('Y-m-d') . ' ' . $day[1];
                            $to_dt = new DateTime($to_txt, new DateTimeZone($tz));
                            if ($to_dt <= $from_dt) {
                                $this->errors[] = $this->l('The end time must be after the start time') . ' (' . $days[$i] . ')';
                            }
                        }
                    }
                }
            }

            // set the banner status
            if (Tools::getIsset('active')) {
                $countdown->active = Tools::getValue('active');
            }

            if (Tools::isSubmit('save_and_enable') && $id_countdown) {
                $countdown->active = 1;
            }

            // Check for errors
            $field_errors = $countdown->validateAllFields();
            // Save if no errors
            $save_success = false;
            if (!(is_array($field_errors) && count($field_errors))) {
                if ($countdown->save()) {
                    $settings_updated = true;
                    $save_success = $confirmation;
                }
            }

            if (!$save_success) {
                // Display errors if any
                if (is_array($field_errors) && count($field_errors)) {
                    foreach ($field_errors as $field_error) {
                        $html .= $this->displayError($field_error);
                    }
                }
            } else {
                // Countdown saved
                $id_countdown = $countdown->id;
                $id_lang_default = Configuration::get('PS_LANG_DEFAULT');
                // set customer groups
                $countdown->setGroups(Tools::getValue('groups'));
                // Upload files:
                foreach (PstBannerCountdownItem::$definition['fields'] as $field_name => $field_data) {
                    if (isset($field_data['file']) && $field_data['file']) {
                        $lang_uploads = [];
                        foreach (Language::getLanguages() as $lang) {
                            if (isset($_FILES[$field_name]) && is_array($_FILES[$field_name])) {
                                $filename = $countdown->id . '-' . $lang['id_lang']
                                    . '-' . uniqid() . '-' . $field_name;
                                $upload_result = $this->uploadImage(
                                    $field_name,
                                    _PS_MODULE_DIR_ . $this->name . '/upload/',
                                    $filename,
                                    $countdown->{$field_name},
                                    $lang['id_lang']
                                );

                                if ($upload_result !== null) {
                                    $lang_uploads[] = $lang['id_lang'];
                                    if (is_string($upload_result)) {
                                        $countdown->{$field_name}[$lang['id_lang']] = $upload_result;
                                        $countdown->save();
                                    } elseif (is_array($upload_result)) {
                                        $this->errors = array_merge($this->errors, $upload_result);
                                    } else {
                                        $this->errors[] = $this->l('Unknown error while uploading images');
                                    }
                                }
                            }
                        }
                        if (count($lang_uploads)) {
                            foreach (Language::getLanguages() as $lang) {
                                if ($lang['id_lang'] != $id_lang_default
                                    && !in_array($lang['id_lang'], $lang_uploads)
                                    && $countdown->{$field_name}[$id_lang_default]
                                ) {
                                    $countdown->{$field_name}[$lang['id_lang']] =
                                        $countdown->{$field_name}[$id_lang_default];
                                }
                            }
                            $countdown->save();
                        }
                    }
                }
                // Save colors:
                $colors = Tools::getValue('colors');
                $id_colors = PstBannerCountdownColors::getIdByIdCountdownAndTheme($countdown->id, $countdown->theme);
                $colors_obj = new PstBannerCountdownColors($id_colors);
                $colors_obj->id_pstbannercountdown = $countdown->id;
                $colors_obj->theme = $countdown->theme;

                foreach ($this->getColorsData($countdown->theme) as $key => $data) {
                    if (isset($colors[$key])) {
                        $param = $data['param'];
                        $colors_obj->{$param} = $colors[$key];
                    }
                }

                $colors_obj->save();

                // shops
                if (Shop::isFeatureActive()) {
                    $selected_shops = [];
                    $countdown->active = $countdown->isActive();
                    foreach (Shop::getShops(false) as $shop) {
                        $id_shop = $shop['id_shop'];
                        $check = Tools::getValue('shops_' . $id_shop);
                        if ($check) {
                            $selected_shops[] = $id_shop;
                            Db::getInstance()->execute(
                                'INSERT INTO `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
                                 (`id_pstbannercountdown`, `id_shop`, `active`)
                                 VALUES
                                 (' . (int) $countdown->id . ', ' . (int) $id_shop . ', ' . (int) $countdown->active . ')
                                 ON DUPLICATE KEY UPDATE
                                  `active` = ' . (int) $countdown->active
                            );
                        }
                    }

                    Db::getInstance()->execute(
                        'DELETE FROM `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
                         WHERE `id_pstbannercountdown` = ' . (int) $countdown->id . ' ' .
                        ($selected_shops
                            ? ' AND `id_shop` NOT IN (' . implode(',', array_map('intval', $selected_shops)) . ')' : '')
                    );
                }
            }

            if (Tools::isSubmit('save_and_preview')) {
                $redirect_url = $this->getModuleConfigurationPageUrl([
                    'updatepstbannercountdown' => '1',
                    'id_pstbannercountdown' => $id_countdown,
                    'conf' => $confirmation,
                ]);
            }
        }

        if (Tools::isSubmit('deletepstbannercountdown')) {
            $id_countdown = Tools::getValue('id_pstbannercountdown');
            $countdown = new PstBannerCountdownItem($id_countdown);
            $countdown->delete();
            $settings_updated = true;
            $confirmation = 1;
        }

        if (Tools::isSubmit('submitBulkdeletepstbannercountdown')) {
            $banners = Tools::getValue('pstbannercountdownBox');
            foreach ($banners as $id_banner) {
                $banner = new PstBannerCountdownItem($id_banner);
                $banner->delete();
            }
            $settings_updated = true;
            $confirmation = 1;
        }

        if (Tools::isSubmit('remove_bg_image')) {
            $id_countdown = Tools::getValue('remove_bg_image');
            $countdown = new PstBannerCountdownItem($id_countdown);
            @unlink(_PS_MODULE_DIR_ . $this->name . '/upload/' . $countdown->bg_image);
            if (is_array($countdown->bg_image)) {
                foreach ($countdown->bg_image as &$item) {
                    $item = '';
                }
            } else {
                $countdown->bg_image = '';
            }
            $countdown->save();
            $settings_updated = true;
            $confirmation = 1;
            $redirect_url = $this->getModuleConfigurationPageUrl([
                'updatepstbannercountdown' => '1',
                'id_pstbannercountdown' => $id_countdown,
                'conf' => $confirmation,
            ]);
        }

        if (Tools::isSubmit('remove_image')) {
            $id_block = Tools::getValue('remove_image');
            $block = new PstBannerCountdownBlock($id_block);
            @unlink(_PS_MODULE_DIR_ . $this->name . '/upload/' . $block->image);
            if (is_array($block->image)) {
                foreach ($block->image as &$item) {
                    $item = '';
                }
            } else {
                $block->image = '';
            }
            $block->save();
            $settings_updated = true;
            $confirmation = 1;
            $redirect_url = $this->getModuleConfigurationPageUrl([
                'updatepstbannercountdown' => '1',
                'id_pstbannercountdown' => $block->id_pstbannercountdown,
                'conf' => $confirmation,
            ]);
        }

        $this->loadSettings();

        // regen custom css
        if ($settings_updated) {
            $this->regenerateCSS();
        }

        if ($settings_updated && !sizeof($this->errors)) {
            if (!$redirect_url) {
                $redirect_url = $this->getModuleConfigurationPageUrl([
                    'conf' => $confirmation,
                ]);
            }
            Tools::redirectAdmin($redirect_url);
        } elseif (sizeof($this->errors)) {
            foreach ($this->errors as $err) {
                $html .= $this->displayError($err);
            }
        }

        return $html;
    }

    protected function renderForm($title, $settings, $form_name = 'Module')
    {
        $field_forms = [
            [
                'form' => [
                    'legend' => [
                        'title' => $title,
                        'icon' => 'icon-cogs',
                    ],
                    'input' => $settings,
                    'submit' => [
                        'title' => $this->l('Save'),
                    ],
                ],
            ],
        ];

        $helper = $this->createFormHelper($field_forms, $form_name);

        foreach ($settings as $item) {
            if ($item['type'] == 'html') {
                continue;
            }
            if (isset($item['lang']) && $item['lang']) {
                foreach (Language::getLanguages() as $language) {
                    $val = Configuration::get($this->settings_prefix . $item['name'], $language['id_lang']);
                    $helper->tpl_vars['fields_value'][$item['name']][$language['id_lang']] =
                        Tools::getValue($item['name'] . '_' . $language['id_lang'], $val);
                }
            } elseif ($item['type'] == 'colors') {
                foreach ($this->getColorsData() as $i => $color) {
                    $val = Configuration::get($this->settings_prefix . $item['name'] . '_' . $i);
                    $helper->tpl_vars['fields_value'][$item['name']][$i] =
                        Tools::getValue($item['name'] . '_' . $i, $val);
                }
            } else {
                $val = Configuration::get($this->settings_prefix . $item['name']);
                $helper->tpl_vars['fields_value'][$item['name']] = $val;
            }
            if ($item['name'] == 'CUSTOM_CSS') {
                $helper->tpl_vars['fields_value'][$item['name']] = html_entity_decode(
                    Configuration::get($this->settings_prefix . $item['name'])
                );
            }
        }

        return $helper->generateForm($field_forms);
    }

    protected function renderItemForm($title, $settings, $form_name = 'pstbannercountdown', $after_content = '', $item = null)
    {
        foreach ($settings as $key => $option) {
            if ($option['type'] == 'file') {
                if (Validate::isLoadedObject($item) && $item->{$option['name']}) {
                    if (isset($option['lang']) && $option['lang']) {
                        $settings[$key]['files'] = [];
                        foreach (Language::getLanguages() as $lang) {
                            if ($item->{$option['name']}[$lang['id_lang']]) {
                                $settings[$key]['files'][$lang['id_lang']] = [
                                    'image' => $this->_path . 'upload/' . $item->{$option['name']}[$lang['id_lang']],
                                    'type' => 'image',
                                    'delete_url' => $this->getModuleConfigurationPageUrl([
                                        'remove_' . $option['name'] => $item->id,
                                    ]),
                                ];
                            }
                        }
                    } else {
                        $settings[$key]['files'] = [
                            [
                                'image' => $this->_path . 'upload/' . $item->{$option['name']},
                                'type' => 'image',
                                'delete_url' => $this->getModuleConfigurationPageUrl([
                                    'remove_' . $option['name'] => $item->id,
                                ]),
                            ],
                        ];
                    }
                }
            }
        }

        $main_url = $this->getModuleConfigurationPageUrl();
        $field_forms = [
            [
                'form' => [
                    'legend' => [
                        'title' => $title,
                        'icon' => 'icon-cogs',
                    ],
                    'input' => $settings,
                    'submit' => [
                        'title' => $this->l('Save'),
                    ],
                    'after_content' => $after_content,
                    'buttons' => [
                        'save_and_preview' => [
                            'name' => 'save_and_preview',
                            'type' => 'submit',
                            'title' => $this->l('Save and stay'),
                            'class' => 'btn btn-default pull-right',
                            'icon' => 'process-icon-save',
                        ],
                        'back' => [
                            'name' => 'back',
                            'href' => $main_url,
                            'title' => $this->l('Back to list'),
                            'class' => 'btn btn-default pull-left',
                            'icon' => 'process-icon-back',
                        ],
                    ],
                ],
            ],
        ];

        if (Validate::isLoadedObject($item)) {
            $tz = Configuration::get('PS_TIMEZONE');
            $dt_to = new DateTime($item->to, new DateTimeZone($tz));
            $dt_to->setTimezone(new DateTimeZone('UTC'));
            $dt_from = new DateTime($item->from, new DateTimeZone($tz));
            $dt_from->setTimezone(new DateTimeZone('UTC'));
            $dt_current = new DateTime('now', new DateTimeZone('UTC'));
            if ($dt_from < $dt_current && $dt_to >= $dt_current) {
                $field_forms[0]['form']['buttons']['preview'] = [
                    'name' => 'preview',
                    'type' => 'button',
                    'title' => $this->l('Preview'),
                    'class' => 'btn btn-default pull-right pbc-btn-preview',
                    'icon' => 'process-icon-preview',
                    'target' => '_blank',
                    'href' => $this->getBaseUrl() . ($item->active == 1 ? '' : '?banner_preview=1'),
                ];
            }
        }

        if (Validate::isLoadedObject($item) && Tools::getIsset('from_preset')) {
            $field_forms[0]['form']['buttons']['cancel'] = [
                'name' => 'cancel',
                'href' => $main_url . '&deletepstbannercountdown=1&id_pstbannercountdown=' . $item->id,
                'title' => $this->l('Cancel creation'),
                'class' => 'btn btn-danger pull-left pbc-btn-cancel-banner',
                'icon' => 'process-icon-delete',
            ];
        }

        // customer groups
        $this->context->smarty->assign([
            'pbc_groups' => Group::getGroups($this->context->language->id),
        ]);

        $helper = $this->createFormHelper($field_forms, $form_name, $item);

        $colors_obj = null;
        if (Validate::isLoadedObject($item) && $item->id) {
            $id_colors = PstBannerCountdownColors::getIdByIdCountdownAndTheme($item->id, $item->theme);
            if ($id_colors) {
                $colors_obj = new PstBannerCountdownColors($id_colors);
            }
        }
        $this->context->smarty->assign([
            'current_theme' => '1-simple',
        ]);
        foreach ($settings as $option) {
            if ($option['type'] == 'colors') {
                foreach ($this->getColorsData(null, $item) as $i => $color) {
                    // Ensure that $helper->tpl_vars['fields_value'][$option['name']] is an array
                    if (!isset($helper->tpl_vars['fields_value'][$option['name']]) || !is_array($helper->tpl_vars['fields_value'][$option['name']])) {
                        $helper->tpl_vars['fields_value'][$option['name']] = [];
                    }
                    if (Validate::isLoadedObject($colors_obj) && $color['theme'] . '.css' == $colors_obj->theme) {
                        $param = $color['param'];
                        $helper->tpl_vars['fields_value'][$option['name']][$i] = $colors_obj->{$param};
                    } else {
                        $helper->tpl_vars['fields_value'][$option['name']][$i] = $color['default'];
                    }
                }
            } elseif ($option['name'] == 'groups') {
                if (Validate::isLoadedObject($item)) {
                    $helper->tpl_vars['fields_value'][$option['name']] = $item->getGroups();
                    $helper->tpl_vars['fields_value']['all_groups'] = $item->all_groups;
                } else {
                    $helper->tpl_vars['fields_value']['all_groups'] = true;
                }
            } elseif ($option['name'] == 'screen_sizes' && Validate::isLoadedObject($item) && $item->screen_sizes) {
                foreach ($this->getScreenSizeList() as $key => $size) {
                    $helper->tpl_vars['fields_value'][$option['name'] . '_' . $size['id_option']] =
                        (int) $item->screen_sizes[$key];
                }
            } elseif ($option['name'] == 'screen_sizes' && !Validate::isLoadedObject($item)) {
                foreach ($this->getScreenSizeList() as $key => $size) {
                    $helper->tpl_vars['fields_value'][$option['name'] . '_' . $size['id_option']] = 1;
                }
            } elseif ($option['name'] == 'shops') {
                if (Validate::isLoadedObject($item)) {
                    $banner_shops = $item->getShops(false);
                    foreach (Shop::getShops() as $shop) {
                        if (in_array($shop['id_shop'], $banner_shops)) {
                            $helper->tpl_vars['fields_value'][$option['name'] . '_' . $shop['id_shop']] =
                                $shop['id_shop'];
                        }
                    }
                } else {
                    foreach (Shop::getShops() as $shop) {
                        $helper->tpl_vars['fields_value'][$option['name'] . '_' . $shop['id_shop']] = $shop['id_shop'];
                    }
                }
            } elseif (isset($option['default']) && !$helper->tpl_vars['fields_value'][$option['name']]) {
                $helper->tpl_vars['fields_value'][$option['name']] = $option['default'];
            }
        }

        return $helper->generateForm($field_forms);
    }

    protected function renderBlockForm($title, $settings, $form_name = 'pstbannercountdown_block', $after_content = '', $item = null, $id_pstbannercountdown = null)
    {
        foreach ($settings as $key => $option) {
            if ($option['type'] == 'file') {
                if (Validate::isLoadedObject($item) && $item->{$option['name']}) {
                    if (isset($option['lang']) && $option['lang']) {
                        $settings[$key]['files'] = [];
                        foreach (Language::getLanguages() as $lang) {
                            if ($item->{$option['name']}[$lang['id_lang']]) {
                                $settings[$key]['files'][$lang['id_lang']] = [
                                    'image' => $this->_path . 'upload/' . $item->{$option['name']}[$lang['id_lang']],
                                    'type' => 'image',
                                    'delete_url' => $this->getModuleConfigurationPageUrl([
                                        'remove_' . $option['name'] => $item->id,
                                    ]),
                                ];
                            }
                        }
                    } else {
                        $settings[$key]['files'] = [
                            [
                                'image' => $this->_path . 'upload/' . $item->{$option['name']},
                                'type' => 'image',
                                'delete_url' => $this->getModuleConfigurationPageUrl([
                                    'remove_' . $option['name'] => $item->id,
                                ]),
                            ],
                        ];
                    }
                }
            }
        }

        $field_forms = [
            'form' => [
                'form' => [
                    'legend' => [
                        'title' => $title,
                        'icon' => 'icon-cogs',
                    ],
                    'id_form' => (!$item ? 'pbc-new-block-form' : 'pbc-edit-block-form'),
                    'input' => $settings,
                    'submit' => [
                        'title' => $this->l('Save'),
                    ],
                    'after_content' => $after_content,
                ],
            ],
        ];

        $helper = $this->createFormHelper($field_forms, $form_name, $item);

        foreach ($settings as &$s_item) {
            if ($s_item['name'] == 'id_pstbannercountdown' && !$helper->tpl_vars['fields_value'][$s_item['name']]) {
                $helper->tpl_vars['fields_value'][$s_item['name']] = $id_pstbannercountdown;
            } elseif ($s_item['name'] == 'width') {
                if (!$helper->tpl_vars['fields_value'][$s_item['name']]) {
                    $helper->tpl_vars['fields_value'][$s_item['name']] = 12;
                }
                $mobile_name = $s_item['name'] . '_mobile';
                if (Validate::isLoadedObject($item)) {
                    $helper->tpl_vars['fields_value'][$mobile_name] = $item->{$mobile_name};
                } else {
                    $helper->tpl_vars['fields_value'][$mobile_name] = '';
                }
            } elseif ($s_item['type'] == 'block_select_responsive') {
                $mobile_name = $s_item['name'] . '_mobile';
                if (Validate::isLoadedObject($item)) {
                    $helper->tpl_vars['fields_value'][$mobile_name] = $item->{$mobile_name};
                } else {
                    $helper->tpl_vars['fields_value'][$mobile_name] = '';
                }
            } elseif ($s_item['name'] == 'products' && Validate::isLoadedObject($item)) {
                $helper->tpl_vars['fields_value'][$s_item['name']] = $item->getProducts();
            }
        }

        return $helper->generateForm($field_forms);
    }

    public function getSettings()
    {
        $settings = [
            [
                'type' => 'textarea',
                'name' => 'CUSTOM_CSS',
                'label' => $this->l('Custom CSS:'),
                'hint' => $this->l('You can add your styles directly into this field without editing files'),
                'validate' => 'isCleanHtml',
                'resize' => true,
                'cols' => '',
                'rows' => '',
            ],
        ];

        if ($this->getPSVersion() < 1.6) {
            foreach ($settings as &$item) {
                $desc = isset($item['desc']) ? $item['desc'] : '';
                $hint = isset($item['hint']) ? $item['hint'] . '<br/>' : '';
                $item['desc'] = $hint . $desc;
                $item['hint'] = '';
            }
        }

        return $settings;
    }

    protected function loadSettings()
    {
        foreach ($this->getSettings() as $item) {
            if ($item['type'] == 'html') {
                continue;
            }

            $name = Tools::strtolower($item['name']);
            if (isset($item['lang']) && $item['lang']) {
                $this->$name = [];
                foreach (Language::getLanguages() as $language) {
                    $this->{$name}[$language['id_lang']] = Configuration::get(
                        $this->settings_prefix . $item['name'],
                        $language['id_lang']
                    );
                }
            } else {
                $this->$name = Configuration::get(
                    $this->settings_prefix .
                    $item['name']
                );
            }
        }
    }

    public function getPSVersion($without_dots = false)
    {
        $ps_version = _PS_VERSION_;
        $ps_version = Tools::substr($ps_version, 0, 3);

        if ($without_dots) {
            if ($ps_version >= 8) {
                $ps_version = explode('.', $ps_version)[0];
            }
            $ps_version = str_replace('.', '', $ps_version);
        }

        return (float) $ps_version;
    }

    public function hookHeader()
    {
        // Add JQuery
        if (version_compare(_PS_VERSION_, '1.7.7', '<')) {
            $this->context->controller->addJquery();
        }

        // Register JS
        $this->context->controller->addJS(
            [
                $this->_path . 'views/js/underscore.min.js',
                $this->_path . 'views/js/jquery.countdown.min.js',
                $this->_path . 'views/js/front.js',
            ]
        );

        // Register CSS
        $this->context->controller->addCSS($this->_path . 'views/css/front.css');
        if ($this->getPSVersion() < 1.6) {
            $this->context->controller->addCSS($this->_path . 'views/css/grid.css');
        }
        $css_time = Configuration::getGlobalValue($this->settings_prefix . 'CSS_SAVED');
        $settings_css = $this->_path . 'views/css/settings-' . $css_time . '.css';
        $this->context->controller->addCSS($settings_css);

        $banners = PstBannerCountdownItem::getBannersFront();

        // Register theme CSS
        foreach ($banners as $banner) {
            $this->context->controller->addCSS(
                $this->_path . 'views/css/themes/' . basename($banner->theme)
            );
        }

        $this->context->smarty->assign([
            'psv' => $this->getPSVersion(),
            'pbc_ajax_url' => $this->context->link->getModuleLink($this->name, 'ajax'),
            'pbc_static_token' => Tools::getToken(false),
        ]);

        return $this->display(__FILE__, 'header.tpl');
    }

    public function hookPstBannerCountdown($params)
    {
        $this->context->smarty->assign($this->getWidgetVariables(null, $params));

        return $this->display(__FILE__, 'countdown.tpl');
    }

    public function hookDisplayBanner($params)
    {
        $params['hook'] = ['displayBanner', 'displayTopSticky'];

        return $this->hookPstBannerCountdown($params);
    }

    public function hookDisplayHome($params)
    {
        $params['hook'] = 'displayHome';

        return $this->hookPstBannerCountdown($params);
    }

    public function hookDisplayLeftColumn($params)
    {
        $params['hook'] = 'displayLeftColumn';

        return $this->hookPstBannerCountdown($params);
    }

    public function hookDisplayRightColumn($params)
    {
        $params['hook'] = 'displayRightColumn';

        return $this->hookPstBannerCountdown($params);
    }

    public function hookDisplayFooter($params)
    {
        $params['hook'] = ['displayFooter', 'displayTopSticky2'];
        $result = $this->hookPstBannerCountdown($params);

        $params['hook'] = 'custom';
        $params['pbc_custom_display'] = true;
        $result .= $this->hookPstBannerCountdown($params);

        return $result;
    }

    public function hookDisplayAfterBodyOpeningTag($params)
    {
        $params['hook'] = ['displayAfterBodyOpeningTag', 'displayTopSticky3'];

        return $this->hookPstBannerCountdown($params);
    }

    public function hookDisplayBeforeBodyClosingTag($params)
    {
        $params['hook'] = ['displayBeforeBodyClosingTag', 'displayFooterSticky2'];

        return $this->hookPstBannerCountdown($params);
    }

    public function hookDisplayTop($params)
    {
        $params['hook'] = 'displayTop';

        return $this->hookPstBannerCountdown($params);
    }

    public function hookDisplayMaintenance($params)
    {
        $banners = PstBannerCountdownItem::getBannersFront('displayMaintenance');
        $html = '';

        if (count($banners)) {
            // getJqueryPath() doesn't exist in PS 8, but Jquery is not loaded without it
            if (is_callable(['Media', 'getJqueryPath'])) {
                $js = Media::getJqueryPath();
            } else {
                $js = [];
                $jquery_path = $this->getJqueryPath();
                if ($jquery_path) {
                    $js[] = $jquery_path;
                }
            }
            $js[] = $this->_path . 'views/js/underscore.min.js';
            $js[] = $this->_path . 'views/js/jquery.countdown.min.js';
            $js[] = $this->_path . 'views/js/front.js';

            $css = null;
            if ($this->getPSVersion() <= 1.6) {
                $css = [
                    $this->_path . 'views/css/front.css',
                    $this->_path . 'views/css/grid.css',
                    $this->_path . 'views/css/settings.css',
                ];
                foreach ($banners as $banner) {
                    $css[] = $this->_path . 'views/css/themes/' . basename($banner->theme);
                }
            }

            $this->context->smarty->assign([
                'pbc_maintenance_js' => $js,
                'pbc_maintenance_css' => $css,
            ]);

            $html .= $this->hookHeader();
            $params['hook'] = 'displayMaintenance';
            $html .= $this->hookPstBannerCountdown($params);
        }

        return $html;
    }

    protected function getJqueryPath()
    {
        // Define the jQuery file we're looking for
        $specificFile = 'jquery-3.5.1.min.js';
        // Specify the path to the directory where the jQuery files are located
        $directory = _PS_ROOT_DIR_ . '/js/jquery/';
        $web_directory = _PS_JS_DIR_ . 'jquery/';

        // Check if the specific file exists
        if (file_exists($directory . '/' . $specificFile)) {
            return $web_directory . '/' . $specificFile;
        } else {
            // Initialize variable to store the latest jQuery version found
            $latestJqueryFile = null;
            $latestVersion = '0.0.0';

            // Open the specified directory
            $dirHandle = opendir($directory);
            if ($dirHandle) {
                // Loop through the files in the directory
                while (($file = readdir($dirHandle)) !== false) {
                    // Check if the file is a minified jQuery file and extract the version
                    if (preg_match('/jquery-(\d+\.\d+\.\d+)\.min\.js$/', $file, $matches)) {
                        $version = $matches[1];
                        // Use version_compare to check if this version is newer than the latest found
                        if (version_compare($version, $latestVersion, '>')) {
                            $latestVersion = $version;
                            $latestJqueryFile = $file;
                        }
                    }
                }
                // Close the directory handle
                closedir($dirHandle);
            }

            // If a latest jQuery file was found, use it
            if ($latestJqueryFile) {
                return $web_directory . '/' . $latestJqueryFile;
            }
        }

        // If nothing found
        return false;
    }

    public function hookDisplayFooterProduct($params)
    {
        $params['hook'] = 'displayFooterProduct';

        return $this->hookPstBannerCountdown($params);
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        if (Tools::getValue('configure') == $this->name) {
            if (version_compare(_PS_VERSION_, '1.7.3.0', '<') || !$this->active) {
                $this->hookActionAdminControllerSetMedia($params);
            }

            $ajax_url = $this->getModuleConfigurationPageUrl();

            $this->context->smarty->assign([
                'psv' => $this->getPSVersion(),
                'pbc_ajax_url' => $ajax_url,
                'pbc_upload_uri' => $this->_path . 'upload/',
            ]);

            return $this->context->smarty->fetch($this->local_path . 'views/templates/hook/admin_header.tpl');
        }
    }

    public function hookActionAdminControllerSetMedia($params)
    {
        if (Tools::getValue('configure') == $this->name) {
            if (version_compare(_PS_VERSION_, '1.7.7', '<')) {
                $this->context->controller->addJquery();
            }
            $this->context->controller->addCSS([
                $this->_path . 'views/css/flatpickr.min.css',
                $this->_path . 'views/css/jquery.spectrum.css',
                $this->_path . 'views/css/jquery.modal.min.css',
                $this->_path . 'views/css/admin.css',
            ]);

            if ($this->getPSVersion() == 1.5) {
                $this->context->controller->addCSS($this->_path . 'views/css/grid.css');
                $this->context->controller->addJS(_PS_JS_DIR_ . 'tiny_mce/tiny_mce.js');
                $this->context->controller->addJS(_PS_JS_DIR_ . 'tinymce.inc.js');
            }

            $this->context->controller->addJqueryUI('ui.sortable');
            $this->context->controller->addJqueryUI('ui.slider');
            $this->context->controller->addJS(_PS_JS_DIR_ . 'tiny_mce/tiny_mce.js');
            $this->context->controller->addJS(_PS_JS_DIR_ . 'admin/tinymce.inc.js');
            $this->context->controller->addJS([
                $this->_path . 'views/js/flatpickr.min.js',
                $this->_path . 'views/js/confirmDate.js',
                $this->_path . 'views/js/jquery.spectrum.min.js',
                $this->_path . 'views/js/jquery.autocomplete.min.js',
                $this->_path . 'views/js/jquery.modal.js',
                $this->_path . 'views/js/admin.js',
            ]);
        }
    }

    protected function renderItems()
    {
        $this->context->smarty->assign([
            'preTable' => $this->renderNewItemButton(),
            'psv' => $this->getPSVersion(),
            'form_id' => 'pstbannercountdown',
        ]);

        return $this->renderItemsList();
    }

    protected function renderNewItemButton()
    {
        $form_url = $this->getModuleConfigurationPageUrl([
            'createNewCountdown' => '1',
        ]);

        $banners_count = (int) Db::getInstance()->getValue(
            'SELECT COUNT(`id_pstbannercountdown`)
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
             WHERE `id_shop` IN (' . implode(',', array_map('intval', Shop::getContextListShopID())) . ')'
        );

        $banners = PstBannerCountdownItem::getAllBO();

        $presets = [
            'none' => [
                'name' => $this->l('None'),
                'desc' => $this->l('Create a banner from scratch.'),
            ],
            'top_banner' => [
                'name' => $this->l('Top banner'),
                'desc' => $this->l('Low height banner with short promo text and simple background.'),
            ],
            'homepage' => [
                'name' => $this->l('Homepage banner'),
                'desc' => $this->l('Timer and text over large image.'),
            ],
            'products' => [
                'name' => $this->l('Banner with products'),
                'desc' => $this->l('A few products and a timer. You can select products at the next step.'),
            ],
            'clone' => [
                'name' => $this->l('Clone existing banner'),
                'desc' => '',
            ],
        ];

        $this->context->smarty->assign([
            'form_url' => $form_url,
            'psv' => $this->getPSVersion(),
            'psvd' => $this->getPSVersion(true),
            'banners_count' => $banners_count,
            'pbc_source_banners' => $banners,
            'pbc_presets' => $presets,
        ]);

        return $this->context->smarty->fetch($this->local_path . 'views/templates/admin/new.tpl');
    }

    protected function renderItemsList()
    {
        $table = 'pstbannercountdown';
        $helper = $this->createListHelper($table);
        $helper->actions = ['edit', 'delete'];
        $helper->title = $this->l('Countdown timers');

        $fields_list = [
            'id_pstbannercountdown' => [
                'title' => $this->l('ID'),
                'type' => 'text',
                'class' => 'fixed-width-xs',
                'search' => false,
                'orderby' => true,
            ],
            'system_name' => [
                'title' => $this->l('Name'),
                'type' => 'text',
                'search' => false,
                'orderby' => true,
            ],
            'hook_name' => [
                'title' => $this->l('Position'),
                'type' => 'text',
                'search' => false,
                'orderby' => true,
                'badges' => ['category', 'groups'],
            ],
            'from' => [
                'title' => $this->l('From'),
                'type' => 'text',
                'search' => false,
                'orderby' => true,
            ],
            'to' => [
                'title' => $this->l('To'),
                'type' => 'text',
                'search' => false,
                'orderby' => true,
                'badges' => ['restart'],
            ],
            'active' => [
                'title' => $this->l('Status'),
                'type' => 'status',
                'search' => false,
                'orderby' => true,
                'remove_onclick' => true,
                'badges' => ['schedule'],
            ],
        ];

        // if multishop
        if (Shop::isFeatureActive()) {
            $fields_list['shops'] = [
                'title' => $this->l('Shops'),
                'type' => 'text',
                'search' => false,
                'orderby' => false,
            ];
        }

        $content = $this->getItemsBO($helper->page, $helper->n, $helper->orderBy, $helper->orderWay);
        foreach ($content as &$row) {
            if (Shop::isFeatureActive()) {
                $shops = PstBannerCountdownItem::getShopsStatic($row['id_pstbannercountdown'], false);
                $shops_names = [];
                foreach ($shops as $id_shop) {
                    $shops_names[] = $this->getShopName($id_shop);
                }
                $row['shops'] = implode(', ', $shops_names);
            }

            if ($row['type'] == 'schedule') {
                $row['from'] = $row['from_schedule'];
                $row['to'] = $row['to_schedule'];
            }
        }
        $helper->listTotal = $this->getListTotal();

        return $helper->generateList($content, $fields_list);
    }

    public function getItemsBO($page = 1, $n = 20, $order_by = null, $order_way = null)
    {
        $order_by_replace = [
            'from' => '`from`',
            'to' => '`to`',
        ];
        if ($order_by && isset($order_by_replace[$order_by])) {
            $order_by = $order_by_replace[$order_by];
        }
        $query =
            'SELECT *,
              IF(p.`from` > UTC_TIMESTAMP(), "-1", IF(p.`to` < UTC_TIMESTAMP(), "-2", ps.`active`)) as `active`,
              ps.`active` AS `active_orig`
			 FROM `' . _DB_PREFIX_ . 'pstbannercountdown` p
			 LEFT JOIN `' . _DB_PREFIX_ . 'pstbannercountdown_shop` ps USING (`id_pstbannercountdown`)
			 WHERE 1
             GROUP BY p.`id_pstbannercountdown`';
        if ($order_by == 'active') {
            $query .= ' ORDER BY `active` ' . pSQL($order_way) . ', `from` ' . pSQL($order_way) . ', `to` ' . pSQL($order_way);
        } elseif ($order_by == 'hook_name') {
            $query .= ' ORDER BY `hook` ' . pSQL($order_way) . ', `priority` ' . pSQL($order_way);
        } else {
            $query .= ' ORDER BY ' . ($order_by && $order_way ? pSQL($order_by) . ' ' . pSQL($order_way) : ' p.`id_pstbannercountdown` ');
        }
        $query .= ' LIMIT ' . (((int) $page - 1) * (int) $n) . ', ' . (int) $n;
        $items = Db::getInstance()->executeS($query);

        $hooks = $this->getHookList(true);
        foreach ($items as &$item) {
            $date_props = ['from', 'to', 'from_schedule', 'to_schedule'];
            foreach ($date_props as $prop) {
                if ($item[$prop] && strtotime($item[$prop]) > 0) {
                    $dt = new DateTime($item[$prop], new DateTimeZone('UTC'));
                    $dt->setTimezone(new DateTimeZone(Configuration::get('PS_TIMEZONE')));
                    $item[$prop] = $dt->format('Y-m-d H:i:s');
                } else {
                    $item[$prop] = '';
                }
            }

            foreach ($hooks as $hook) {
                if ($hook['id_option'] == $item['hook']) {
                    $item['hook_name'] = $hook['name'];
                    $item['hook'] = $hook['name'];
                }
            }
        }

        return $items;
    }

    public function getListTotal()
    {
        return Db::getInstance()->getValue(
            'SELECT COUNT(`id_pstbannercountdown`)
             FROM `' . _DB_PREFIX_ . 'pstbannercountdown_shop`
             WHERE `id_shop` IN (' . implode(',', array_map('intval', Shop::getContextListShopID())) . ')'
        );
    }

    protected function createListHelper($table, $identifier = null)
    {
        if ($identifier === null) {
            $identifier = 'id_' . $table;
        }

        $this->context->cookie->{$table . '_pagination'} =
            Tools::getValue($table . '_pagination', $this->context->cookie->{$table . '_pagination'});
        if (!$this->context->cookie->{$table . '_pagination'}) {
            $this->context->cookie->{$table . '_pagination'} = 20;
        }

        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->identifier = $identifier;
        $helper->actions = [];
        $helper->show_toolbar = false;
        $helper->_defaultOrderBy = 'id_pstbannercountdown';
        $helper->list_id = $table;
        $helper->table_id = $table;
        $helper->actions = ['edit', 'delete'];
        $helper->table = $table;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->currentIndex = str_replace('adminmodules', 'AdminModules', $helper->currentIndex);
        $helper->no_link = false;
        $helper->tpl_vars = [
            'pbc_psv' => $this->getPSVersion(),
        ];
        $helper->bulk_actions = [
            'delete' => [
                'text' => $this->l('Delete selected'),
                'confirm' => $this->l('Delete selected items?'),
                'icon' => 'icon-trash',
            ],
        ];

        if (isset($this->context->cookie->{$helper->table . '_pagination'})
            && $this->context->cookie->{$helper->table . '_pagination'}) {
            $helper->_default_pagination = $this->context->cookie->{$helper->table . '_pagination'};
        } elseif ($this->getPSVersion() > 1.5) {
            $helper->_default_pagination = $helper->_pagination[0];
        } else {
            $helper->_default_pagination = 20;
        }
        $helper->module = $this;

        $order_way = Tools::strtolower(Tools::getValue($table . 'Orderway'));
        $order_way = ($order_way == 'desc' ? 'desc' : 'asc');
        $order_by = Tools::getValue($table . 'Orderby', 'id_pstbannercountdown');
        $helper->orderBy = $order_by;
        $helper->orderWay = Tools::strtoupper($order_way);
        $p = (int) Tools::getValue('submitFilter' . $table, Tools::getValue('page', 1));
        if ($p < 1) {
            $p = 1;
        }
        $helper->page = $p;

        $helper->n = Tools::getValue(
            $table . '_pagination',
            isset($this->context->cookie->{$table . '_pagination'}) ?
                $this->context->cookie->{$table . '_pagination'} :
                $helper->_default_pagination
        );

        if ($this->getPSVersion() == 1.5) {
            $this->context->smarty->assign([
                'list_id' => $helper->list_id,
            ]);
        }

        return $helper;
    }

    protected function createFormHelper(&$form_settings, $table, $item = null)
    {
        if ($this->getPSVersion() == 1.5) {
            foreach ($form_settings as &$form) {
                $form['form']['submit']['class'] = 'button';
            }
        }

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $table;
        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang =
            Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ?
                Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') :
                0;
        $this->fields_form = [];

        $helper->identifier = 'id_' . $table;
        $helper->submit_action = 'submit' . $table;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) .
            '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = [
            'fields_value' => [],
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
            'psvd' => $this->getPSVersion(true),
            'psv' => $this->getPSVersion(),
            'PS_ALLOW_ACCENTED_CHARS_URL' => Configuration::get('PS_ALLOW_ACCENTED_CHARS_URL'),
            'pbc_days' => $this->getDaysOfWeek(),
        ];
        $helper->module = $this;
        if (Validate::isLoadedObject($item) && $item->id) {
            $helper->id = $item->id;
        }

        $languages = Language::getLanguages();
        foreach ($form_settings as $form) {
            foreach ($form['form']['input'] as $row) {
                if ($row['type'] != 'html') {
                    if (Validate::isLoadedObject($item) && $item->id) {
                        if (property_exists($item, $row['name'])) {
                            $helper->tpl_vars['fields_value'][$row['name']] = $item->{$row['name']};
                            if (Tools::isSubmit($row['name'])) {
                                $helper->tpl_vars['fields_value'][$row['name']] = Tools::getValue($row['name']);
                            }
                        }
                        if (isset($row['addon'])) {
                            $addon = $row['addon'];
                            if (is_array($addon)) {
                                if (isset($addon['data']) && is_array($addon['data'])) {
                                    foreach ($addon['data'] as $property => $value) {
                                        if (property_exists($item, $property)) {
                                            $helper->tpl_vars['fields_value'][$property] = $item->{$property};
                                            if (Tools::isSubmit($property)) {
                                                $helper->tpl_vars['fields_value'][$property] = Tools::getValue($property);
                                            }
                                        }
                                    }
                                } elseif (isset($addon['options'])) {
                                    $property = $addon['name'];
                                    if (property_exists($item, $property)) {
                                        $helper->tpl_vars['fields_value'][$property] = $item->{$property};
                                        if (Tools::isSubmit($property)) {
                                            $helper->tpl_vars['fields_value'][$property] = Tools::getValue($property);
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        if (isset($row['lang']) && $row['lang']) {
                            foreach ($languages as $language) {
                                $helper->tpl_vars['fields_value'][$row['name']][$language['id_lang']] =
                                    Tools::getValue($row['name'] . '_' . $language['id_lang']);
                            }
                        } else {
                            $helper->tpl_vars['fields_value'][$row['name']] = Tools::getValue($row['name']);
                        }
                    }
                }
            }
        }

        $iso = $this->context->language->iso_code;
        $helper->tpl_vars['iso'] = file_exists(_PS_ROOT_DIR_ . '/js/tiny_mce/langs/' . $iso . '.js') ? $iso : 'en';
        $helper->tpl_vars['path_css'] = _THEME_CSS_DIR_;
        $helper->tpl_vars['ad'] = __PS_BASE_URI__ . basename(_PS_ADMIN_DIR_);
        $helper->tpl_vars['tinymce'] = true;

        return $helper;
    }

    protected function getItemFormFields($id_item = null)
    {
        $fields = [
            [
                'type' => $this->getPSVersion() == 1.5 ? 'radio' : 'switch',
                'name' => 'active',
                'label' => $this->l('Active:'),
                'hint' => $this->l('Enable this option to display the banner in Front Office'),
                'class' => 't',
                'values' => [
                    [
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes'),
                    ],
                    [
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No'),
                    ],
                ],
                'validate' => 'isInt',
            ],
            [
                'type' => 'text',
                'name' => 'system_name',
                'id' => 'system_name' . ($id_item ? $id_item : ''),
                'label' => $this->l('Name:'),
                'hint' => $this->l('Not required, only for convenience.'),
                'validate' => 'isCleanHtml',
                'required' => false,
            ],
            'hooks' => [
                'type' => 'select',
                'name' => 'hook',
                'class' => 't pstb-position-select',
                'id' => 'hook' . ($id_item ? $id_item : ''),
                'label' => $this->l('Position:'),
                'hint' => $this->l('Choose a hook for displaying this block. If you choose a custom hook, you need to insert it into your template manually.'),
                'desc' => $this->l('Please note that your theme may not support some hooks.'),
                'validate' => 'isCleanHtml',
                'options' => [
                    'query' => $this->getHookList(),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'addon' => [
                    'type' => 'select',
                    'name' => 'priority',
                    'id' => 'priority' . ($id_item ? $id_item : ''),
                    'class' => 't pstb-position-select fixed-width-xl',
                    'options' => [
                        'query' => $this->getPriorityOptionList(),
                        'id' => 'id_option',
                        'name' => 'name',
                    ],
                ],
                'required' => true,
            ],
        ];

        if (Shop::isFeatureActive()) {
            $fields[] = [
                'type' => 'checkbox',
                'name' => 'shops',
                'id' => 'shops' . ($id_item ? $id_item : ''),
                'label' => $this->l('Shops:'),
                'hint' => $this->l('Associate this banner with selected shops'),
                'validate' => 'isCleanHtml',
                'values' => [
                    'query' => $this->getShopList(),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'required' => false,
                'form_group_class' => 'ps' . $this->getPSVersion(true),
            ];
        }

        $selected_categories = [];
        if ($id_item) {
            $item = new PstBannerCountdownItem($id_item);
            if (Validate::isLoadedObject($item)) {
                $selected_categories = explode(',', $item->categories);
            }
        }

        $fields = array_merge($fields, [
            [
                'type' => 'text',
                'name' => 'link',
                'label' => $this->l('Link:'),
                'hint' => $this->l('Enter a link that will be opened on clicking this banner'),
                'validate' => 'isUrl',
                'lang' => true,
            ],
            [
                'type' => 'text',
                'name' => 'bg_color',
                'label' => $this->l('Background color:'),
                'hint' => $this->l('Background color of this block'),
                'class' => 'pbcColorPickerInput',
                'validate' => 'isString',
            ],
            'bg_img' => [
                'type' => 'file',
                'name' => 'bg_image',
                'label' => $this->l('Background image:'),
                'hint' => $this->l('Background image of this block'),
                'ajax' => false,
                'lang' => true,
                'default' => '',
                'validate' => 'isString',
            ],
            [
                'type' => 'html',
                'name' => '',
                'label' => '',
                'html_content' => $this->context->smarty->fetch(
                    $this->local_path . 'views/templates/admin/_more_options_btn.tpl'
                ),
            ],
            [
                'type' => 'select',
                'name' => 'width',
                'class' => 't',
                'id' => 'width' . ($id_item ? $id_item : ''),
                'label' => $this->l('Width:'),
                'hint' => $this->l('Width of this block'),
                'validate' => 'isCleanHtml',
                'options' => [
                    'query' => $this->getBlockWidthOptions(),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'required' => false,
                'default' => 12,
                'form_group_class' => 'pbc_more_options_row ps' . $this->getPSVersion(true),
            ],
            [
                'type' => $this->getPSVersion() == 1.5 ? 'radio' : 'switch',
                'name' => 'limit_width',
                'label' => $this->l('Limit content width:'),
                'hint' => $this->l('Limit content width and keep free space on the sides of the banner (will be used default content width). Usually applicable in the Top Banner and similar positions.'),
                'class' => 't',
                'values' => [
                    [
                        'id' => 'close_btn_on',
                        'value' => 1,
                        'label' => $this->l('Yes'),
                    ],
                    [
                        'id' => 'close_btn_off',
                        'value' => 0,
                        'label' => $this->l('No'),
                    ],
                ],
                'default' => 0,
                'validate' => 'isInt',
                'form_group_class' => 'pbc_more_options_row ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'text',
                'name' => 'height',
                'id' => 'height' . ($id_item ? $id_item : ''),
                'label' => $this->l('Minimum height:'),
                'hint' => $this->l('Leave empty to use auto height'),
                'validate' => 'isCleanHtml',
                'required' => false,
                'suffix' => 'px',
                'class' => 'fixed-width-xs',
                'form_group_class' => 'pbc_more_options_row ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'margin',
                'name' => 'margin',
                'id' => 'margin' . ($id_item ? $id_item : ''),
                'label' => $this->l('Margin, px:'),
                'hint' => $this->l('Margin around this block. You can use it for adding some space around this block. It can be negative for reduction of space around.'),
                'validate' => 'isCleanHtml',
                'required' => false,
                'form_group_class' => 'pbc_more_options_row ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'checkbox',
                'name' => 'screen_sizes',
                'id' => 'screen_sizes' . ($id_item ? $id_item : ''),
                'label' => $this->l('Screen sizes:'),
                'hint' => $this->l('Display this countdown only for chosen screen sizes.'),
                'validate' => 'isCleanHtml',
                'values' => [
                    'query' => $this->getScreenSizeList(),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'required' => false,
                'form_group_class' => 'pbc_more_options_row ps' . $this->getPSVersion(true),
            ],
            [
                'type' => $this->getPSVersion() == 1.5 ? 'radio' : 'switch',
                'name' => 'close_btn',
                'id' => 'close_btn' . ($id_item ? $id_item : ''),
                'label' => $this->l('Show close button:'),
                'hint' => $this->l('Show a close button for closing this banner. After clicking it the banner will be hidden for 24 hours for that particular customer.'),
                'class' => 't',
                'values' => [
                    [
                        'id' => 'close_btn_on',
                        'value' => 1,
                        'label' => $this->l('Yes'),
                    ],
                    [
                        'id' => 'close_btn_off',
                        'value' => 0,
                        'label' => $this->l('No'),
                    ],
                ],
                'default' => 0,
                'validate' => 'isInt',
                'form_group_class' => 'pbc_more_options_row ps' . $this->getPSVersion(true),
            ],
            'categories' => [
                'type' => 'categories',
                'name' => 'categories',
                'id' => 'categories' . ($id_item ? $id_item : ''),
                'label' => $this->l('Show only in these categories:'),
                'hint' => $this->l('Show this banner only in selected categories and their products. Uncheck to display everywhere.'),
                'required' => false,
                'validate' => 'isString',
                'tree' => [
                    'root_category' => $this->context->shop->id_category,
                    'id' => 'id_category',
                    'name' => 'categoryBox',
                    'selected_categories' => $selected_categories,
                    'use_checkbox' => true,
                ],
                'form_group_class' => 'pbc_more_options_row ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'groups',
                'name' => 'groups',
                'id' => 'groups' . ($id_item ? $id_item : ''),
                'label' => $this->l('Customer groups:'),
                'hint' => $this->l('Display this banner only to selected customer groups. Uncheck "All" to see the groups.'),
                'validate' => 'isString',
                'form_group_class' => 'pbc_more_options_row ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'textarea',
                'name' => 'custom_css',
                'id' => 'custom_css' . ($id_item ? $id_item : ''),
                'label' => $this->l('Custom CSS:'),
                'hint' => $this->l('You can add your styles directly into this field without editing files'),
                'validate' => 'isCleanHtml',
                'resize' => true,
                'cols' => '',
                'rows' => '',
                'form_group_class' => 'pbc_more_options_row last-row ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'select',
                'name' => 'type',
                'class' => 't',
                'id' => 'type' . ($id_item ? $id_item : ''),
                'label' => $this->l('Countdown type:'),
                'hint' => [
                    $this->l('Regular - standard countdown, works in selected date and time interval.'),
                    $this->l('On schedule - works on the selected days of the week at a specified time.'),
                ],
                'validate' => 'isCleanHtml',
                'options' => [
                    'query' => $this->getCountdownTypesOptions(),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'required' => true,
            ],
            [
                'type' => 'text',
                'name' => 'from',
                'id' => 'from' . ($id_item ? $id_item : ''),
                'label' => $this->l('From:'),
                'hint' => $this->l('Countdown start'),
                'validate' => 'isCleanHtml',
                'required' => false,
                'class' => 'fixed-width-xxl pbc_datepicker',
                'form_group_class' => 'pbc_type_sub_row pbc_regular_type_sub_row',
            ],
            [
                'type' => 'text',
                'name' => 'to',
                'id' => 'to' . ($id_item ? $id_item : ''),
                'label' => $this->l('To:'),
                'hint' => $this->l('Countdown end'),
                'validate' => 'isCleanHtml',
                'required' => true,
                'class' => 'fixed-width-xxl pbc_datepicker',
                'addon' => [
                    'type' => 'restart',
                    'id' => 'restart' . ($id_item ? $id_item : ''),
                    'data' => ['restart' => null, 'restart_hours' => null],
                ],
                'form_group_class' => 'pbc_type_sub_row pbc_regular_type_sub_row',
            ],
            [
                'type' => 'text',
                'name' => 'from_schedule',
                'id' => 'from_schedule' . ($id_item ? $id_item : ''),
                'label' => $this->l('From:'),
                'hint' => $this->l('Countdown start'),
                'validate' => 'isCleanHtml',
                'required' => false,
                'class' => 'fixed-width-xxl pbc_datepicker',
                'form_group_class' => 'pbc_type_sub_row pbc_schedule_type_sub_row',
            ],
            [
                'type' => 'text',
                'name' => 'to_schedule',
                'id' => 'to_schedule' . ($id_item ? $id_item : ''),
                'label' => $this->l('To:'),
                'hint' => $this->l('Countdown end'),
                'validate' => 'isCleanHtml',
                'required' => false,
                'class' => 'fixed-width-xxl pbc_datepicker',
                'form_group_class' => 'pbc_type_sub_row pbc_schedule_type_sub_row',
            ],
            [
                'type' => 'schedule',
                'name' => 'schedule',
                'id' => 'schedule' . ($id_item ? $id_item : ''),
                'label' => $this->l('Schedule:'),
                'hint' => [
                    $this->l('Specify the schedule for displaying the countdown. This option uses time zone from the store settings.'),
                    $this->l('The beginning of the day at 0:00, the end - 23:59.'),
                ],
                'validate' => 'isCleanHtml',
                'required' => true,
                'form_group_class' => 'pbc_type_sub_row pbc_schedule_type_sub_row',
            ],
            [
                'type' => 'theme',
                'name' => 'theme',
                'label' => $this->l('Countdown theme:'),
                'class' => 't',
                'values' => $this->getThemeOptions(),
                'default' => '1-simple.css',
                'validate' => 'isString',
                'required' => true,
            ],
            [
                'type' => 'html',
                'name' => '',
                'label' => '',
                'html_content' => $this->context->smarty->fetch(
                    $this->local_path . 'views/templates/admin/_countdown_appearance_btn.tpl'
                ),
            ],
            [
                'type' => 'colors',
                'name' => 'colors',
                'id' => 'colors' . ($id_item ? $id_item : ''),
                'label' => $this->l('Countdown colors:'),
                'default' => $this->getColorsData(),
                'colors_data' => $this->getColorsData(),
                'validate' => 'isString',
                'form_group_class' => 'countdown_appearance_row pbc_options_colors ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'font_size',
                'name' => 'font_size',
                'label' => $this->l('Size:'),
                'hint' => $this->l('You can change countdown size by changing this option'),
                'default' => '1',
                'validate' => 'isFloat',
                'form_group_class' => 'countdown_appearance_row pbc_options_size ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'text',
                'name' => 'border_radius',
                'id' => 'border_radius' . ($id_item ? $id_item : ''),
                'label' => $this->l('Border radius:'),
                'hint' => $this->l('Border radius of a countdown'),
                'validate' => 'isCleanHtml',
                'required' => false,
                'suffix' => 'px',
                'class' => 'fixed-width-xs',
                'form_group_class' => 'countdown_appearance_row pbc_options_brad ps' . $this->getPSVersion(true),
            ],
            [
                'type' => $this->getPSVersion() == 1.5 ? 'radio' : 'switch',
                'name' => 'compact_view',
                'label' => $this->l('Compact view:'),
                'hint' => $this->l('More compact view of a countdown.'),
                'class' => 't',
                'values' => [
                    [
                        'id' => 'compact_view_on',
                        'value' => 1,
                        'label' => $this->l('Yes'),
                    ],
                    [
                        'id' => 'compact_view_off',
                        'value' => 0,
                        'label' => $this->l('No'),
                    ],
                ],
                'default' => 0,
                'validate' => 'isInt',
                'form_group_class' => 'countdown_appearance_row pbc_options_compact ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'select',
                'name' => 'highlight_position',
                'class' => 't',
                'id' => 'highlight_position' . ($id_item ? $id_item : ''),
                'label' => $this->l('Highlight:'),
                'hint' => $this->l('Choose what part of a countdown should be highlighted (if applicable).'),
                'validate' => 'isCleanHtml',
                'options' => [
                    'query' => $this->getHighlightSelectOptions(),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'required' => false,
                'form_group_class' => 'countdown_appearance_row pbc_options_highlight ps' . $this->getPSVersion(true),
            ],
            [
                'type' => $this->getPSVersion() == 1.5 ? 'radio' : 'switch',
                'name' => 'show_colon',
                'label' => $this->l('Show colons:'),
                'class' => 't',
                'values' => [
                    [
                        'id' => 'show_colon_on',
                        'value' => 1,
                        'label' => $this->l('Yes'),
                    ],
                    [
                        'id' => 'show_colon_off',
                        'value' => 0,
                        'label' => $this->l('No'),
                    ],
                ],
                'hint' => $this->l('Show colons between digits'),
                'default' => 0,
                'validate' => 'isInt',
                'form_group_class' => 'countdown_appearance_row pbc_options_colon ps' . $this->getPSVersion(true),
            ],
            [
                'type' => 'text',
                'name' => 'promo_text',
                'id' => 'promo_text' . ($id_item ? $id_item : ''),
                'label' => $this->l('Promo text:'),
                'hint' => $this->l('The "Offer ends in" text'),
                'validate' => 'isCleanHtml',
                'required' => false,
                'lang' => true,
                'form_group_class' => 'countdown_appearance_row pbc_options_promo_text last-row ps' . $this->getPSVersion(true),
                'class' => 'pbc_promo_text',
            ],
            [
                'type' => $this->getPSVersion() == 1.5 ? 'radio' : 'switch',
                'name' => 'show_full_labels',
                'label' => $this->l('Show full names of time units:'),
                'class' => 't',
                'values' => [
                    [
                        'id' => 'show_full_labels_on',
                        'value' => 1,
                        'label' => $this->l('Yes'),
                    ],
                    [
                        'id' => 'show_full_labels_off',
                        'value' => 0,
                        'label' => $this->l('No'),
                    ],
                ],
                'hint' => $this->l('Show "seconds" instead of "sec", etc.'),
                'default' => 0,
                'validate' => 'isInt',
                'form_group_class' => 'countdown_appearance_row pbc_options_full_labels ps' . $this->getPSVersion(true),
            ],
            [
                'type' => $this->getPSVersion() == 1.5 ? 'radio' : 'switch',
                'name' => 'hide_zero_days',
                'label' => $this->l('Hide zero days:'),
                'class' => 't',
                'values' => [
                    [
                        'id' => 'hide_zero_days_on',
                        'value' => 1,
                        'label' => $this->l('Yes'),
                    ],
                    [
                        'id' => 'hide_zero_days_off',
                        'value' => 0,
                        'label' => $this->l('No'),
                    ],
                ],
                'default' => 0,
                'validate' => 'isInt',
                'form_group_class' => 'countdown_appearance_row pbc_options_zero_days ps' . $this->getPSVersion(true),
            ],
        ]);

        if ($this->getPSVersion() >= 1.7) {
            $fields['hooks'] = [
                'type' => 'select',
                'name' => 'hook',
                'class' => 't pstb-position-select',
                'id' => 'hook' . ($id_item ? $id_item : ''),
                'label' => $this->l('Position:'),
                'hint' => $this->l('Choose a hook for displaying this block. If you choose a custom hook, you need to insert it into your template manually.'),
                'validate' => 'isCleanHtml',
                'addon' => [
                    'type' => 'select',
                    'name' => 'priority',
                    'id' => 'priority' . ($id_item ? $id_item : ''),
                    'class' => 't pstb-position-select fixed-width-xl',
                    'options' => [
                        'query' => $this->getPriorityOptionList(),
                        'id' => 'id_option',
                        'name' => 'name',
                    ],
                ],
                'options' => [
                    'optiongroup' => [
                        'label' => 'name',
                        'query' => $this->getHookList(),
                    ],
                    'options' => [
                        'id' => 'id_option',
                        'name' => 'name',
                        'query' => 'query',
                    ],
                ],
                'required' => true,
            ];
        }

        if ($this->getPSVersion() < 1.6) {
            foreach ($fields as &$item) {
                $desc = isset($item['desc']) ? $item['desc'] : '';
                $hint = isset($item['hint']) ? $item['hint'] : '';
                if ($hint) {
                    $hint = (is_array($hint) ? implode(' ', $hint) : $hint) . '<br/>';
                }
                $item['desc'] = $hint . $desc;
                $item['hint'] = '';
            }

            // PS1.5 Category input
            $root_category = Category::getRootCategory();
            if (!$root_category->id) {
                $root_category->id = 0;
                $root_category->name = $this->l('Root');
            }
            $root_category = ['id_category' => (int) $root_category->id, 'name' => $root_category->name];
            $trads = [
                'Root' => $root_category,
                'selected' => $this->l('Selected'),
                'Check all' => $this->l('Check all'),
                'Check All' => $this->l('Check All'),
                'Uncheck All' => $this->l('Uncheck All'),
                'Collapse All' => $this->l('Collapse All'),
                'Expand All' => $this->l('Expand All'),
                'search' => $this->l('Search a category'),
            ];
            $fields['categories']['values'] = [
                'trads' => $trads,
                'selected_cat' => $selected_categories,
                'input_name' => 'categories[]',
                'use_radio' => false,
                'use_search' => false,
                'disabled_categories' => [],
                'top_category' => Category::getTopCategory(),
                'use_context' => true,
            ];
        }

        return $fields;
    }

    protected function getHookList($list = false)
    {
        $hooks = [
            [
                'id_option' => 'displayBanner',
                'name' => $this->l('Top banner'),
            ],
            [
                'id_option' => 'displayAfterBodyOpeningTag',
                'name' => '- ' . $this->l('Top banner') . ' ' . $this->l('(alternative hook)'),
            ],
            [
                'id_option' => 'displayHome',
                'name' => $this->l('Home page'),
            ],
            [
                'id_option' => 'displayLeftColumn',
                'name' => $this->l('Left column'),
            ],
            [
                'id_option' => 'displayRightColumn',
                'name' => $this->l('Right column'),
            ],
            [
                'id_option' => 'displayTop',
                'name' => $this->l('Top of the page'),
            ],
            [
                'id_option' => 'displayFooter',
                'name' => $this->l('Footer'),
            ],
            [
                'id_option' => 'displayBeforeBodyClosingTag',
                'name' => '- ' . $this->l('Footer') . ' ' . $this->l('(alternative hook)'),
            ],
            [
                'id_option' => 'displayFooterProduct',
                'name' => $this->l('Product footer'),
            ],
            [
                'id_option' => 'displayMaintenance',
                'name' => $this->l('Maintenance page'),
            ],
            [
                'id_option' => 'displayTopSticky',
                'name' => $this->l('Fixed at the top'),
            ],
            [
                'id_option' => 'displayTopSticky2',
                'name' => '- ' . $this->l('Fixed at the top') . ' ' . $this->l('(alternative hook)') . ' #1',
            ],
            [
                'id_option' => 'displayTopSticky3',
                'name' => '- ' . $this->l('Fixed at the top') . ' ' . $this->l('(alternative hook)') . ' #2',
            ],
            [
                'id_option' => 'displayFooterSticky',
                'name' => $this->l('Fixed at the bottom'),
            ],
            [
                'id_option' => 'displayFooterSticky2',
                'name' => '- ' . $this->l('Fixed at the bottom') . ' ' . $this->l('(alternative hook)') . ' #1',
            ],
            [
                'id_option' => 'custom',
                'name' => $this->l('Custom'),
            ],
        ];

        if ($this->getPSVersion() >= 1.7) {
            $all_hooks = [];
            foreach (Hook::getHooks(false, true) as $hook) {
                if (strpos($hook['name'], 'displayAdmin') === false
                    && strpos($hook['name'], 'displayBackOffice') === false
                ) {
                    $all_hooks[] = [
                        'id_option' => $hook['name'],
                        'name' => $hook['name'],
                    ];
                }
            }

            if (!$list) {
                $result = [
                    'main' => [
                        'name' => $this->l('Main'),
                        'query' => $hooks,
                    ],
                    'all' => [
                        'name' => $this->l('All'),
                        'query' => $all_hooks,
                    ],
                ];
            } else {
                $result = array_merge($hooks, $all_hooks);
            }

            $hooks = $result;
        }

        return $hooks;
    }

    public function getScreenSizeList()
    {
        $hooks = [
            [
                'id_option' => 'lg',
                'name' => $this->l('Large desktop (1200px+ width)'),
            ],
            [
                'id_option' => 'md',
                'name' => $this->l('Desktop (992px+)'),
            ],
            [
                'id_option' => 'sm',
                'name' => $this->l('Tablets (768px+)'),
            ],
            [
                'id_option' => 'xs',
                'name' => $this->l('Mobile phones (less than 768px)'),
            ],
        ];

        return $hooks;
    }

    public function ajaxProcessGetList()
    {
        $table = Tools::getValue('table');

        if ($table == 'pstbannercountdown') {
            exit($this->renderItems());
        }
    }

    public function renderPreviewBlock($id_countdown = null)
    {
        $blocks = [];
        if ($id_countdown) {
            $blocks = PstBannerCountdownBlock::getBlocks($id_countdown);
        }

        $new_block_form = $this->renderBlockForm(
            $id_countdown ? $this->l('Edit block') : $this->l('Add block'),
            $this->getBlockFormFields(),
            'pstbannercountdown_block',
            '',
            null,
            $id_countdown
        );

        $this->context->smarty->assign([
            'psv' => $this->getPSVersion(),
            'link' => $this->context->link,
            'pbc_blocks' => $blocks,
            'block_types' => $this->getBlockTypes(),
            'id_pstbannercountdown' => $id_countdown,
            'tpl_path' => _PS_MODULE_DIR_ . $this->name . '/views/templates/admin/',
            'id_countdown' => (int) $id_countdown,
            'new_block_form' => $new_block_form,
        ]);

        return $this->context->smarty->fetch($this->local_path . 'views/templates/admin/preview_block.tpl');
    }

    public function renderPreviewBlockList($id_countdown = null)
    {
        if ($id_countdown) {
            $blocks = PstBannerCountdownBlock::getBlocks($id_countdown);

            $this->context->smarty->assign([
                'psv' => $this->getPSVersion(),
                'link' => $this->context->link,
                'pbc_blocks' => $blocks,
                'block_types' => $this->getBlockTypes(),
                'id_pstbannercountdown' => $id_countdown,
                'tpl_path' => _PS_MODULE_DIR_ . $this->name . '/views/templates/admin/',
            ]);

            return $this->context->smarty->fetch($this->local_path . 'views/templates/admin/_blocks.tpl');
        }

        return null;
    }

    public function getThemeOptions()
    {
        $options = [];

        foreach ($this->getThemes() as $theme) {
            $options[] = [
                'id' => $theme['file'],
                'value' => $theme['file'],
                'label' => $theme['name'],
                'img' => $this->_path . 'views/img/themes/' . $theme['name'] . '.png',
            ];
        }

        return $options;
    }

    protected function getThemes()
    {
        $themes = [];

        if (file_exists(_PS_MODULE_DIR_ . $this->name . '/views/css/themes/')) {
            $themes_files = scandir(_PS_MODULE_DIR_ . $this->name . '/views/css/themes/');
            natsort($themes_files);
            foreach ($themes_files as $file) {
                if (strpos($file, '.css') !== false && $file[0] != '.') {
                    $pos = strpos($file, '.css');
                    $themes[] = ['file' => $file, 'name' => Tools::substr($file, 0, $pos)];
                }
            }
        }

        return $themes;
    }

    public function getColorsData($chosen_theme = null)
    {
        $default_colors = [
            '1-simple' => ['rgba(214, 214, 214, 0.5)', '#232323', '#333333', '#f13340', '#202020'],
            '2-dark' => ['#202020', '#232323', '#f8f8f8', '#f8f8f8', '#202020', '#000000', 'rgba(0, 0, 0, 0.5)'],
            '3-light' => ['#ffffff', '#232323', '#333333', '#333333', '#202020', '#e1e1e1', 'rgba(0, 0, 0, 0.2)'],
            '4' => ['', '#232323', '#333333', '#f13340', '#3f3f3f', null, null, 'rgba(255, 255, 255, 0.8)', ''],
            '5' => ['', '#232323', '#333333', '#f13340', '#3f3f3f'],
            '6' => ['#cc0000', '#232323', '#333333', '#ffffff', '#3f3f3f'],
            '7-minimal' => ['rgba(255, 255, 255, 0.8)', '#232323', '#232323'],
            '8-clock' => ['rgba(255, 255, 255, 0.8)', '#232323', '#333333', '#f13340', '#9b9b9b', '#dedede'],
            '9-clock-b' => ['rgba(255, 255, 255, 0.8)', '#232323', '#333333', '#af0404', '#9b9b9b', '#b9b9b9'],
            '10-minimal-1' => [null, '#232323', '#d80f00'],
            '11-minimal-2' => [null, '#232323', '#232323'],
        ];

        $result = [];
        foreach ($default_colors as $theme => $colors) {
            // skip other themes if a chosen theme param specified
            if ($chosen_theme && rtrim($chosen_theme, '.css') != $theme) {
                continue;
            }

            if (isset($colors[0]) && $colors[0]) {
                $result[$theme . '-bg'] = [
                    'param' => 'bg',
                    'name' => $this->l('Background'),
                    'default' => $colors[0],
                    'theme' => $theme,
                ];
            }
            if (isset($colors[1]) && $colors[1]) {
                $result[$theme . '-promo'] = [
                    'param' => 'promo',
                    'name' => $this->l('Promo text'),
                    'default' => $colors[1],
                    'theme' => $theme,
                ];
            }
            if (isset($colors[2]) && $colors[2]) {
                $result[$theme . '-digits'] = [
                    'param' => 'digits',
                    'name' => $this->l('Digits'),
                    'default' => $colors[2],
                    'theme' => $theme,
                ];
            }
            if (isset($colors[3]) && $colors[3]) {
                $result[$theme . '-highlight'] = [
                    'param' => 'highlight',
                    'name' => $this->l('Highlight'),
                    'default' => $colors[3],
                    'theme' => $theme,
                ];
            }
            if (isset($colors[4]) && $colors[4]) {
                $result[$theme . '-labels'] = [
                    'param' => 'labels',
                    'name' => $this->l('Labels'),
                    'default' => $colors[4],
                    'theme' => $theme,
                ];
            }

            if (isset($colors[5]) && $colors[5]) {
                $result[$theme . '-border'] = [
                    'param' => 'border',
                    'name' => $this->l('Border'),
                    'default' => $colors[5],
                    'theme' => $theme,
                ];
            }
            if (isset($colors[6]) && $colors[6]) {
                $result[$theme . '-shadow'] = [
                    'param' => 'shadow',
                    'name' => $this->l('Shadow'),
                    'default' => $colors[6],
                    'theme' => $theme,
                ];
            }
        }

        return $result;
    }

    public function ajaxProcessSaveBlock()
    {
        $id_block = Tools::getValue('id_pstbannercountdown_block');
        $block = new PstBannerCountdownBlock($id_block);
        if ($id_block && !Validate::isLoadedObject($block)) {
            exit('0');
        }

        foreach (PstBannerCountdownBlock::$definition['fields'] as $field_name => $field_data) {
            if (isset($field_data['lang']) && $field_data['lang']
                && !(isset($field_data['file']) && $field_data['file'])
            ) {
                $block->{$field_name} = [];
                foreach (Language::getLanguages() as $lang) {
                    $block->{$field_name}[$lang['id_lang']] = trim(Tools::getValue($field_name . '_' . $lang['id_lang']));
                }
            } elseif (isset($field_data['file']) && $field_data['file']) {
                // skip for now because ID is required but can be not set yet
                continue;
            } else {
                if ($id_block) {
                    if (Tools::isSubmit($field_name)
                        || (isset($field_data['is_checkbox']) && $field_data['is_checkbox'])
                    ) {
                        $block->$field_name = trim(Tools::getValue($field_name));
                    }
                } else {
                    $block->$field_name = trim(Tools::getValue($field_name));
                }
            }
        }
        if (!$id_block) {
            $block->position = PstBannerCountdownBlock::getMaxPosition(Tools::getValue('id_pstbannercountdown')) + 1;
        }

        // Check for errors
        $field_errors = $block->validateAllFields();
        // Save if no errors
        if (!(is_array($field_errors) && count($field_errors))) {
            if ($block->save()) {
                $id_lang_default = Configuration::get('PS_LANG_DEFAULT');
                foreach (PstBannerCountdownBlock::$definition['fields'] as $field_name => $field_data) {
                    if (isset($field_data['file']) && $field_data['file']) {
                        $lang_uploads = [];
                        foreach (Language::getLanguages(false) as $lang) {
                            if (isset($_FILES[$field_name]) && is_array($_FILES[$field_name])) {
                                $filename = 'bl-' . $block->id . '-' . $lang['id_lang']
                                    . '-' . uniqid() . '-' . $field_name;
                                $upload_result = $this->uploadImage(
                                    $field_name,
                                    _PS_MODULE_DIR_ . $this->name . '/upload/',
                                    $filename,
                                    $block->{$field_name}[$lang['id_lang']],
                                    $lang['id_lang']
                                );

                                if ($upload_result !== null) {
                                    $lang_uploads[] = $lang['id_lang'];
                                    if (is_string($upload_result)) {
                                        $block->{$field_name}[$lang['id_lang']] = $upload_result;
                                        $block->save();
                                    } elseif (is_array($upload_result)) {
                                        $field_errors = array_merge($field_errors, $upload_result);
                                    } else {
                                        $field_errors[] = $this->l('Unknown error while uploading images');
                                    }
                                }
                            }
                        }
                        if (count($lang_uploads)) {
                            foreach (Language::getLanguages(false) as $lang) {
                                if (!$block->{$field_name}[$lang['id_lang']]
                                    && $lang['id_lang'] != $id_lang_default
                                    && !in_array($lang['id_lang'], $lang_uploads)
                                    && $block->{$field_name}[$id_lang_default]
                                ) {
                                    $block->{$field_name}[$lang['id_lang']] = $block->{$field_name}[$id_lang_default];
                                }
                            }
                            $block->save();
                        }
                    }
                }

                $products = Tools::getValue('products');
                $block->clearProducts();
                if ($products && is_array($products)) {
                    foreach ($products as $id_product) {
                        $block->addProduct($id_product);
                    }
                }

                if (!(is_array($field_errors) && count($field_errors))) {
                    exit('1');
                }
            }
        }

        // Display errors if any
        if (is_array($field_errors) && count($field_errors)) {
            $html = '';
            foreach ($field_errors as $field_error) {
                $html .= $this->displayError($field_error);
            }
            // if this is creation of block and there are some errors
            if (!$id_block && Validate::isLoadedObject($block)) {
                $block->delete(); // delete created block if there were any errors
            }
            exit($html);
        }

        exit('0');
    }

    public function ajaxProcessSaveBlockPositions()
    {
        $blocks = Tools::getValue('pbc_block');

        foreach ($blocks as $position => $id_block) {
            $block = new PstBannerCountdownBlock($id_block);
            $block->position = $position;
            $block->save();
        }

        exit('0');
    }

    public function ajaxProcessDeleteBlock()
    {
        $id_block = Tools::getValue('id_block');

        if ($id_block) {
            $block = new PstBannerCountdownBlock($id_block);
            $block->delete();
        }

        exit('0');
    }

    public function ajaxProcessGetBlockList()
    {
        $id_countdown = Tools::getValue('id_countdown');

        exit($this->renderPreviewBlockList($id_countdown));
    }

    public function ajaxProcessGetNewBlockForm()
    {
        $id_countdown = Tools::getValue('id_countdown');

        $html = $this->renderBlockForm(
            $this->l('Add block'),
            $this->getBlockFormFields(),
            'pstbannercountdown_block',
            '',
            null,
            $id_countdown
        );

        exit($html);
    }

    public function ajaxProcessGetEditBlockForm()
    {
        $id_block = Tools::getValue('id_block');
        $block = new PstBannerCountdownBlock($id_block);

        $html = $this->renderBlockForm(
            $this->l('Edit block'),
            $this->getBlockFormFields($block->id),
            'pstbannercountdown_block',
            '',
            $block,
            $block->id_pstbannercountdown
        );

        exit($html);
    }

    public function ajaxProcessChangeCountdownStatus()
    {
        $id_countdown = Tools::getValue('id_countdown');
        $countdown = new PstBannerCountdownItem($id_countdown);

        if ($countdown->active == 2) {
            $countdown->active = 1;
        } else {
            $countdown->active = ($countdown->active ? 0 : 1);
        }
        $countdown->save();

        $this->regenerateCSS();

        exit('1');
    }

    protected function getBlockFormFields($id_item = null)
    {
        $fields = [
            [
                'type' => 'select',
                'name' => 'type',
                'class' => 't pbc_type',
                'id' => 'type' . ($id_item ? $id_item : ''),
                'label' => $this->l('Type:'),
                'validate' => 'isCleanHtml',
                'options' => [
                    'query' => $this->getBlockTypeOptions(),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'form_group_class' => 'pbc_form_group',
                'required' => false,
            ],
            [
                'type' => 'block_select_responsive',
                'name' => 'width',
                'class' => 't',
                'id' => 'width' . ($id_item ? $id_item : ''),
                'label' => $this->l('Width:'),
                'hint' => $this->l('You can choose width of this block inside of the banner. For example you can add 2 blocks with 50% width (e.g. text and countdown). They will be placed side by side.'),
                'validate' => 'isCleanHtml',
                'options' => [
                    'query' => $this->getBlockWidthOptions(),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'form_group_class' => 'pbc_form_group',
                'required' => false,
            ],
            [
                'type' => 'block_select_responsive',
                'name' => 'align',
                'class' => 't pbc_no_product',
                'id' => 'align' . ($id_item ? $id_item : ''),
                'label' => $this->l('Alignment:'),
                'hint' => $this->l('Text alignment inside this block'),
                'validate' => 'isCleanHtml',
                'options' => [
                    'query' => $this->getBlockAlignmentOptions(),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'form_group_class' => 'pbc_form_group pbc_bfg pbc_bfg_countdown pbc_bfg_text pbc_bfg_image',
                'required' => false,
            ],
            [
                'type' => 'block_select_responsive',
                'name' => 'valign',
                'class' => 't pbc_no_product',
                'id' => 'valign' . ($id_item ? $id_item : ''),
                'label' => $this->l('Vertical alignment:'),
                'validate' => 'isCleanHtml',
                'options' => [
                    'query' => $this->getBlockAlignmentOptions('valign'),
                    'id' => 'id_option',
                    'name' => 'name',
                ],
                'form_group_class' => 'pbc_form_group pbc_bfg pbc_bfg_countdown pbc_bfg_text pbc_bfg_image',
                'required' => false,
            ],
            [
                'type' => 'textarea',
                'name' => 'content',
                'id' => 'content' . mt_rand() . ($id_item ? $id_item : ''),
                'label' => $this->l('Content:'),
                'validate' => 'isCleanHtml',
                'required' => false,
                'lang' => true,
                'cols' => 100,
                'rows' => 6,
                'class' => 'pbc_rte pbc_content',
                'form_group_class' => 'pbc_form_group pbc_bfg pbc_bfg_text',
            ],
            [
                'type' => 'text',
                'name' => 'content_countdown',
                'id' => 'content_countdown' . mt_rand() . ($id_item ? $id_item : ''),
                'label' => $this->l('Promo text:'),
                'validate' => 'isCleanHtml',
                'required' => false,
                'lang' => true,
                'form_group_class' => 'pbc_form_group pbc_bfg pbc_bfg_countdown',
            ],
            [
                'type' => 'margin',
                'name' => 'margin',
                'id' => 'margin' . ($id_item ? $id_item : ''),
                'label' => $this->l('Margin, px:'),
                'hint' => $this->l('Margin around this block. You can use it for adding some space around this block. It can be negative for reduction of space around.'),
                'validate' => 'isString',
                'required' => false,
            ],
            [
                'type' => 'products',
                'name' => 'products',
                'id' => 'products' . ($id_item ? $id_item : ''),
                'label' => $this->l('Products:'),
                'hint' => $this->l('Search products by name, reference etc. Add them by click at search results.'),
                'validate' => 'isString',
                'required' => false,
                'form_group_class' => 'pbc_form_group pbc_bfg pbc_bfg_products',
                'products' => [],
            ],
            [
                'type' => 'file',
                'name' => 'image',
                'id' => 'image' . ($id_item ? $id_item : ''),
                'label' => $this->l('Image:'),
                'hint' => $this->l('You can upload an image.'),
                'ajax' => false,
                'lang' => true,
                'default' => '',
                'validate' => 'isString',
                'form_group_class' => 'pbc_img_form_group pbc_bfg pbc_bfg_image',
            ],
            [
                'type' => 'text',
                'name' => 'link',
                'id' => 'link' . ($id_item ? $id_item : ''),
                'label' => $this->l('Link:'),
                'hint' => $this->l('A link that will be opened on clicking this image. Not mandatory.'),
                'default' => '',
                'validate' => 'isUrl',
                'lang' => true,
                'form_group_class' => 'pbc_img_form_group pbc_bfg pbc_bfg_image',
            ],
            [
                'type' => 'text',
                'name' => 'bg_color',
                'id' => 'bg_color' . ($id_item ? $id_item : ''),
                'label' => $this->l('Background color:'),
                'hint' => $this->l('Background color of this block'),
                'class' => 'pbcColorPickerInput',
                'validate' => 'isString',
            ],
            [
                'type' => 'hidden',
                'name' => 'id_pstbannercountdown',
            ],
            [
                'type' => 'html',
                'name' => '',
                'id' => 'error_container',
                'html_content' => $this->context->smarty->fetch(
                    $this->local_path . 'views/templates/admin/_errors_wrp.tpl'
                ),
            ],
        ];

        if ($this->getPSVersion() < 1.6) {
            foreach ($fields as &$item) {
                $desc = isset($item['desc']) ? $item['desc'] : '';
                $hint = isset($item['hint']) ? $item['hint'] . '<br/>' : '';
                $item['desc'] = $hint . $desc;
                $item['hint'] = '';
            }
        }

        return $fields;
    }

    protected function getBlockTypes()
    {
        $types = [
            'text' => $this->l('Text'),
            'image' => $this->l('Image'),
            'countdown' => $this->l('Countdown'),
            'products' => $this->l('Products'),
        ];

        return $types;
    }

    protected function getBlockTypeOptions()
    {
        $options = [];

        foreach ($this->getBlockTypes() as $type => $name) {
            $options[] = [
                'id_option' => $type,
                'name' => $name,
            ];
        }

        return $options;
    }

    protected function getBlockWidthOptions()
    {
        $options = [];

        for ($i = 1; $i <= 12; ++$i) {
            $percent = '';
            if (is_int(100 * $i / 12)) {
                $percent = 100 * $i / 12;
                $percent = " ($percent%)";
            }
            $options[] = [
                'id_option' => $i,
                'name' => $i . '/12' . $percent,
            ];
        }

        return $options;
    }

    protected function getAlignmentTypes($type = 'align')
    {
        if ($type == 'valign') {
            $types = [
                'top' => $this->l('Top'),
                'center' => $this->l('Center'),
                'bottom' => $this->l('Bottom'),
            ];
        } else {
            $types = [
                'left' => $this->l('Left'),
                'center' => $this->l('Center'),
                'right' => $this->l('Right'),
            ];
        }

        return $types;
    }

    protected function getBlockAlignmentOptions($type = 'align')
    {
        $options = [];

        foreach ($this->getAlignmentTypes($type) as $type => $name) {
            $options[] = [
                'id_option' => $type,
                'name' => $name,
            ];
        }

        return $options;
    }

    protected function uploadImage($input_name, $upload_dir, $result_filename, $old_file, $id_lang = null)
    {
        $extensions = ['.png', '.jpeg', '.gif', '.jpg'];
        $errors = [];

        $file_attachment = $this->fileAttachment($input_name, $result_filename, $id_lang);
        if ($file_attachment) {
            if (!empty($file_attachment['name']) && $file_attachment['error'] != 0) {
                $errors[] = $this->l('An error occurred during the file upload process.');
            } elseif (!empty($file_attachment['name'])
                && !in_array(Tools::strtolower(Tools::substr($file_attachment['name'], -4)), $extensions)
                && !in_array(Tools::strtolower(Tools::substr($file_attachment['name'], -5)), $extensions)
            ) {
                $errors[] = $this->l('Bad file extension');
            } elseif (!@getimagesize($file_attachment['tmp_name'])) {
                $errors[] = $this->l('Invalid image.');
            } else {
                if (isset($file_attachment['rename']) && !empty($file_attachment['rename'])
                    && @rename($file_attachment['tmp_name'], $upload_dir . basename($file_attachment['rename']))
                ) {
                    // Delete old file
                    if ($old_file && is_string($old_file) && file_exists($upload_dir . basename($old_file))) {
                        @unlink($upload_dir . basename($old_file));
                    } elseif (is_array($old_file)) {
                        foreach ($old_file as $old_file_name) {
                            if ($old_file_name && is_string($old_file_name)
                                && file_exists($upload_dir . basename($old_file_name))
                            ) {
                                @unlink($upload_dir . basename($old_file_name));
                            }
                        }
                    }

                    @chmod($upload_dir . basename($file_attachment['rename']), 0664);
                } else {
                    $errors[] = $this->l('Unable to upload an image. Please check write permissions.');
                }
            }
        }

        if (count($errors)) {
            return $errors;
        } else {
            return $file_attachment ? $file_attachment['rename'] : null;
        }
    }

    /**
     * @param $input string - input name
     * @param $result_filename string - output filename without extension
     * @param int $id_lang
     *
     * @return array|null
     */
    protected function fileAttachment($input, $result_filename, $id_lang = null)
    {
        $file_attachment = null;

        if (isset($_FILES[$input]) && isset($_FILES[$input]['name'])
            && !empty($_FILES[$input]['name']) && !empty($_FILES[$input]['tmp_name'])
        ) {
            if ($id_lang) {
                $ext = pathinfo($_FILES[$input]['name'][$id_lang], PATHINFO_EXTENSION);
                if ($_FILES[$input]['tmp_name'][$id_lang]) {
                    $file_attachment = [];
                    $file_attachment['rename'] = $result_filename . '.' . $ext;
                    $file_attachment['tmp_name'] = $_FILES[$input]['tmp_name'][$id_lang];
                    $file_attachment['name'] = $_FILES[$input]['name'][$id_lang];
                    $file_attachment['mime'] = $_FILES[$input]['type'][$id_lang];
                    $file_attachment['error'] = $_FILES[$input]['error'][$id_lang];
                    $file_attachment['size'] = $_FILES[$input]['size'][$id_lang];
                }
            } else {
                $ext = pathinfo($_FILES[$input]['name'], PATHINFO_EXTENSION);
                if ($_FILES[$input]['tmp_name']) {
                    $file_attachment = [];
                    $file_attachment['rename'] = $result_filename . '.' . $ext;
                    $file_attachment['tmp_name'] = $_FILES[$input]['tmp_name'];
                    $file_attachment['name'] = $_FILES[$input]['name'];
                    $file_attachment['mime'] = $_FILES[$input]['type'];
                    $file_attachment['error'] = $_FILES[$input]['error'];
                    $file_attachment['size'] = $_FILES[$input]['size'];
                }
            }
        }

        return $file_attachment;
    }

    public static function getSideMargin($margin, $side)
    {
        $margin = explode(' ', $margin);
        if (isset($margin[0]) && isset($margin[1]) && isset($margin[2]) && isset($margin[3])) {
            switch ($side) {
                case 'top':
                    return rtrim($margin[0], 'px');
                case 'right':
                    return rtrim($margin[1], 'px');
                case 'bottom':
                    return rtrim($margin[2], 'px');
                case 'left':
                    return rtrim($margin[3], 'px');
            }
        }

        return 0;
    }

    /**
     * Ajax get products for autocomplete
     */
    public function ajaxProcessGetProducts()
    {
        $query = Tools::getValue('query', false);
        if (!$query or $query == '' or Tools::strlen($query) < 1) {
            exit;
        }

        /*
         * In the SQL request the "q" param is used entirely to match result in database.
         * In this way if string:"(ref : #ref_pattern#)" is displayed on the return list,
         * they are no return values just because string:"(ref : #ref_pattern#)"
         * is not write in the name field of the product.
         * So the ref pattern will be cut for the search request.
         */
        if ($pos = strpos($query, ' (ref:')) {
            $query = Tools::substr($query, 0, $pos);
        }

        $excludeIds = Tools::getValue('excludeIds', false);
        if ($excludeIds && $excludeIds != 'NaN') {
            $excludeIds = implode(',', array_map('intval', explode(',', $excludeIds)));
        } else {
            $excludeIds = '';
        }

        $context = Context::getContext();

        $sql =
            'SELECT p.`id_product`, pl.`link_rewrite`, p.`reference`, pl.`name`, p.`cache_default_attribute`
		     FROM `' . _DB_PREFIX_ . 'product` p
             ' . Shop::addSqlAssociation('product', 'p') . '
		     LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON
		      (pl.id_product = p.id_product
              AND pl.id_lang = ' . (int) $context->language->id . Shop::addSqlRestrictionOnLang('pl') . ')
		     WHERE (pl.name LIKE \'%' . pSQL($query) . '%\' OR p.reference LIKE \'%' . pSQL($query) . '%\'
		      OR p.`id_product` = ' . (int) $query . ')' .
            (!empty($excludeIds) ? ' AND p.id_product NOT IN (' . $excludeIds . ') ' : ' ') .
            ' GROUP BY p.id_product';

        $items = Db::getInstance()->executeS($sql);

        if ($items) {
            $result = [];
            $result['suggestions'] = [];
            foreach ($items as $item) {
                $result['suggestions'][] = [
                    'value' => trim($item['name']) . (!empty($item['reference']) ? ' (' . $this->l('ref:') . ' '
                            . $item['reference'] . ')' : '') . ' | ID ' . (int) $item['id_product'],
                    'data' => $item['id_product'],
                ];
            }
            echo json_encode($result);
        } else {
            json_encode(new stdClass());
        }
    }

    public function displayCustomHookInfo($id_countdown)
    {
        $countdown = new PstBannerCountdownItem($id_countdown);

        $this->context->smarty->assign([
            'id_countdown' => $id_countdown,
            'pbc_countdown' => $countdown,
            'psv' => $this->getPSVersion(),
        ]);

        return $this->context->smarty->fetch($this->local_path . 'views/templates/admin/custom_hook_info.tpl');
    }

    protected function getHighlightSelectOptions()
    {
        $results = [
            [
                'id_option' => 'seconds',
                'name' => $this->l('Seconds'),
            ],
            [
                'id_option' => 'minutes',
                'name' => $this->l('Minutes'),
            ],
            [
                'id_option' => 'hours',
                'name' => $this->l('Hours'),
            ],
            [
                'id_option' => 'days',
                'name' => $this->l('Days'),
            ],
        ];

        return $results;
    }

    public function renderWidget($hookName, array $params)
    {
        $data = $this->getWidgetVariables($hookName, $params);
        $this->context->smarty->assign($data);

        $html = '';
        if (!empty($data['pbc_banners']) && count($data['pbc_banners'])) {
            $html = $this->fetch(
                'module:' . $this->name . '/views/templates/hook/countdown.tpl'
            );
        }

        return $html;
    }

    public function getWidgetVariables($hookName, array $params)
    {
        $hook = ($hookName ? $hookName : null);
        if (!$hook) {
            $hook = (isset($params['hook']) ? $params['hook'] : 'custom');
        }
        $name = (isset($params['name']) ? $params['name'] : '');
        $id = (isset($params['id']) ? $params['id'] : '');
        $banners = PstBannerCountdownItem::getBannersFront($hook, $id, $name);

        // set the product list template path
        $pbc_tpl_dir = _PS_THEME_DIR_;
        if ($this->getPSVersion() >= 1.7) {
            $product_list_tpl = $this->name . '/views/templates/front/product-list.tpl';
            if (file_exists(_PS_THEME_DIR_ . 'modules/' . $product_list_tpl)) {
                $pbc_tpl_dir = _PS_THEME_DIR_ . 'modules/' . $this->name . '/views/templates/front/';
            } else {
                $pbc_tpl_dir = _PS_MODULE_DIR_ . $this->name . '/views/templates/front/';
            }
        }

        return [
            'pbc_banners' => $banners,
            'psv' => $this->getPSVersion(),
            'psvd' => $this->getPSVersion(true),
            'pbc_hook' => (is_array($hook) ? $hookName : $hook),
            'pbc_custom_display' => (isset($params['pbc_custom_display']) ? $params['pbc_custom_display'] : false),
            'pbc_tpl_dir' => $pbc_tpl_dir,
        ];
    }

    protected function getCacheId($name = null, $to_time = null)
    {
        $cache_array = [];
        $cache_array[] = $name !== null ? $name : $this->name;
        $cache_array[] = $to_time !== null ? $to_time : '';
        if (Configuration::get('PS_SSL_ENABLED')) {
            $cache_array[] = (int) Tools::usingSecureMode();
        }
        if (Shop::isFeatureActive()) {
            $cache_array[] = (int) $this->context->shop->id;
        }
        if (Group::isFeatureActive() && isset($this->context->customer)) {
            $cache_array[] = (int) Group::getCurrent()->id;
            $cache_array[] = implode('_', Customer::getGroupsStatic($this->context->customer->id));
        }
        if (Language::isMultiLanguageActivated()) {
            $cache_array[] = (int) $this->context->language->id;
        }
        if (method_exists('Currency', 'isMultiCurrencyActivated')) {
            if (Currency::isMultiCurrencyActivated()) {
                $cache_array[] = (int) $this->context->currency->id;
            }
        }
        $cache_array[] = (int) $this->context->country->id;

        return implode('|', $cache_array);
    }

    public function clearSmartyCache()
    {
        if (method_exists($this, '_clearCache')) {
            $this->_clearCache('header.tpl');
            $this->_clearCache('countdown.tpl');
        }
        //        Tools::clearCache($this->context->smarty);

        if ($this->getPSVersion() >= 1.7 && method_exists($this, '_deferedClearCache')) {
            $this->_deferedClearCache($this->getTemplatePath('header.tpl'), null, null);
            $this->_deferedClearCache($this->getTemplatePath('countdown.tpl'), null, null);
        }
    }

    public function renderQuickGuide()
    {
        $this->context->smarty->assign([
            'psv' => $this->getPSVersion(),
            'psvd' => $this->getPSVersion(true),
            'module_path' => $this->_path,
        ]);

        return $this->context->smarty->fetch($this->local_path . 'views/templates/admin/guide.tpl');
    }

    public function getShopName($id_shop)
    {
        $shop = new Shop($id_shop, $this->context->language->id);

        return $shop->name;
    }

    protected function getShopList()
    {
        $shops = Shop::getShops();
        $result = [];

        foreach ($shops as $shop) {
            $result[] = [
                'id_option' => $shop['id_shop'],
                'name' => $shop['name'],
            ];
        }

        return $result;
    }

    public function regenerateCSS()
    {
        $banners_initial = PstBannerCountdownItem::getAllBanners(false);
        $banners = [];
        foreach ($banners_initial as $banner) {
            $banner->loadColors();
            $banners[] = $banner;
        }

        $this->context->smarty->assign([
            'banners' => $banners,
            'upload_dir' => $this->_path . 'upload/',
            'custom_css' => html_entity_decode($this->custom_css),
        ]);

        $time = time();
        $code = $this->context->smarty->fetch($this->local_path . 'views/templates/front/css.tpl');
        $css_dir = _PS_MODULE_DIR_ . $this->name . '/views/css/';
        $css_file = $css_dir . 'settings-' . $time . '.css';
        if (is_writable($css_dir)) {
            array_map('unlink', glob(_PS_MODULE_DIR_ . $this->name . '/views/css/settings-*.css'));
            Configuration::updateGlobalValue($this->settings_prefix . 'CSS_SAVED', $time);
            file_put_contents($css_file, $code);
        } else {
            $this->errors[] = $this->l('Please make the "css" directory writable:')
                . ' /modules/' . $this->name . '/views/css/';
        }
    }

    protected function installTab()
    {
        $tabId = (int) Tab::getIdFromClassName('AdminPstBannerCountdown');
        if (!$tabId) {
            $tabId = null;
        }

        $tab = new Tab($tabId);
        $tab->active = 1;
        $tab->class_name = 'AdminPstBannerCountdown';
        $tab->name = [];
        foreach (Language::getLanguages() as $lang) {
            $tab->name[$lang['id_lang']] = $this->displayName;
        }
        $tab->module = $this->name;
        $tab->id_parent = (int) Tab::getIdFromClassName('AdminParentModulesSf');

        return $tab->save();
    }

    protected function uninstallTab()
    {
        $tabId = (int) Tab::getIdFromClassName('AdminPstBannerCountdown');
        if (!$tabId) {
            return true;
        }

        $tab = new Tab($tabId);

        return $tab->delete();
    }

    protected function createBannerFromPreset($preset)
    {
        $id_lang_default = Configuration::get('PS_LANG_DEFAULT');
        $id_banner = null;
        $banner = new PstBannerCountdownItem();
        // default options:
        $from_time = time() - (24 * 60 * 60); // now - 24h
        $banner->from = date('Y-m-d H:i:s', $from_time);
        $to_time = time() + (24 * 60 * 60); // now + 24h
        $banner->to = date('Y-m-d H:i:s', $to_time);
        $banner->width = 12;
        $banner->screen_sizes = '1111';
        $banner->font_size = 1;
        $banner->highlight_position = 'seconds';
        $banner->active = 0;
        $banner->skip_block_creation = true;

        if ($preset != 'clone') {
            $banner->all_groups = true;
        }

        if ($preset == 'top_banner') {
            $banner->theme = '5.css';
            $banner->compact_view = true;
            $banner->limit_width = true;
            $banner->font_size = 0.7;
            $banner->show_colon = 1;
            $banner->hook = ($this->getPSVersion() >= 1.7 ? 'displayBanner' : 'displayTopSticky');
            if ($this->getPSVersion() == 1.5) {
                $banner->hook = 'displayTopSticky2';
            }
            $banner->bg_color = 'rgb(0, 152, 255)';
            $banner->close_btn = true;

            // save and create blocks:
            if ($banner->save()) {
                $id_banner = $banner->id;

                // set colors
                $colors_obj = new PstBannerCountdownColors();
                $colors_obj->id_pstbannercountdown = $id_banner;
                $colors_obj->theme = $banner->theme;
                foreach ($this->getColorsData($banner->theme) as $key => $data) {
                    $param = $data['param'];
                    $colors_obj->{$param} = $data['default'];
                }
                $colors_obj->digits = '#ffffff';
                $colors_obj->labels = '#ffffff';
                $colors_obj->highlight = '#ff9800';
                $colors_obj->save();

                // text block
                $b1 = new PstBannerCountdownBlock();
                $b1->id_pstbannercountdown = $id_banner;
                $b1->type = 'text';
                $b1->width = 6;
                $b1->align = 'left';
                $b1->valign = 'center';
                $b1->position = 0;
                $b1->content = [];
                $this->context->smarty->assign([
                    'pbc_example_text' => $this->l('Sale!'),
                    'pbc_example_color' => 'white',
                ]);
                $text = $this->context->smarty->fetch(
                    $this->local_path . 'views/templates/admin/_example_content.tpl'
                );
                foreach (Language::getlanguages(false) as $lang) {
                    $b1->content[$lang['id_lang']] = $text;
                }
                $b1->save();

                // countdown block
                $b2 = new PstBannerCountdownBlock();
                $b2->id_pstbannercountdown = $id_banner;
                $b2->type = 'countdown';
                $b2->width = 6;
                $b2->align = 'right';
                $b2->valign = 'center';
                $b2->position = 1;
                $b2->save();
            }
        } elseif ($preset == 'homepage') {
            $banner->theme = '8-clock.css';
            $banner->font_size = 0.85;
            $banner->show_colon = true;
            $banner->hook = 'displayHome';
            foreach (Language::getlanguages(false) as $lang) {
                $banner->link[$lang['id_lang']] =
                    $this->context->link->getPageLink('prices-drop', null, $lang['id_lang']);
            }

            // save and create blocks:
            if ($banner->save()) {
                $id_banner = $banner->id;

                // set bg image
                $new_filename = $id_banner . '-' . $id_lang_default . '-' . uniqid() . '-bg_image.png';
                $upload_dir = _PS_MODULE_DIR_ . $this->name . '/upload/';
                if (copy(_PS_MODULE_DIR_ . $this->name . '/views/img/homepage-example.png', $upload_dir . $new_filename)) {
                    foreach (Language::getlanguages(false) as $lang) {
                        $banner->bg_image[$lang['id_lang']] = $new_filename;
                    }
                    $banner->save();
                } else {
                    $this->errors[] = $this->l('Unable to copy an image');
                }

                // set colors
                $colors_obj = new PstBannerCountdownColors();
                $colors_obj->id_pstbannercountdown = $id_banner;
                $colors_obj->theme = $banner->theme;
                foreach ($this->getColorsData($banner->theme) as $key => $data) {
                    $param = $data['param'];
                    $colors_obj->{$param} = $data['default'];
                }
                $colors_obj->save();

                // text block
                $b1 = new PstBannerCountdownBlock();
                $b1->id_pstbannercountdown = $id_banner;
                $b1->type = 'text';
                $b1->width = 12;
                $b1->align = 'center';
                $b1->valign = 'center';
                $b1->position = 0;
                $b1->margin = '35px 0 20px 0';
                $b1->content = [];
                $this->context->smarty->assign([
                    'pbc_example_text' => $this->l('Sale up to 50%'),
                    'pbc_example_color' => 'white',
                    'pbc_example_fz' => '250%',
                ]);
                $text = $this->context->smarty->fetch(
                    $this->local_path . 'views/templates/admin/_example_content.tpl'
                );
                foreach (Language::getlanguages(false) as $lang) {
                    $b1->content[$lang['id_lang']] = $text;
                }
                $b1->save();

                // countdown block
                $b2 = new PstBannerCountdownBlock();
                $b2->id_pstbannercountdown = $id_banner;
                $b2->type = 'countdown';
                $b2->width = 12;
                $b2->align = 'center';
                $b2->valign = 'center';
                $b2->position = 1;
                $b2->margin = '0 0 20px 0';
                $b2->save();
            }
        } elseif ($preset == 'products') {
            $banner->system_name = $this->l('Banner with products');
            $banner->theme = '6.css';
            $banner->font_size = 1;
            $banner->show_colon = true;
            $banner->hook = 'displayHome';
            $banner->margin = '15px 0 0 0';

            // save and create blocks:
            if ($banner->save()) {
                $id_banner = $banner->id;

                // set colors
                $colors_obj = new PstBannerCountdownColors();
                $colors_obj->id_pstbannercountdown = $id_banner;
                $colors_obj->theme = $banner->theme;
                foreach ($this->getColorsData($banner->theme) as $key => $data) {
                    $param = $data['param'];
                    $colors_obj->{$param} = $data['default'];
                }
                $colors_obj->save();

                // countdown block
                $b1 = new PstBannerCountdownBlock();
                $b1->id_pstbannercountdown = $id_banner;
                $b1->type = 'countdown';
                $b1->width = 5;
                $b1->align = 'center';
                $b1->valign = 'center';
                $b1->position = 0;
                foreach (Language::getlanguages(false) as $lang) {
                    $b1->content_countdown[$lang['id_lang']] = $this->l('Hurry up! Our best offers');
                }
                $b1->save();

                // products
                $b2 = new PstBannerCountdownBlock();
                $b2->id_pstbannercountdown = $id_banner;
                $b2->type = 'products';
                $b2->width = 7;
                $b2->align = 'center';
                $b2->valign = 'center';
                $b2->position = 1;
                $b2->save();

                $products = [$this->getRandomProductID(), $this->getRandomProductID()];
                foreach ($products as $id_product) {
                    if ($id_product) {
                        $b2->addProduct($id_product);
                    }
                }
            }
        } elseif ($preset == 'clone') {
            $id_source_banner = Tools::getValue('source_banner');
            $source_banner = new PstBannerCountdownItem($id_source_banner);
            if (Validate::isLoadedObject($source_banner)) {
                foreach (PstBannerCountdownItem::$definition['fields'] as $field_name => $field_data) {
                    if ($field_name != 'bg_image') {
                        $banner->{$field_name} = $source_banner->{$field_name};
                    }
                }

                if ($banner->save()) {
                    $id_banner = $banner->id;
                    $img_dir = _PS_MODULE_DIR_ . $this->name . '/upload/';

                    // clone images
                    $bg_copied = false;
                    foreach (Language::getlanguages(false) as $lang) {
                        $old_filename = $source_banner->bg_image[$lang['id_lang']];
                        if ($old_filename) {
                            $ext = pathinfo($old_filename, PATHINFO_EXTENSION);
                            $new_filename = $id_banner . '-' . $lang['id_lang'] . '-' . uniqid() . '-bg_image.' . $ext;
                            // check if this img should be copied
                            $need_to_copy = true;
                            if ($lang['id_lang'] != $id_lang_default
                                && $source_banner->bg_image[$lang['id_lang']] == $source_banner->bg_image[$id_lang_default]
                            ) {
                                $need_to_copy = false;
                            }
                            if ($need_to_copy && !copy($img_dir . $old_filename, $img_dir . $new_filename)) {
                                $this->errors[] = $this->l('Unable to copy an image');
                            } elseif ($need_to_copy) {
                                $bg_copied = true;
                                $banner->bg_image[$lang['id_lang']] = $new_filename;
                            }
                        }
                    }
                    if ($bg_copied) {
                        foreach (Language::getlanguages(false) as $lang) {
                            if ($banner->bg_image[$id_lang_default] && !$banner->bg_image[$lang['id_lang']]) {
                                $banner->bg_image[$lang['id_lang']] = $banner->bg_image[$id_lang_default];
                            }
                        }

                        $banner->save();
                    }

                    // copy colors
                    $color_sets = Db::getInstance()->executeS(
                        'SELECT *
                         FROM `' . _DB_PREFIX_ . 'pstbannercountdown_colors`
                         WHERE `id_pstbannercountdown` = ' . (int) $source_banner->id
                    );
                    foreach ($color_sets as $color_set) {
                        $colors_obj = new PstBannerCountdownColors();
                        foreach (PstBannerCountdownColors::$definition['fields'] as $field_name => $field_data) {
                            if (isset($color_set[$field_name])) {
                                $colors_obj->{$field_name} = $color_set[$field_name];
                            }
                        }
                        $colors_obj->id_pstbannercountdown = $id_banner;
                        $colors_obj->save();
                    }

                    // copy blocks
                    $blocks = PstBannerCountdownBlock::getBlocks($source_banner->id);
                    foreach ($blocks as $source_block) {
                        $new_block = new PstBannerCountdownBlock();
                        foreach (PstBannerCountdownBlock::$definition['fields'] as $field_name => $field_data) {
                            if ($field_name != 'image') {
                                $new_block->{$field_name} = $source_block->{$field_name};
                            }
                        }
                        $new_block->id_pstbannercountdown = $id_banner;
                        if ($new_block->save()) {
                            // clone images
                            $img_copied = false;
                            foreach (Language::getlanguages(false) as $lang) {
                                $old_filename = $source_block->image[$lang['id_lang']];
                                if ($old_filename) {
                                    $ext = pathinfo($old_filename, PATHINFO_EXTENSION);
                                    $new_filename =
                                        'bl-' . $new_block->id . '-' . $lang['id_lang'] . '-' . uniqid() . '-image.' . $ext;
                                    // check if this img should be copied
                                    $need_to_copy = true;
                                    if ($lang['id_lang'] != $id_lang_default
                                        && $source_block->image[$lang['id_lang']] == $source_block->image[$id_lang_default]
                                    ) {
                                        $need_to_copy = false;
                                    }
                                    if ($need_to_copy && !copy($img_dir . $old_filename, $img_dir . $new_filename)) {
                                        $this->errors[] = $this->l('Unable to copy an image');
                                    } elseif ($need_to_copy) {
                                        $img_copied = true;
                                        $new_block->image[$lang['id_lang']] = $new_filename;
                                    }
                                }
                            }
                            if ($img_copied) {
                                foreach (Language::getlanguages(false) as $lang) {
                                    if ($new_block->image[$id_lang_default] && !$new_block->image[$lang['id_lang']]) {
                                        $new_block->image[$lang['id_lang']] = $new_block->image[$id_lang_default];
                                    }
                                }

                                $new_block->save();
                            }
                        }
                    }

                    // copy groups
                    $groups = $source_banner->getGroups();
                    $banner->setGroups($groups);
                }
            }
        }

        return $id_banner;
    }

    public function getBaseUrl($id_shop = null)
    {
        $id_shop = ($id_shop ? $id_shop : $this->context->shop->id);
        $url = $this->getShopDomain(true, false, $id_shop);
        $url_ssl = $this->getShopDomainSsl(true, false, $id_shop);

        if (Configuration::get('PS_SSL_ENABLED', null, null, $id_shop) && $url_ssl) {
            $url = $url_ssl;
        }

        $url = rtrim($url, '/') . '/';

        $main_shop = new Shop(Configuration::get('PS_SHOP_DEFAULT'));
        if (Validate::isLoadedObject($main_shop)) {
            $url .= trim($main_shop->physical_uri, '/') . '/';
        }

        $url = rtrim($url, '/') . '/';

        return $url;
    }

    public function getShopDomain($http = false, $entities = false, $id_shop = null)
    {
        $id_shop = ($id_shop ? $id_shop : $this->context->shop->id);

        if (!$domain = ShopUrl::getMainShopDomain($id_shop)) {
            $domain = Tools::getHttpHost();
        }
        if ($entities) {
            $domain = htmlspecialchars($domain, ENT_COMPAT, 'UTF-8');
        }
        if ($http) {
            $domain = 'http://' . $domain;
        }

        return $domain;
    }

    public function getShopDomainSsl($http = false, $entities = false, $id_shop = null)
    {
        $id_shop = ($id_shop ? $id_shop : $this->context->shop->id);

        if (!$domain = ShopUrl::getMainShopDomainSSL($id_shop)) {
            $domain = Tools::getHttpHost();
        }
        if ($entities) {
            $domain = htmlspecialchars($domain, ENT_COMPAT, 'UTF-8');
        }
        if ($http) {
            $domain = (Configuration::get('PS_SSL_ENABLED', null, null, $id_shop) ? 'https://' : 'http://') . $domain;
        }

        return $domain;
    }

    protected function getRandomProductID()
    {
        $row = Db::getInstance()->getValue(
            'SELECT FLOOR(COUNT(*) * RAND()) FROM `' . _DB_PREFIX_ . 'product_shop`
             WHERE `active` = 1 AND `id_shop` = ' . (int) $this->context->shop->id
        );

        $id = Db::getInstance()->executeS(
            'SELECT `id_product` FROM `' . _DB_PREFIX_ . 'product_shop`
             WHERE `active` = 1 AND `id_shop` = ' . (int) $this->context->shop->id . '
             LIMIT ' . (int) $row . ', 1'
        );

        if (count($id) && isset($id[0]['id_product'])) {
            return $id[0]['id_product'];
        }

        return null;
    }

    protected function getCountdownTypes()
    {
        return [
            'regular' => $this->l('Regular'),
            'schedule' => $this->l('On schedule'),
        ];
    }

    protected function getCountdownTypesOptions()
    {
        $types = $this->getCountdownTypes();
        $result = [];

        foreach ($types as $type => $label) {
            $result[] = [
                'id_option' => $type,
                'name' => $label,
            ];
        }

        return $result;
    }

    protected function getDaysOfWeek()
    {
        return [
            1 => $this->l('Monday'),
            2 => $this->l('Tuesday'),
            3 => $this->l('Wednesday'),
            4 => $this->l('Thursday'),
            5 => $this->l('Friday'),
            6 => $this->l('Saturday'),
            7 => $this->l('Sunday'),
        ];
    }

    public function smartyModifierImplode($separator, $array)
    {
        return implode($separator, $array);
    }

    public function registerSmartyPlugins()
    {
        // Register the custom modifier with Smarty, PS8.1
        if (version_compare(_PS_VERSION_, '8.1', '>=')) {
            $smarty = $this->context->smarty;
            if (empty($smarty->registered_plugins['modifier']['implode'])) {
                $smarty->registerPlugin('modifier', 'implode', [$this, 'smartyModifierImplode']);
            }
        }
    }

    protected function getPriorityOptionList()
    {
        $options = [
            [
                'id_option' => 1,
                'name' => $this->l('Priority 1 - display first'),
            ],
        ];

        for ($i = 2; $i < 10; ++$i) {
            $options[] = [
                'id_option' => $i,
                'name' => sprintf($this->l('Priority %s'), $i),
            ];
        }

        $options[] = [
            'id_option' => 10,
            'name' => $this->l('Priority 10 - display last'),
        ];

        return $options;
    }

    public function getModuleConfigurationPageUrl($params = [])
    {
        $url = 'index.php?controller=AdminModules&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules');
        if ($params) {
            $url .= '&' . http_build_query($params);
        }

        if (method_exists($this->context->link, 'getAdminLink')) {
            // This check helps determine if you are in a symfony context or not.
            // The check used in the diff was `checkUseSymfony()` which is also a good option.
            $url = $this->context->link->getAdminLink('AdminModules', true, [], array_merge(['configure' => $this->name], $params));
        }

        return $url;
    }
}
